<?php
include '../config/session_check.php';
if ($_SESSION['role'] != 'staff') {
    header("Location: ../config/login.php");
    exit();
}
?>

<?php
include '../includes/auth.php';
?>
<!DOCTYPE html>
<html>
<head><title>Staff Dashboard</title></head>
<body>
<h2>Welcome Staff - <?php echo $_SESSION['username']; ?></h2>
<a href="../admin/logout.php">Logout</a>
</body>
</html>