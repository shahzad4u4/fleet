<aside id="sidebar" class="w-64 bg-white border-r border-slate-200 p-4 space-y-2 fixed inset-y-0 left-0 transform -translate-x-full md:translate-x-0 transition-transform duration-200 z-40">
  <div class="flex items-center justify-between">
    <a href="/index.php" class="text-lg font-bold">Fleet Master</a>
    <button class="md:hidden p-2" onclick="toggleSidebar()">✕</button>
  </div>
  <nav class="mt-4 space-y-1 text-sm">
    <a href="/modules/booking_bilty/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Booking / Bilty</a>
    <a href="/modules/dispatch/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Dispatch</a>
    <a href="/modules/trips/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Trips</a>
    <a href="/modules/vehicles/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Vehi122cles</a>
    <a href="/modules/drivers/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Drivers</a>
    <a href="/modules/invoice/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Invoice</a>
    <a href="/modules/payments/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Payments</a>
    <a href="/modules/expenses/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Expenses</a>
    <a href="/modules/customers/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Customers</a>
    <a href="/modules/reports/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Reports</a>
    <a href="/modules/users_auth/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Users</a>
    <a href="/modules/settings/" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Settings</a>
  </nav>
</aside>
<div id="overlay" class="fixed inset-0 bg-black/30 z-30 hidden md:hidden" onclick="toggleSidebar()"></div>
<script>
function toggleSidebar(){
  const s = document.getElementById('sidebar');
  const o = document.getElementById('overlay');
  if(s.classList.contains('-translate-x-full')){ s.classList.remove('-translate-x-full'); o.classList.remove('hidden'); }
  else { s.classList.add('-translate-x-full'); o.classList.add('hidden'); }
}
</script>
