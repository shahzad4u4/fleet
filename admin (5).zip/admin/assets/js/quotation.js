// Google Maps Distance Calculator
let map, directionsService, directionsRenderer, distanceService;
let stops = [];

function initMap(){
  const start = {lat:24.8607, lng:67.0011}; // Karachi default
  map = new google.maps.Map(document.getElementById('map'), { zoom: 6, center: start });
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer({ map });
  distanceService = new google.maps.DistanceMatrixService();
}

function calcRoute(){
  const from = document.getElementById('from').value.trim();
  const to = document.getElementById('to').value.trim();
  if(!from || !to) return;
  const waypoints = Array.from(document.querySelectorAll('.stop-input'))
    .map(i => i.value.trim()).filter(Boolean).map(s => ({location:s, stopover:true}));
  directionsService.route({
    origin: from, destination: to, waypoints, optimizeWaypoints:false, travelMode: 'DRIVING'
  }, (res, status) => {
    if(status === 'OK'){
      directionsRenderer.setDirections(res);
      // sum legs distance
      let meters = 0;
      const legs = res.routes[0].legs;
      for(const leg of legs){ meters += leg.distance.value; }
      const km = (meters/1000).toFixed(1);
      document.getElementById('distance_km').value = km;
    }
  });
}

function addStop(){
  const wrap = document.getElementById('stopsWrap');
  const div = document.createElement('div');
  div.className = 'input-group mb-2';
  div.innerHTML = '<input type="text" class="form-control stop-input" placeholder="Add stop">'+
                  '<button type="button" class="btn btn-outline-danger" onclick="this.parentNode.remove();calcRoute();">×</button>';
  wrap.appendChild(div);
}

document.addEventListener('input', (e)=>{
  if(['from','to'].includes(e.target.id) || e.target.classList.contains('stop-input')){
    // debounce
    clearTimeout(window.__kmTimer);
    window.__kmTimer = setTimeout(calcRoute, 500);
  }
});
