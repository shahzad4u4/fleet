<?php
include '../includes/db.php';

// Fetch current settings
$result = $conn->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Settings</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <h2>System Settings</h2>
    <form action="save_settings.php" method="post" enctype="multipart/form-data">
        <label>Company Name</label>
        <input type="text" name="company_name" value="<?= $settings['company_name'] ?? '' ?>" required><br>

        <label>Contact Person</label>
        <input type="text" name="contact_person" value="<?= $settings['contact_person'] ?? '' ?>"><br>

        <label>Phone</label>
        <input type="text" name="phone" value="<?= $settings['phone'] ?? '' ?>"><br>

        <label>Email</label>
        <input type="email" name="email" value="<?= $settings['email'] ?? '' ?>"><br>

        <label>Address</label>
        <textarea name="address"><?= $settings['address'] ?? '' ?></textarea><br>

        <label>Logo</label>
        <input type="file" name="logo"><br>
        <?php if(!empty($settings['logo'])): ?>
            <img src="uploads/<?= $settings['logo'] ?>" width="100"><br>
        <?php endif; ?>

        <label>Letterhead (JPG/PNG)</label>
        <input type="file" name="letterhead"><br>
        <?php if(!empty($settings['letterhead'])): ?>
            <img src="uploads/<?= $settings['letterhead'] ?>" width="200"><br>
        <?php endif; ?>

        <label>WhatsApp API</label>
        <input type="text" name="whatsapp_api" value="<?= $settings['whatsapp_api'] ?? '' ?>"><br>

        <label>Google API</label>
        <input type="text" name="google_api" value="<?= $settings['google_api'] ?? '' ?>"><br>

        <button type="submit">Save Settings</button>
    </form>
</body>
</html>
