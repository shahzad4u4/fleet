<?php
// Admin shim to open the module without changing your menu structure.
require_once __DIR__ . '/../modules/bookings/_bootstrap.php';
include __DIR__ . '/../modules/bookings/index.php';
