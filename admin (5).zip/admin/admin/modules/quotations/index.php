<?php
require __DIR__ . '/../../../includes/db.php';
$page_title = 'Quotations - Admin';
include __DIR__ . '/../../../includes/header.php';
$res = $conn->query("SELECT id, customer_name, phone, from_city, to_city, status, created_at FROM quotations ORDER BY id DESC");
?>
<h1>Quotations</h1>
<table>
  <thead><tr><th>ID</th><th>Customer</th><th>Phone</th><th>Route</th><th>Status</th><th>Created</th><th>Action</th></tr></thead>
  <tbody>
  <?php while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['customer_name']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td><?= htmlspecialchars($row['from_city']) ?> → <?= htmlspecialchars($row['to_city']) ?></td>
      <td><?= htmlspecialchars($row['status']) ?></td>
      <td><?= htmlspecialchars($row['created_at']) ?></td>
      <td><a href="view.php?id=<?= $row['id'] ?>">View</a></td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php include __DIR__ . '/../../../includes/footer.php'; ?>
