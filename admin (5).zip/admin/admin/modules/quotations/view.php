<?php
require __DIR__ . '/../../../includes/db.php';
$id = intval($_GET['id'] ?? 0);
$q = $conn->query("SELECT * FROM quotations WHERE id="$id" LIMIT 1");
if(!$q || !$q->num_rows){ die('Quotation not found'); }
$data = $q->fetch_assoc();
$stops = $conn->query("SELECT * FROM quotation_stops WHERE quotation_id=$id ORDER BY stop_order");
$page_title = 'Quotation #'.$id;
include __DIR__ . '/../../../includes/header.php';
?>
<h1>Quotation #<?= $id ?></h1>
<p><b>Customer:</b> <?= htmlspecialchars($data['customer_name']) ?> (<?= htmlspecialchars($data['phone']) ?>)</p>
<p><b>Route:</b> <?= htmlspecialchars($data['from_city']) ?> →
  <?php while($s=$stops->fetch_assoc()) echo htmlspecialchars($s['stop_city']).' → '; ?>
  <?= htmlspecialchars($data['to_city']) ?>
</p>
<p><b>Vehicle:</b> <?= htmlspecialchars($data['vehicle_type']) ?>,
   <b>KM:</b> <?= htmlspecialchars($data['km']) ?></p>
<p><b>Notes:</b> <?= nl2br(htmlspecialchars($data['notes'])) ?></p>
<form method="post" action="edit.php">
  <input type="hidden" name="id" value="<?= $id ?>">
  <select name="status">
    <option value="pending" <?= $data['status']=='pending'?'selected':''; ?>>Pending</option>
    <option value="approved" <?= $data['status']=='approved'?'selected':''; ?>>Approved</option>
    <option value="rejected" <?= $data['status']=='rejected'?'selected':''; ?>>Rejected</option>
  </select>
  <button type="submit">Update Status</button>
</form>
<?php include __DIR__ . '/../../../includes/footer.php'; ?>
