<?php
require __DIR__ . '/../../../includes/db.php';
$id = intval($_POST['id'] ?? 0);
$status = $_POST['status'] ?? 'pending';
$stmt = $conn->prepare("UPDATE quotations SET status=? WHERE id=?");
$stmt->bind_param('si', $status, $id);
$stmt->execute();
header('Location: index.php');
?>
