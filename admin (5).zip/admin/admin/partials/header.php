<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>HS Logistics Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <style>
    .sidebar-link{ @apply flex items-center px-4 py-2 rounded hover:bg-blue-50 cursor-pointer; }
  </style>
</head>
<body class="bg-gray-100 min-h-screen">
<div class="flex">
  <!-- Sidebar -->
  <aside class="w-64 bg-white shadow-lg hidden md:block">
    <div class="p-4 border-b">
      <h1 class="text-xl font-bold">HS Logistics</h1>
      <p class="text-xs text-gray-500">Admin shahzaf Panel</p>
    </div>
    <nav class="p-3 space-y-1">
      <a href="index.php" class="block sidebar-link">🏠 Dashboard</a>
      <a href="../modules/vehicles/index.php" class="block sidebar-link">🚛 Vehicles</a>
      <a href="../modules/drivers/index.php" class="block sidebar-link">👨‍✈️ Drivers</a>
      <a href="../modules/trips/index.php" class="block sidebar-link">🗺 Trips</a>
      <a href="../modules/bookings/index.php" class="block sidebar-link">📑 Bookings</a>
      <a href="../modules/bilty/index.php" class="block sidebar-link">🧾 Bilasasty / LR</a>
      <a href="../modules/payments/index.php" class="block sidebar-link">💳 Payments</a>
      <a href="../modules/expenses/index.php" class="block sidebar-link">💰 Expenses</a>
      <a href="../modules/invoices/index.php" class="block sidebar-link">📄 Invoices</a>
       <a href="../modules/customers/index.php" class="block sidebar-link">📄 Icustomers</a>
      <a href="../modules/staff/add_staff.php" class="block sidebar-link">👥 Staff</a>
      <a href="slider.php" class="block sidebar-link">🖼 Slider</a>
      <a href="../modules/reports/index.php" class="block sidebar-link">📈 Reports</a>
      <a href="../modules/settings/index.php" class="block sidebar-link">⚙ Settings</a>
      <a href="logout.php" class="block sidebar-link text-red-600">🚪 Logout</a>
    </nav>
  </aside>

  <!-- Main -->
  <main class="flex-1">
    <header class="bg-white shadow-sm">
      <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <button onclick="document.getElementById('mnav').classList.toggle('hidden')" class="md:hidden px-3 py-2 bg-blue-600 text-white rounded">Menu</button>
        <div class="font-semibold">Welcome, <?php echo isset($_SESSION['email'])?htmlspecialchars($_SESSION['email']):'Admin'; ?></div>
        <a href="logout.php" class="text-sm text-red-600">Logout</a>
      </div>
      <!-- mobile nav -->
      <div id="mnav" class="md:hidden hidden bg-white border-t">
        <nav class="p-3 space-y-1">
          <a href="index.php" class="block sidebar-link">🏠 Dashboard</a>
          <a href="../modules/vehicles/index.php" class="block sidebar-link">🚛 Vehicles</a>
          <a href="../modules/drivers/index.php" class="block sidebar-link">👨‍✈️ Drivers</a>
          <a href="../modules/trips/index.php" class="block sidebar-link">🗺 Trips</a>
          <a href="../modules/bookings/index.php" class="block sidebar-link">📑 Bookings</a>
          <a href="../modules/bilty/index.php" class="block sidebar-link">🧾 Bilty / LR</a>
          <a href="../modules/payments/index.php" class="block sidebar-link">💳 Payments</a>
          <a href="../modules/expenses/index.php" class="block sidebar-link">💰 Expenses</a>
          <a href="../modules/invoices/index.php" class="block sidebar-link">📄 Invoices</a>
          <a href="slider.php" class="block sidebar-link">🖼 Slider</a>
          <a href="../modules/reports/index.php" class="block sidebar-link">📈 Reports</a>
          <a href="../modules/settings/index.php" class="block sidebar-link">⚙ Settings</a>
          <a href="logout.php" class="block sidebar-link text-red-600">🚪 Logout</a>
        </nav>
      </div>
    </header>
    <div class="max-w-7xl mx-auto px-4 py-6">
