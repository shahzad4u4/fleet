<ul class="sidebar-menu">

    <li>
        <a href="dashboard.php">
            <i class="fa fa-home"></i> Dashboard
        </a>
    </li>

    <li>
        <a href="modules/vehicles/index.php">
            <i class="fa fa-truck"></i> Vehicles
        </a>
    </li>

    <li>
        <a href="modules/drivers/index.php">
            <i class="fa fa-user"></i> Drivers
        </a>
    </li>

    <li>
        <a href="modules/trips/index.php">
            <i class="fa fa-map"></i> Trips
        </a>
    </li>

    <li>
        <a href="modules/bookings/index.php">
            <i class="fa fa-book"></i> Bookings
        </a>
    </li>

    <li>
        <a href="modules/customers/index.php">
            <i class="fa fa-users"></i> Customers
        </a>
    </li>

    <li>
        <a href="modules/bilty/index.php">
            <i class="fa fa-file-text"></i> Bilty / LR
        </a>
    </li>

    <li>
        <a href="modules/payments/index.php">
            <i class="fa fa-credit-card"></i> Payments
        </a>
    </li>

    <li>
        <a href="modules/expenses/index.php">
            <i class="fa fa-money"></i> Expenses
        </a>
    </li>

    <li>
        <a href="modules/invoices/index.php">
            <i class="fa fa-file-invoice"></i> Invoices
        </a>
    </li>

    <li>
        <a href="modules/slider/index.php">
            <i class="fa fa-image"></i> Slider
        </a>
    </li>

    <li>
        <a href="modules/reports/index.php">
            <i class="fa fa-chart-line"></i> Reports
        </a>
    </li>

    <li>
        <a href="modules/settings/index.php">
            <i class="fa fa-cog"></i> Settings
        </a>
    </li>

    <li>
        <a href="logout.php" style="color:red;">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </li>

</ul>