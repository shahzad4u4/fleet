<?php
require __DIR__.'/../includes/auth.php';
require __DIR__.'/../includes/db.php';
$page_title = 'Dashboard';
include __DIR__.'/../includes/header.php';
?>
<div class="w-full overflow-hidden mb-4">
  <img src="/uploads/slider.jpg" class="w-full h-56 object-cover rounded shadow" onerror="this.style.display='none'">
</div>
<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
  <?php
  $cards = [
    ['title'=>'Vehicles','href'=>'/modules/vehicles/index.php'],
    ['title'=>'Drivers','href'=>'/modules/drivers/index.php'],
    ['title'=>'Bookings','href'=>'/modules/bookings/index.php'],
    ['title'=>'Enquiries','href'=>'/modules/enquiries/index.php'], // ✅ نیا module
    ['title'=>'Bilty','href'=>'/modules/bilty/index.php'],
    ['title'=>'Customers','href'=>'/modules/customers/index.php'], // ✅ root/modules path confirm
    ['title'=>'Expenses','href'=>'/modules/expenses/index.php'],
    ['title'=>'Invoices','href'=>'/modules/invoices/index.php'],
    ['title'=>'Payments','href'=>'/modules/payments/index.php'],
    ['title'=>'Reports','href'=>'/modules/reports/index.php'],
    ['title'=>'Settings','href'=>'/modules/settings/index.php'],
    ['title'=>'Staff','href'=>'/modules/staff/index.php'],
    ['title'=>'Slider','href'=>'/modules/slider/index.php'],
    ['title'=>'Quotations','href'=>'/modules/quotations/index.php'],
  ];

  foreach($cards as $c){
    echo '<a class="bg-white border rounded-xl p-6 shadow hover:shadow-lg transition block" href="'.$c['href'].'">
            <div class="text-lg font-semibold">'.$c['title'].'</div>
            <div class="text-xs text-gray-500">Open Module</div>
          </a>';
  }
  ?>
</div>
<section class="mt-6">
  <div class="bg-white p-4 rounded-xl shadow" style="height:420px">
    <div class="font-semibold mb-2">Monthly Bookings</div>
    <canvas id="chart" style="max-height:360px"></canvas>
  </div>
</section>
<script>
const ctx = document.getElementById('chart').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {labels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    datasets:[{label:'Bookings', data:[5,9,7,11,6,13,8,10,12,9,6,14]}]},
  options:{responsive:true, maintainAspectRatio:false}
});
</script>
<?php include __DIR__.'/../includes/footer.php'; ?>