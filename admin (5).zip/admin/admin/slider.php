<?php
require_once '../includes/session_check.php';
require_once '../includes/db.php';

// Ensure table exists
$conn->query("CREATE TABLE IF NOT EXISTS slider (
  id INT AUTO_INCREMENT PRIMARY KEY,
  image VARCHAR(255) NOT NULL,
  title VARCHAR(100) NULL,
  description TEXT NULL,
  status TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// Handle Add
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action']) && $_POST['action']==='add') {
    if (!empty($_FILES['image']['name'])) {
        $dir = '../uploads/sliders/';
        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fname = 'slide_'.time().'_'.mt_rand(1000,9999).'.'.strtolower($ext);
        $target = $dir.$fname;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $title = $conn->real_escape_string($_POST['title'] ?? '');
            $desc  = $conn->real_escape_string($_POST['description'] ?? '');
            $status= (int)($_POST['status'] ?? 1);
            $conn->query("INSERT INTO slider (image,title,description,status) VALUES ('$fname','$title','$desc',$status)");
            $msg = '✅ Slide added.';
        } else {
            $msg = '❌ Upload failed.';
        }
    } else {
        $msg = '❌ Please select image.';
    }
}

// Handle Delete
if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    $rs = $conn->query("SELECT image FROM slider WHERE id=$id");
    if ($rs && $rs->num_rows){
        $img = $rs->fetch_assoc()['image'];
        @unlink('../uploads/sliders/'.$img);
    }
    $conn->query("DELETE FROM slider WHERE id=$id");
    header("Location: slider.php");
    exit();
}

// Toggle status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $conn->query("UPDATE slider SET status = IF(status=1,0,1) WHERE id=$id");
    header("Location: slider.php");
    exit();
}

$slides = $conn->query("SELECT * FROM slider ORDER BY id DESC");
include 'partials/header.php';
?>
<div class="bg-white p-4 rounded shadow mb-6">
  <h2 class="text-lg font-semibold mb-4">Slider Manager</h2>
  <?php if(!empty($msg)): ?><div class="p-3 mb-3 bg-blue-50 text-blue-700 rounded"><?php echo $msg; ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="grid md:grid-cols-4 gap-3 items-end">
    <input type="hidden" name="action" value="add">
    <div class="md:col-span-2">
      <label class="text-sm block mb-1">Image</label>
      <input type="file" name="image" accept="image/*" class="w-full border rounded p-2" required>
    </div>
    <div>
      <label class="text-sm block mb-1">Title</label>
      <input type="text" name="title" class="w-full border rounded p-2" placeholder="Optional">
    </div>
    <div>
      <label class="text-sm block mb-1">Description</label>
      <input type="text" name="description" class="w-full border rounded p-2" placeholder="Optional">
    </div>
    <div>
      <label class="text-sm block mb-1">Status</label>
      <select name="status" class="w-full border rounded p-2">
        <option value="1">Active</option>
        <option value="0">Inactive</option>
      </select>
    </div>
    <div class="md:col-span-4">
      <button class="bg-blue-600 text-white px-4 py-2 rounded">Add Slide</button>
    </div>
  </form>
</div>

<div class="bg-white p-4 rounded shadow">
  <h3 class="font-semibold mb-3">Slides</h3>
  <div class="grid md:grid-cols-3 gap-4">
    <?php if($slides && $slides->num_rows): while($row=$slides->fetch_assoc()): ?>
      <div class="border rounded overflow-hidden">
        <img src="<?php echo '../uploads/sliders/'.htmlspecialchars($row['image']); ?>" class="w-full h-40 object-cover" alt="">
        <div class="p-3 space-y-2">
          <div class="font-medium"><?php echo htmlspecialchars($row['title'] ?? ''); ?></div>
          <div class="text-sm text-gray-600"><?php echo htmlspecialchars($row['description'] ?? ''); ?></div>
          <div class="text-xs">Status: <?php echo $row['status']?'Active':'Inactive'; ?></div>
          <div class="flex gap-2">
            <a href="slider.php?toggle=<?php echo $row['id']; ?>" class="px-3 py-1 bg-yellow-100 rounded">Toggle</a>
            <a href="slider.php?del=<?php echo $row['id']; ?>" class="px-3 py-1 bg-red-100 rounded" onclick="return confirm('Delete this slide?')">Delete</a>
          </div>
        </div>
      </div>
    <?php endwhile; else: ?>
      <div class="text-gray-500">No slides uploaded yet.</div>
    <?php endif; ?>
  </div>
</div>

<?php include 'partials/footer.php'; ?>
