<?php
// admin/bilty.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$_GET['from_admin'] = 1;
require_once __DIR__ . '/../modules/bilty/list.php';
