<?php /* sample sidebar - merge into your admin */ ?>
<ul>
  <li><a href="/admin/modules/quotations/index.php">Quotations</a></li>
</ul>
