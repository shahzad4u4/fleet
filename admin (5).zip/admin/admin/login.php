<?php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = $conn->real_escape_string($_POST['email'] ?? '');
    $password = $conn->real_escape_string($_POST['password'] ?? '');
    $q = $conn->query("SELECT id, email, role_id FROM users WHERE email='$email' AND password='$password' LIMIT 1");
    if ($q && $q->num_rows===1){
        $u = $q->fetch_assoc();
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['email'] = $u['email'];
        $_SESSION['role_id'] = $u['role_id'];
        header("Location: index.php");
        exit();
    } else {
        $err = 'Invalid email or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - HS Logistics</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">
  <div class="bg-white w-full max-w-md rounded-xl shadow p-6">
    <h1 class="text-2xl font-bold text-center mb-4">HS Logistics</h1>
    <?php if (!empty($err)): ?>
      <div class="mb-3 p-3 text-red-700 bg-red-50 rounded"><?php echo $err; ?></div>
    <?php endif; ?>
    <form method="post" class="space-y-3">
      <div>
        <label class="text-sm">Email</label>
        <input type="email" name="email" class="w-full border rounded p-2" required>
      </div>
      <div>
        <label class="text-sm">Password</label>
        <input type="password" name="password" class="w-full border rounded p-2" required>
      </div>
      <button class="w-full bg-blue-600 text-white py-2 rounded">Login</button>
    </form>
  </div>
</body>
</html>
<?php ob_end_flush(); ?>
