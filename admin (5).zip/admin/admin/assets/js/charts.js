
document.addEventListener('DOMContentLoaded', () => {
  const rx = document.getElementById('rxChart');
  if (rx) {
    new Chart(rx, {
      type: 'line',
      data: {
        labels: ['Mar','Apr','May','Jun','Jul','Aug'],
        datasets: [
          {label:'Revenue', data:[120,160,140,200,220,240], tension:.35},
          {label:'Expense', data:[90,110,130,150,140,160], tension:.35}
        ]
      },
      options: { responsive: true, maintainAspectRatio: false }
    });
  }
  const tb = document.getElementById('tbChart');
  if (tb) {
    new Chart(tb, {
      type: 'bar',
      data: {
        labels: ['Mar','Apr','May','Jun','Jul','Aug'],
        datasets: [
          {label:'Trips', data:[30,28,35,40,42,38]},
          {label:'Bookings', data:[22,24,30,33,35,34]}
        ]
      },
      options: { responsive: true, maintainAspectRatio: false }
    });
  }
});
