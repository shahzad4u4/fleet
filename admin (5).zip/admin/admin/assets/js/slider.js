
document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('hs-slider');
  if(!root) return;
  const slides = Array.from(root.querySelectorAll('.hs-slide'));
  const prev = root.querySelector('.hs-prev');
  const next = root.querySelector('.hs-next');
  let i = 0, t;

  const show = (idx)=>{
    slides.forEach((s, k)=>{
      s.style.transition = 'opacity .5s ease';
      s.style.opacity = (k===idx)?'1':'0';
      s.style.zIndex = (k===idx)?'10':'0';
    });
  };
  const auto = ()=>{
    clearInterval(t);
    t = setInterval(()=>{
      i = (i+1) % slides.length;
      show(i);
    }, 3500);
  };

  prev && prev.addEventListener('click', ()=>{ i = (i-1+slides.length)%slides.length; show(i); auto(); });
  next && next.addEventListener('click', ()=>{ i = (i+1)%slides.length; show(i); auto(); });

  show(i);
  auto();
});
