<?php
require_once '../includes/session_check.php';
require_once '../includes/db.php';

function safeCount($conn, $table){
    $q = $conn->query("SELECT COUNT(*) c FROM {$table}");
    if ($q) { $row = $q->fetch_assoc(); return (int)$row['c']; }
    return 0;
}

$stats = [
  'vehicles' => safeCount($conn,'vehicles'),
  'drivers'  => safeCount($conn,'drivers'),
  'trips'    => safeCount($conn,'trips'),
  'expenses' => safeCount($conn,'expenses'),
];

// Slider fetch (if table missing, fallback empty)
$slides = [];
if ($conn->query("SHOW TABLES LIKE 'slider'")->num_rows === 1) {
  $res = $conn->query("SELECT * FROM slider WHERE status=1 ORDER BY id DESC LIMIT 10");
  if ($res) { while($r = $res->fetch_assoc()){ $slides[] = $r; } }
}

include 'partials/header.php';
?>

<!-- Slider -->
<div class="bg-white rounded-lg shadow p-0 overflow-hidden mb-6">
  <div class="relative">
    <div id="slider" class="relative w-full h-56 md:h-72 overflow-hidden">
      <?php if (count($slides)): ?>
        <?php foreach($slides as $i=>$s): ?>
          <div class="slide absolute inset-0 <?php echo $i===0?'':'hidden'; ?>">
            <img src="<?php echo '../uploads/sliders/'.htmlspecialchars($s['image']); ?>" class="w-full h-full object-cover" alt="slide">
            <?php if (!empty($s['title']) || !empty($s['description'])): ?>
              <div class="absolute bottom-0 left-0 right-0 bg-black bg-opacity-40 text-white p-4">
                <h3 class="text-lg font-semibold"><?php echo htmlspecialchars($s['title'] ?? ''); ?></h3>
                <p class="text-sm"><?php echo htmlspecialchars($s['description'] ?? ''); ?></p>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="absolute inset-0 flex items-center justify-center text-gray-500">
          <div class="text-center p-6">
            <p class="font-semibold">No slides yet</p>
            <p class="text-sm">Go to <a class="text-blue-600 underline" href="slider.php">Slider Manager</a> to upload images.</p>
          </div>
        </div>
      <?php endif; ?>
    </div>
    <div class="absolute inset-0 flex items-center justify-between px-2">
      <button id="prev" class="bg-white bg-opacity-70 px-3 py-2 rounded shadow">‹</button>
      <button id="next" class="bg-white bg-opacity-70 px-3 py-2 rounded shadow">›</button>
    </div>
  </div>
</div>

<!-- Stats -->
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
  <div class="bg-white p-4 rounded shadow">
    <div class="text-gray-500 text-sm">Vehicles</div>
    <div class="text-2xl font-bold"><?php echo $stats['vehicles']; ?></div>
  </div>
  <div class="bg-white p-4 rounded shadow">
    <div class="text-gray-500 text-sm">Drivers</div>
    <div class="text-2xl font-bold"><?php echo $stats['drivers']; ?></div>
  </div>
  <div class="bg-white p-4 rounded shadow">
    <div class="text-gray-500 text-sm">Trips</div>
    <div class="text-2xl font-bold"><?php echo $stats['trips']; ?></div>
  </div>
  <div class="bg-white p-4 rounded shadow">
    <div class="text-gray-500 text-sm">Expenses</div>
    <div class="text-2xl font-bold">Rs <?php
      $sum = 0;
      $qr = $conn->query("SELECT SUM(amount) s FROM expenses");
      if ($qr){ $sum = (int)($qr->fetch_assoc()['s'] ?? 0); }
      echo number_format($sum);
    ?></div>
  </div>
</div>

<!-- Chart -->
<div class="bg-white p-4 rounded shadow mb-6">
  <h3 class="font-semibold mb-3">Monthly Expenses</h3>
  <canvas id="expChart"></canvas>
</div>

<script>
// Simple slider
(function(){
  const slides = document.querySelectorAll('#slider .slide');
  let i = 0;
  function show(idx){
    slides.forEach((s, k)=> s.classList.toggle('hidden', k!==idx));
  }
  document.getElementById('prev').addEventListener('click', ()=>{ i = (i - 1 + slides.length) % slides.length; show(i); });
  document.getElementById('next').addEventListener('click', ()=>{ i = (i + 1) % slides.length; show(i); });
  if (slides.length > 1){ setInterval(()=>{ i = (i + 1) % slides.length; show(i); }, 5000); }
})();

// Dummy chart data (replace with server data later)
const ctx = document.getElementById('expChart');
if (ctx){
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      datasets: [{
        label: 'Expenses',
        data: [12000, 15000, 8000, 22000, 14000, 20000, 24000, 18000, 16000, 21000, 23000, 19000]
      }]
    },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } }, elements: { line: { tension: .3 } } }
  });
}
</script>

<?php include 'partials/footer.php'; ?>
