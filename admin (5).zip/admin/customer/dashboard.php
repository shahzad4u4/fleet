<?php
include '../config/session_check.php';
if ($_SESSION['role'] != 'customer') {
    header("Location: ../config/login.php");
    exit();
}
?>

<?php
include '../includes/auth.php';
?>
<!DOCTYPE html>
<html>
<head><title>Customer Dashboard</title></head>
<body>
<h2>Welcome Customer - <?php echo $_SESSION['username']; ?></h2>
<a href="../admin/logout.php">Logout</a>
</body>
</html>