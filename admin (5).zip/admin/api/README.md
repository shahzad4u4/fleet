# Deploy — HS Logistics API

Upload this `api_php` folder to `/public_html/api/` on your hosting.
Create DB tables by running `schema.sql` in phpMyAdmin.
db.php already points to:
- DB: hslogistics_fleet2
- USER: hslogistics_root
- PASS: shazhad1234
