
INSTALL (Non-Destructive)
-------------------------
1) Zip ko extract kiye bina 'admin' folder ke andar yeh files copy kar den:
   - admin/dashboard.php
   - admin/includes/header.php
   - admin/includes/footer.php
   - admin/assets/css/dashboard.css
   - admin/assets/js/charts.js
   - admin/assets/js/slider.js

2) Kisi module/file ko move/overwrite NAHIN kiya gaya.
   Links assume karte hain ke modules yahan hain:
   ../modules/<module>/index.php
   Agar aapke modules ka folder different hai to header.php nav links adjust kar len.

3) Company details & slider:
   - Table `settings` (key, value) optional hai:
       company_name, company_address, company_phone, company_email, company_logo
     Agar table nahi hoga to defaults show honge.
   - Table `slider` (id, image_path, sort_order) optional hai.
     Agar record nahi hoga to ../uploads/slider/slide1.jpg etc placeholders use honge.

4) Charts:
   - Demo values set hain; aap chahein to DB se real data wire kar sakte hain.

5) Auth:
   - Page guard karta hai: if (!$_SESSION['user_id']) → login.php
