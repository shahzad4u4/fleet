HS Logistics — Phase-2 (Bilty + Reports)
=================================================
This package adds Bilty/LR management and Booking+Bilty report.

Folders
-------
- modules/bilty/    → add.php, list.php, edit.php, delete.php, _bootstrap.php
- modules/reports/  → booking_bilty.php
- admin/bilty.php   → shortcut
- admin/reports.php → shortcut
- uploads/bilty/    → file uploads target (make writable 775/755)
- sql/phase2_bilty.sql → table structure (no CREATE DATABASE)

How to install
--------------
1) Copy the folders into your project WITHOUT changing existing structure.
   Do NOT replace your config; the bootstrap auto-loads config/db.php or includes/db.php.

2) Create table in your database:
   - Import sql/phase2_bilty.sql in phpMyAdmin (select your DB first).

3) File permissions:
   - Make sure /uploads/bilty/ is writable by the web server (chmod 775 or 755).

4) Open from admin:
   - Bilty:   /admin/bilty.php
   - Reports: /admin/reports.php

Permissions
-----------
- Admin: add + edit + delete all
- Staff/Customer: add + view own (if your session stores role/role_id it will respect admin-only for edit/delete)

Notes
-----
- Tailwind is served via CDN for quick UI (mobile responsive).
- If you already have a layout header/footer, you can remove the standalone <html> shell in module files and include in your template.
- For CSV export: click "Export CSV" on Reports page; for PDF, use browser Print → Save as PDF.

Generated: 2025-08-17T17:33:54.942959
