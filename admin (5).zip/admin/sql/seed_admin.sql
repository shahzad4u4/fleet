-- seed_admin.sql
-- Default admin user: username=admin, password=123456
INSERT INTO users (username, password, role)
VALUES ('admin', '$2y$10$7b0N8Hfrf0zPq1q7fO0wK.2xw5uG0bEw6EwV9tH7x6F9v0o6u8b1K', 'admin')
ON DUPLICATE KEY UPDATE role='admin';
-- The hash above is bcrypt for '123456'.
