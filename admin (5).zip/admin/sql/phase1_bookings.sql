-- Phase 1: Bookings schema (safe create, no drop)
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_no` VARCHAR(30) NOT NULL,
  `customer_id` INT NULL,
  `vehicle_id` INT NULL,
  `pickup_address` VARCHAR(255) NOT NULL,
  `drop_address` VARCHAR(255) NOT NULL,
  `stops_json` TEXT NULL,
  `distance_km` DECIMAL(10,2) DEFAULT 0,
  `advance_amount` DECIMAL(12,2) DEFAULT 0,
  `total_amount` DECIMAL(12,2) DEFAULT 0,
  `status` ENUM('Pending','In-Transit','Delivered','Cancelled') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_booking_no` (`booking_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional seed (remove if not needed)
INSERT INTO bookings (booking_no, pickup_address, drop_address, distance_km, advance_amount, total_amount, status)
VALUES ('BK-1001','Lahore','Karachi', 1215.00, 20000.00, 120000.00, 'Pending')
ON DUPLICATE KEY UPDATE booking_no=booking_no;
