-- Phase-2: Bilty / LR table
CREATE TABLE IF NOT EXISTS `bilties` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` INT UNSIGNED NOT NULL,
  `bilty_no` VARCHAR(100) NOT NULL,
  `file_path` VARCHAR(255) DEFAULT NULL,
  `created_by` INT UNSIGNED DEFAULT NULL,
  `status` ENUM('Pending','In-Transit','Delivered') DEFAULT 'Pending',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_booking` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional demo record (ensure booking_id exists)
-- INSERT INTO bilties (booking_id, bilty_no, file_path, created_by, status) VALUES (1,'LR-2025-0001',NULL,1,'Pending');
