# Fleet Master – Clean Merged Build

This is the cleaned project built from your merged source:
- Duplicate clash files removed (skipped `__dupN` variants).
- Unified layout added in `/app/layout` (header, sidebar, topnav, footer).
- Dashboard `index.php` with quick links and module file listing.

## How to run
1) Place project in your PHP server root (XAMPP/ Laragon / nginx).
2) Configure database in `/config/db.php` (or your own config).
3) Import SQL files from `/sql/` into your DB.
4) Open `http://localhost/index.php`.

> Note: Existing module pages keep their own includes; migrate them gradually to `/app/layout/*` for full consistency.
