<?php
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HS Logistics - Home</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header>
    <div class="logo">HS Logistics</div>
    <nav>
      <a href="index.php">Home</a>
      <a href="pages/about.php">About</a>
      <a href="pages/contact.php">Contact</a>
      <a href="enquiry.php">Get Quotation</a>
      <a href="login.html">Login</a>
    </nav>
  </header>

  <section class="hero">
    <h1>Welcome to HS Logistics</h1>
    <p>Pakistan’s trusted fleet and logistics management solution.</p>
  </section>

  <footer>
    <p>&copy; <?php echo date('Y'); ?> HS Logistics. All Rights Reserved.</p>
  </footer>
</body>
</html>
