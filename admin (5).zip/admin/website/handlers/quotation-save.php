<?php
require __DIR__ . '/../includes/db.php';
header('Content-Type: text/html; charset=utf-8');

// Create tables if not exist (safe)
$conn->query("CREATE TABLE IF NOT EXISTS quotations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL,
    from_city VARCHAR(120) NOT NULL,
    to_city VARCHAR(120) NOT NULL,
    vehicle_type VARCHAR(80) DEFAULT NULL,
    km INT DEFAULT NULL,
    notes TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS quotation_stops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quotation_id INT NOT NULL,
    stop_order INT NOT NULL,
    stop_city VARCHAR(120) NOT NULL,
    FOREIGN KEY (quotation_id) REFERENCES quotations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function post($k){ return trim($_POST[$k] ?? ''); }

$stmt = $conn->prepare("INSERT INTO quotations (customer_name,phone,from_city,to_city,vehicle_type,km,notes) VALUES (?,?,?,?,?,?,?)");
if(!$stmt){ die('SQL error: ' . $conn->error); }
$km = strlen(post('km')) ? intval(post('km')) : NULL;
$stmt->bind_param('sssssis',
    $_POST['customer_name'], $_POST['phone'], $_POST['from_city'], $_POST['to_city'],
    $_POST['vehicle_type'], $km, $_POST['notes']
);
$stmt->execute();
$qid = $stmt->insert_id;
$stmt->close();

$stops = array_filter(array_map('trim', explode(',', $_POST['stops'] ?? '')));
if($stops){
    $ins = $conn->prepare("INSERT INTO quotation_stops (quotation_id, stop_order, stop_city) VALUES (?,?,?)");
    $i=1;
    foreach($stops as $s){
        $ins->bind_param('iis', $qid, $i, $s);
        $ins->execute();
        $i++;
    }
    $ins->close();
}

echo '<script>alert("Quotation submitted successfully. Our team will contact you.");window.location="/pages/quotation.php";</script>';
?>
