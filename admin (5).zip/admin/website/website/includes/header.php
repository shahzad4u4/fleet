<?php if(!isset($page_title)) $page_title='HS Logistics'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($page_title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
  <link rel="stylesheet" href="/website/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="/website/index.php">
      <img src="/website/assets/images/logo.png" alt="HS Logistics" width="40" height="40" class="rounded">
      <span class="fw-bold">HS Logistics</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsMain">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarsMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="/website/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="/website/about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="/website/services.php">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="/website/quotation.php">Quotation</a></li>
        <li class="nav-item"><a class="nav-link" href="/website/contact.php">Contact</a></li>
      </ul>
      <div class="d-flex">
        <a class="btn btn-outline-light" href="/fleet/login.html">Login</a>
      </div>
    </div>
  </div>
</nav>
<main>
