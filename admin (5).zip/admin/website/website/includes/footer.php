</main>
<footer class="bg-dark text-light mt-5">
  <div class="container py-4">
    <div class="row g-4">
      <div class="col-md-6">
        <h5>HS Logistics</h5>
        <p class="mb-1">Fast, Reliable & Secure Transport across Pakistan.</p>
        <small>© <span id="y"></span> HS Logistics. All rights reserved.</small>
      </div>
      <div class="col-md-6 text-md-end">
        <a class="text-light text-decoration-none me-3" href="/website/about.php">About</a>
        <a class="text-light text-decoration-none me-3" href="/website/services.php">Services</a>
        <a class="text-light text-decoration-none me-3" href="/website/quotation.php">Quotation</a>
        <a class="text-light text-decoration-none" href="/website/contact.php">Contact</a>
      </div>
    </div>
  </div>
</footer>
<script>document.getElementById('y').textContent=new Date().getFullYear();</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="/website/assets/js/main.js"></script>
</body>
</html>
