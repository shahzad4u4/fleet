<?php
  $page_title='Get Quotation - HS Logistics';
  include __DIR__.'/../includes/header.php';
  include __DIR__.'/../includes/db.php';
?>
<h1>Get a Quotation</h1>
<form class="grid" method="post" action="/handlers/quotation-save.php">
  <div>
    <label>Customer Name</label>
    <input name="customer_name" required>
  </div>
  <div>
    <label>Phone</label>
    <input name="phone" required>
  </div>
  <div>
    <label>From (City)</label>
    <input name="from_city" required>
  </div>
  <div>
    <label>To (City)</label>
    <input name="to_city" required>
  </div>
  <div>
    <label>Stops (comma separated)</label>
    <input name="stops" placeholder="Hyderabad, Sukkur">
  </div>
  <div>
    <label>Vehicle Type</label>
    <select name="vehicle_type">
      <option>20ft Container</option>
      <option>40ft Container</option>
      <option>Reefer</option>
      <option>Flatbed</option>
    </select>
  </div>
  <div>
    <label>Estimated KM</label>
    <input type="number" name="km" min="1">
  </div>
  <div style="grid-column:1/-1">
    <label>Goods / Notes</label>
    <textarea name="notes" rows="3"></textarea>
  </div>
  <div style="grid-column:1/-1">
    <button type="submit">Submit Quotation Request</button>
  </div>
</form>
<?php include __DIR__.'/../includes/footer.php'; ?>
