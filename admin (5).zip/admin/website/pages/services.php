<?php $page_title='Services - HS Logistics'; include __DIR__.'/../includes/header.php'; ?>
<h1>Services</h1>
<p>We offer modern fleet services including FTL, reefer logistics, and port operations.</p>
<?php include __DIR__.'/../includes/footer.php'; ?>
