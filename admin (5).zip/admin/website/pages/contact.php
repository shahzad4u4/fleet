<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact HS Logistics</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
  <h1>Contact Us</h1>
  <p>Email: info@hslogistics.pk</p>
  <p>Phone: +92-300-1234567</p>
</body>
</html>
