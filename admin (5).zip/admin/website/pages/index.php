<?php $page_title='HS Logistics - Home'; include __DIR__.'/../includes/header.php'; ?>
<section class="hero">
  <h1>Fast, Reliable & Secure Logistics in Pakistan</h1>
  <p>We provide container, reefer, and bulk transport with trusted drivers and tracked routes.</p>
  <p><a href="/pages/quotation.php"><button>Get a Free Quotation</button></a></p>
</section>
<h2>Our Services</h2>
<ul>
  <li>Full Truck Load (FTL)</li>
  <li>Reefer & Dry Containers (20/40 ft)</li>
  <li>Door-to-Door Delivery across Pakistan</li>
</ul>
<?php include __DIR__.'/../includes/footer.php'; ?>
