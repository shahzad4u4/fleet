<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About HS Logistics</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
  <h1>About Us</h1>
  <p>HS Logistics is a modern fleet and logistics management company based in Pakistan.</p>
</body>
</html>
