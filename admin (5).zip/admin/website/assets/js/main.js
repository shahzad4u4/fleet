if (document.querySelector('.swiper')){
  new Swiper('.swiper', {
    loop: true,
    autoplay: { delay: 3500 },
    pagination: { el: '.swiper-pagination', clickable: true },
  });
}
