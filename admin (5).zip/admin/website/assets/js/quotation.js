let map, directionsService, directionsRenderer;
function initMap(){
  const start = {lat:24.8607, lng:67.0011}; // Karachi
  map = new google.maps.Map(document.getElementById('map'), { zoom: 6, center: start });
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer({ map });
}
function calcRoute(){
  const from = document.getElementById('from').value.trim();
  const to = document.getElementById('to').value.trim();
  if(!from || !to) return;
  const waypoints = Array.from(document.querySelectorAll('.stop-input'))
    .map(i => i.value.trim()).filter(Boolean).map(s => ({location:s, stopover:true}));
  directionsService.route({
    origin: from, destination: to, waypoints, travelMode: 'DRIVING'
  }, (res, status) => {
    if(status === 'OK'){
      directionsRenderer.setDirections(res);
      let meters = 0;
      for(const leg of res.routes[0].legs){ meters += leg.distance.value; }
      document.getElementById('distance_km').value = (meters/1000).toFixed(1);
    }
  });
}
function addStop(){
  const wrap = document.getElementById('stopsWrap');
  const div = document.createElement('div');
  div.className = 'input-group mb-2';
  div.innerHTML = '<input type="text" name="stops[]" class="form-control stop-input" placeholder="Add stop">'+
                  '<button type="button" class="btn btn-outline-danger" onclick="this.parentNode.remove();calcRoute();">×</button>';
  wrap.appendChild(div);
}
document.addEventListener('input',(e)=>{
  if(['from','to'].includes(e.target.id) || e.target.classList.contains('stop-input')){
    clearTimeout(window.__kmTimer); window.__kmTimer=setTimeout(calcRoute,400);
  }
});
