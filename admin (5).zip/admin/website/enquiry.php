<?php
include_once "../db.php";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $from = $_POST['from_location'];
    $to = $_POST['to_location'];
    $stops = $_POST['stops'];
    $km = $_POST['km'];
    $sql = "INSERT INTO enquiries (from_location, to_location, stops, km, status)
            VALUES ('$from', '$to', '$stops', '$km', 'Pending')";
    if(mysqli_query($conn, $sql)){
        echo "Your enquiry has been submitted successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Get Quotation - HS Logistics</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <h2>Request a Quotation</h2>
  <form method="POST">
    <label>From:</label><input type="text" name="from_location" required><br>
    <label>To:</label><input type="text" name="to_location" required><br>
    <label>Stops (if any):</label><input type="text" name="stops"><br>
    <label>KM:</label><input type="number" name="km" required><br>
    <button type="submit">Submit</button>
  </form>
</body>
</html>
