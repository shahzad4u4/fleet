<?php
$conn = mysqli_connect("localhost", "hslogistics_root", "shahzad1234", "hslogistics_fleet");
if (!$conn) { die("Database connection failed"); }
?>