hs
<?php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'hslogistics_fleet',
    'user' => 'hslogistics_root',
    'pass' => 'shahzad1234'
  ],
  'app' => [
    'base_url' => 'http://localhost/hslogistics',
    'locale' => 'en',
    'allow_public_booking' => true
  ],
  'security' => [
    'session_name' => 'hs_session',
    'csrf_key' => 'change_this_random_key',
    'upload_max_size' => 5242880
  ]
];
