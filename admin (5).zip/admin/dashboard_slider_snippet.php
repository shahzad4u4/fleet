<?php
$sliders = mysqli_query($conn,"SELECT * FROM sliders ORDER BY id DESC");
?>
<div id="carouselExample" class="carousel slide mb-4" data-bs-ride="carousel">
  <div class="carousel-inner">
    <?php $active = "active"; while($s=mysqli_fetch_assoc($sliders)){ ?>
      <div class="carousel-item <?= $active ?>">
        <img src="<?= $s['image'] ?>" class="d-block w-100" style="height:300px;object-fit:cover;">
        <div class="carousel-caption d-none d-md-block">
          <h5><?= $s['title'] ?></h5>
        </div>
      </div>
    <?php $active=""; } ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
