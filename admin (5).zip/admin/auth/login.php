<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../config/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || $password === '') {
        $error = 'Username and password are required.';
    } else {
        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['user'] = ['id'=>$row['id'],'username'=>$row['username'],'role'=>$row['role']];
                header("Location: /index.php");
                exit;
            }
        }
        $error = 'Invalid credentials';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Fleet Master</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
  <div class="w-full max-w-sm bg-white border rounded-2xl shadow p-6">
    <h1 class="text-xl font-bold mb-4">Fleet Master Login</h1>
    <?php if($error): ?><div class="mb-3 text-red-600 text-sm"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="post" class="space-y-3">
      <div>
        <label class="text-sm">Username</label>
        <input name="username" class="mt-1 w-full border rounded px-3 py-2" required>
      </div>
      <div>
        <label class="text-sm">Password</label>
        <input name="password" type="password" class="mt-1 w-full border rounded px-3 py-2" required>
      </div>
      <button class="w-full px-3 py-2 border rounded-lg bg-slate-900 text-white">Login</button>
    </form>
  </div>
</body>
</html>
