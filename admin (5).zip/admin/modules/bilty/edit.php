<?php
require_once __DIR__ . '/_bootstrap.php';
require_login();
if (!is_admin()) { die('Only admin can edit.'); }

$id = intval($_GET['id'] ?? 0);
if ($id<=0) { die('Invalid ID'); }

$res = $conn->query("SELECT * FROM bilties WHERE id=".$id);
$item = $res ? $res->fetch_assoc() : null;
if (!$item) { die('Not found'); }

$errors = []; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $bilty_no = trim($_POST['bilty_no'] ?? '');
    $status = trim($_POST['status'] ?? 'Pending');

    if ($bilty_no==='') $errors[]='Bilty number required.';
    $file_path = $item['file_path'];

    if (!empty($_FILES['bilty_file']['name'])) {
        $allowed = ['pdf','jpg','jpeg','png'];
        $ext = strtolower(pathinfo($_FILES['bilty_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) $errors[]='Invalid file type.';
        else {
            $safe = 'bilty_' . time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/','_', $_FILES['bilty_file']['name']);
            $dir = __DIR__ . '/../../uploads/bilty/';
            if (!is_dir($dir)) mkdir($dir, 0775, true);
            $dest = $dir.$safe;
            if (!move_uploaded_file($_FILES['bilty_file']['tmp_name'], $dest)) $errors[]='Upload failed.';
            else $file_path = '/uploads/bilty/'.$safe;
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare("UPDATE bilties SET bilty_no=?, status=?, file_path=? WHERE id=?");
        $stmt->bind_param('sssi', $bilty_no, $status, $file_path, $id);
        if ($stmt->execute()) $success='Updated successfully.'; else $errors[]=$conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Bilty</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-4">
<div class="max-w-3xl mx-auto bg-white rounded-xl shadow p-6">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">Edit Bilty</h1>
        <a href="/admin/bilty.php" class="text-sm underline">← Back to List</a>
    </div>
    <?php if($errors): ?><div class="mb-4 p-3 rounded bg-red-50 text-red-700"><ul class="ml-6 list-disc"><?php foreach($errors as $e):?><li><?=htmlspecialchars($e)?></li><?php endforeach;?></ul></div><?php endif; ?>
    <?php if($success): ?><div class="mb-4 p-3 rounded bg-green-50 text-green-700"><?=htmlspecialchars($success)?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="grid gap-4">
        <label class="grid gap-1">
            <span class="text-sm">Bilty / LR No.</span>
            <input class="border rounded p-2" type="text" name="bilty_no" value="<?=htmlspecialchars($item['bilty_no'])?>">
        </label>
        <label class="grid gap-1">
            <span class="text-sm">Status</span>
            <select class="border rounded p-2" name="status">
                <?php foreach(['Pending','In-Transit','Delivered'] as $s): ?>
                    <option <?=$item['status']===$s?'selected':''?>><?=$s?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="grid gap-1">
            <span class="text-sm">Replace File (optional)</span>
            <input class="border rounded p-2" type="file" name="bilty_file" accept=".pdf,.jpg,.jpeg,.png">
            <?php if(!empty($item['file_path'])): ?>
                <a class="text-indigo-600 underline mt-1" href="<?=htmlspecialchars($item['file_path'])?>" target="_blank">Current File</a>
            <?php endif; ?>
        </label>
        <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">Update</button>
    </form>
</div>
</body>
</html>
