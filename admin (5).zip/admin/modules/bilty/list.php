<?php
require_once __DIR__ . '/_bootstrap.php';
require_login();

// handle delete (admin only)
if (isset($_GET['delete']) && is_admin()) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM bilties WHERE id=".$id);
    header('Location: /admin/bilty.php?msg=deleted');
    exit;
}

// Fetch list
$q = "SELECT b.id, b.bilty_no, b.file_path, b.status, b.created_at, bk.customer_name, bk.from_location, bk.to_location
      FROM bilties b
      LEFT JOIN bookings bk ON bk.id=b.booking_id
      ORDER BY b.id DESC LIMIT 500";
$res = $conn->query($q);
$rows = [];
if ($res) { while($r = $res->fetch_assoc()) { $rows[] = $r; } }
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Bilty / LR List</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-4">
<div class="max-w-6xl mx-auto bg-white rounded-xl shadow p-6">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <h1 class="text-xl font-semibold">Bilty / LR</h1>
        <div class="flex gap-2">
            <a href="/modules/bilty/add.php" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">+ Add Bilty</a>
            <a href="/admin/dashboard.php" class="px-3 py-2 rounded border">Dashboard</a>
        </div>
    </div>
    <?php if($msg==='deleted'): ?>
        <div class="mb-4 p-3 rounded bg-green-50 text-green-700">Deleted.</div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="text-left p-2">#</th>
                    <th class="text-left p-2">Bilty No</th>
                    <th class="text-left p-2">Booking</th>
                    <th class="text-left p-2">Route</th>
                    <th class="text-left p-2">Status</th>
                    <th class="text-left p-2">File</th>
                    <th class="text-left p-2">Created</th>
                    <th class="text-left p-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $r): ?>
                    <tr class="border-b">
                        <td class="p-2"><?=intval($r['id'])?></td>
                        <td class="p-2"><?=htmlspecialchars($r['bilty_no'])?></td>
                        <td class="p-2"><?=htmlspecialchars($r['customer_name'] ?? '-')?></td>
                        <td class="p-2"><?=htmlspecialchars(($r['from_location'] ?? '-') . ' → ' . ($r['to_location'] ?? '-'))?></td>
                        <td class="p-2"><?=htmlspecialchars($r['status'])?></td>
                        <td class="p-2">
                            <?php if(!empty($r['file_path'])): ?>
                                <a class="text-indigo-600 underline" href="<?=htmlspecialchars($r['file_path'])?>" target="_blank">Open</a>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td class="p-2"><?=htmlspecialchars($r['created_at'])?></td>
                        <td class="p-2 flex gap-2">
                            <a class="px-2 py-1 border rounded" href="/modules/bilty/edit.php?id=<?=$r['id']?>">Edit</a>
                            <?php if(is_admin()): ?>
                                <a class="px-2 py-1 border rounded text-red-600" href="?delete=<?=$r['id']?>" onclick="return confirm('Delete this bilty?')">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if(empty($rows)): ?>
                    <tr><td class="p-4 text-center text-gray-500" colspan="8">No records.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
