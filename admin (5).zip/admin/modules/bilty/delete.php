<?php
require_once __DIR__ . '/_bootstrap.php';
require_login();
if (!is_admin()) { die('Only admin can delete.'); }
$id = intval($_GET['id'] ?? 0);
if ($id>0) { $conn->query("DELETE FROM bilties WHERE id=".$id); }
header('Location: /admin/bilty.php?msg=deleted');
exit;
