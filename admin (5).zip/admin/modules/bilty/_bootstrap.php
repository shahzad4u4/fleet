<?php
// modules/bilty/_bootstrap.php
// Auto-detect DB include and start session safely
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function __try_include($paths) {
    foreach ($paths as $p) {
        if (file_exists($p)) { require_once $p; return true; }
    }
    return false;
}

// Try common db include locations used in your project
$tried = __try_include([
    __DIR__ . '/../../config/db.php',
    __DIR__ . '/../../includes/db.php',
    __DIR__ . '/../../config/database.php',
    __DIR__ . '/../../db.php',
]);

if (!$tried) {
    // As a fallback, create a mysqli connection from env-like constants if defined
    if (!isset($conn)) {
        $host = defined('DB_HOST') ? DB_HOST : 'localhost';
        $user = defined('DB_USER') ? DB_USER : 'root';
        $pass = defined('DB_PASS') ? DB_PASS : '';
        $name = defined('DB_NAME') ? DB_NAME : 'hslogistics_fleet';
        $conn = @new mysqli($host, $user, $pass, $name);
        if ($conn->connect_errno) {
            die('Database not connected. Please verify config/db.php. Error: '.$conn->connect_error);
        }
    }
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('DB connection ($conn) not available. Ensure config/db.php defines $conn = new mysqli(...)');
}

// Role helper (accepts role text or role_id=1)
function is_admin() {
    if (!isset($_SESSION)) return false;
    if (!empty($_SESSION['role']) && strtolower($_SESSION['role']) === 'admin') return true;
    if (!empty($_SESSION['role_id']) && intval($_SESSION['role_id']) === 1) return true;
    return false;
}

// Simple auth guard (require login)
function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: /admin/login.php');
        exit;
    }
}
?>
