<?php
require_once __DIR__ . '/_bootstrap.php';
require_login();

// Fetch bookings for select (limit to 200 newest)
$bookings = [];
$res = $conn->query("SELECT id, customer_name, from_location, to_location FROM bookings ORDER BY id DESC LIMIT 200");
if ($res) { while($row = $res->fetch_assoc()) { $bookings[] = $row; } }

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = intval($_POST['booking_id'] ?? 0);
    $bilty_no   = trim($_POST['bilty_no'] ?? '');
    $status     = trim($_POST['status'] ?? 'Pending');

    if ($booking_id <= 0) $errors[] = "Please select a booking.";
    if ($bilty_no === '') $errors[] = "Bilty/LR number is required.";

    // Handle file upload
    $file_path = null;
    if (!empty($_FILES['bilty_file']['name'])) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($_FILES['bilty_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            $errors[] = "Only PDF, JPG, JPEG, PNG files are allowed.";
        } else {
            $safeName = 'bilty_' . time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/','_', $_FILES['bilty_file']['name']);
            $destDir = __DIR__ . '/../../uploads/bilty/';
            if (!is_dir($destDir)) mkdir($destDir, 0775, true);
            $dest = $destDir . $safeName;
            if (!move_uploaded_file($_FILES['bilty_file']['tmp_name'], $dest)) {
                $errors[] = "File upload failed.";
            } else {
                $file_path = '/uploads/bilty/' . $safeName;
            }
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare("INSERT INTO bilties (booking_id, bilty_no, file_path, created_by, status) VALUES (?, ?, ?, ?, ?)");
        $uid = intval($_SESSION['user_id'] ?? 0);
        $stmt->bind_param('issis', $booking_id, $bilty_no, $file_path, $uid, $status);
        if ($stmt->execute()) {
            $success = "Bilty created successfully.";
        } else {
            $errors[] = "DB error: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Bilty / LR</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-4">
<div class="max-w-3xl mx-auto bg-white rounded-xl shadow p-6">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">Add Bilty / LR</h1>
        <a href="/admin/bilty.php" class="text-sm underline">← Back to List</a>
    </div>
    <?php if($errors): ?>
        <div class="mb-4 p-3 rounded bg-red-50 text-red-700">
            <ul class="list-disc ml-6">
                <?php foreach($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach;?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if($success): ?>
        <div class="mb-4 p-3 rounded bg-green-50 text-green-700"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="grid gap-4">
        <label class="grid gap-1">
            <span class="text-sm text-gray-700">Booking</span>
            <select name="booking_id" class="border rounded p-2">
                <option value="">-- Select Booking --</option>
                <?php foreach($bookings as $b): ?>
                    <option value="<?=$b['id']?>">#<?=$b['id']?> — <?=$b['customer_name']?> (<?=$b['from_location']?> → <?=$b['to_location']?>)</option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="grid gap-1">
            <span class="text-sm text-gray-700">Bilty / LR No.</span>
            <input type="text" name="bilty_no" class="border rounded p-2" placeholder="e.g. LR-2025-0001" />
        </label>

        <label class="grid gap-1">
            <span class="text-sm text-gray-700">Attach File (PDF/JPG/PNG)</span>
            <input type="file" name="bilty_file" accept=".pdf,.jpg,.jpeg,.png" class="border rounded p-2" />
        </label>

        <label class="grid gap-1">
            <span class="text-sm text-gray-700">Status</span>
            <select name="status" class="border rounded p-2">
                <option>Pending</option>
                <option>In-Transit</option>
                <option>Delivered</option>
            </select>
        </label>

        <button class="mt-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">Save Bilty</button>
    </form>
</div>
</body>
</html>
