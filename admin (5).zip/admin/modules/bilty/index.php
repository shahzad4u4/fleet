<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';

$page_title = 'Bilty Upload';
include __DIR__ . '/../../includes/header.php';

// ================== File Upload ==================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['bilty'])) {
    $dir = __DIR__ . '/../../uploads/bilty/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $name = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['bilty']['name']);
    $path = $dir . $name;

    if (move_uploaded_file($_FILES['bilty']['tmp_name'], $path)) {
        $rel = '/uploads/bilty/' . $name;

        $stmt = $conn->prepare("INSERT INTO bilty (booking_id, file_path, notes) VALUES (?,?,?)");
        if ($stmt === false) {
            die("SQL insert error: " . $conn->error);
        }

        $booking_id = intval($_POST['booking_id'] ?? 0);
        $notes = $_POST['notes'] ?? '';

        $stmt->bind_param('iss', $booking_id, $rel, $notes);
        $stmt->execute();

        echo "<p style='color:green;'>✅ Bilty uploaded.</p>";
    } else {
        echo "<p style='color:red;'>❌ Upload failed.</p>";
    }
}

// ================== Records Fetch ==================
$records = $conn->query("SELECT id, booking_id, file_path, notes, uploaded_at 
                         FROM bilty ORDER BY id DESC");

if (!$records) {
    die("SQL select error: " . $conn->error);
}
?>

<h2>Bilty Upload</h2>
<form method="POST" enctype="multipart/form-data">
    <label>Booking ID:</label>
    <input type="number" name="booking_id" required><br><br>

    <label>Notes:</label>
    <textarea name="notes"></textarea><br><br>

    <label>Select Bilty File:</label>
    <input type="file" name="bilty" required><br><br>

    <button type="submit">Upload</button>
</form>

<hr>

<h3>Uploaded Bilty Records</h3>
<table border="1" cellpadding="6" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Booking ID</th>
        <th>Notes</th>
        <th>File</th>
        <th>Uploaded At</th>
    </tr>
    <?php if ($records->num_rows > 0): ?>
        <?php while ($row = $records->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['booking_id']); ?></td>
                <td><?php echo htmlspecialchars($row['notes']); ?></td>
                <td><a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View</a></td>
                <td><?php echo htmlspecialchars($row['uploaded_at']); ?></td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="5" style="color:red;">No records found.</td></tr>
    <?php endif; ?>
</table>
