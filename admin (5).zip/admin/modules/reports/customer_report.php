<?php
// Customer report with Export/Print buttons
?>
<button onclick='window.print()'>Print</button>
<a href='report_export_pdf.php?type=customer'>Export PDF</a>
<a href='report_export_excel.php?type=customer'>Export Excel</a>