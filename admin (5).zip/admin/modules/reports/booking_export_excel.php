<?php
include 'db.php';
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=bookings.xlsx");

$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

echo "BookingID	Consignment	Customer	From	To	Freight	Advance	Balance	Status\n";
while($row = $result->fetch_assoc()) {
    echo $row['id']."\t".$row['consignment_no']."\t".$row['customer']."\t".$row['from_location']."\t".$row['to_location']."\t".$row['freight']."\t".$row['advance']."\t".$row['balance']."\t".$row['status']."\n";
}
?>