<?php
require('fpdf/fpdf.php');
include 'db.php';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,'Bilty Report',0,1,'C');

$sql = "SELECT * FROM bilty";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $pdf->Cell(0,10,"Bilty No: ".$row['bilty_no']." | Booking Ref: ".$row['booking_id']." | Consignor: ".$row['consignor'],0,1);
    $pdf->Cell(0,10,"Consignee: ".$row['consignee']." | Vehicle: ".$row['vehicle']." | Driver: ".$row['driver'],0,1);
    $pdf->Ln(5);
}
$pdf->Output("D","bilty_report.pdf");
?>