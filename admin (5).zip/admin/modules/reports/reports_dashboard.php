<?php
include 'db.php';
?>
<html>
<head>
<title>Reports Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<h2>Reports Dashboard</h2>

<canvas id="tripChart" width="400" height="200"></canvas>
<canvas id="expenseChart" width="400" height="200"></canvas>
<canvas id="paymentChart" width="400" height="200"></canvas>

<script>
var ctx1 = document.getElementById('tripChart').getContext('2d');
var tripChart = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Jan','Feb','Mar','Apr','May','Jun'],
        datasets: [{
            label: 'Trips',
            data: [12, 19, 3, 5, 2, 3],
            borderWidth: 1
        }]
    }
});

var ctx2 = document.getElementById('expenseChart').getContext('2d');
var expenseChart = new Chart(ctx2, {
    type: 'line',
    data: {
        labels: ['Jan','Feb','Mar','Apr','May','Jun'],
        datasets: [{
            label: 'Expenses',
            data: [2000, 1500, 3000, 2500, 2800, 3500],
            borderWidth: 1
        }]
    }
});

var ctx3 = document.getElementById('paymentChart').getContext('2d');
var paymentChart = new Chart(ctx3, {
    type: 'pie',
    data: {
        labels: ['Advance','Balance','Received'],
        datasets: [{
            data: [5000, 3000, 4000],
            borderWidth: 1
        }]
    }
});
</script>

<h3>Trip Table</h3>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Vehicle</th><th>Driver</th><th>Date</th><th>Status</th></tr>
<?php
$result = $conn->query("SELECT * FROM trips LIMIT 10");
while($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['vehicle']}</td><td>{$row['driver']}</td><td>{$row['date']}</td><td>{$row['status']}</td></tr>";
}
?>
</table>
</body>
</html>