<?php
// Half A4 Bilty Layout
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM bilty WHERE id=$id");
$row = $result->fetch_assoc();
?>
<html>
<head><title>Bilty Half Page</title></head>
<body style="font-family:Arial;">
<div style="width:48%; float:left; border:1px solid #000; padding:10px; margin:5px;">
    <h3 style="text-align:center;">Company Name / Logo</h3>
    <p>Bilty No: <?php echo $row['bilty_no']; ?><br>
    Booking Ref: <?php echo $row['booking_id']; ?><br>
    Consignor: <?php echo $row['consignor']; ?><br>
    Consignee: <?php echo $row['consignee']; ?><br>
    Vehicle: <?php echo $row['vehicle']; ?><br>
    Driver: <?php echo $row['driver']; ?><br>
    Freight: <?php echo $row['freight']; ?> | Advance: <?php echo $row['advance']; ?> | Balance: <?php echo $row['balance']; ?></p>
</div>

<div style="width:48%; float:right; border:1px solid #000; padding:10px; margin:5px;">
    <h3 style="text-align:center;">Company Name / Logo</h3>
    <p>Bilty No: <?php echo $row['bilty_no']; ?><br>
    Booking Ref: <?php echo $row['booking_id']; ?><br>
    Consignor: <?php echo $row['consignor']; ?><br>
    Consignee: <?php echo $row['consignee']; ?><br>
    Vehicle: <?php echo $row['vehicle']; ?><br>
    Driver: <?php echo $row['driver']; ?><br>
    Freight: <?php echo $row['freight']; ?> | Advance: <?php echo $row['advance']; ?> | Balance: <?php echo $row['balance']; ?></p>
</div>
</body>
</html>