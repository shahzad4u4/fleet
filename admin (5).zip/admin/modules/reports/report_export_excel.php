<?php
include 'db.php';

$type = $_GET['type'] ?? 'vehicle';

header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename={$type}_report.xls");
header("Pragma: no-cache");
header("Expires: 0");

$output = fopen("php://output", "w");

if ($type == "vehicle") {
    fputcsv($output, ["ID", "Vehicle No", "Model", "Capacity"], "\t");

    $result = $conn->query("SELECT id, vehicle_no, model, capacity FROM vehicles");
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row, "\t");
    }
}
fclose($output);
?>