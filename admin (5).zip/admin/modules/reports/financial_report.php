<?php
include 'db.php';

// Total Payments (group by status)
$paymentResult = $conn->query("
    SELECT status, SUM(amount) as total_amount
    FROM payments
    GROUP BY status
");
$paymentData = [];
while ($row = $paymentResult->fetch_assoc()) {
    $paymentData[$row['status']] = $row['total_amount'];
}

// Monthly Expenses
$expenseResult = $conn->query("
    SELECT MONTH(date) as month, YEAR(date) as year,
           SUM(amount) as total_expense
    FROM expenses
    GROUP BY YEAR(date), MONTH(date)
    ORDER BY YEAR(date), MONTH(date)
");
$expenseLabels = [];
$expenseTotals = [];
while ($row = $expenseResult->fetch_assoc()) {
    $monthYear = $row['month'] . '-' . $row['year'];
    $expenseLabels[] = $monthYear;
    $expenseTotals[] = $row['total_expense'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Financial Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        h2 { text-align: center; margin-bottom: 20px; }
        .report-section { margin-bottom: 40px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        table th, table td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        table th { background: #007bff; color: white; }
        .chart-container { width: 80%; margin: auto; }
    </style>
</head>
<body>
    <h2>Financial Report</h2>

    <div class="report-section">
        <h3>Payments Summary</h3>
        <table>
            <tr>
                <th>Status</th>
                <th>Total Amount (PKR)</th>
            </tr>
            <?php foreach ($paymentData as $status => $total) { ?>
            <tr>
                <td><?php echo ucfirst($status); ?></td>
                <td><?php echo $total; ?></td>
            </tr>
            <?php } ?>
        </table>

        <div class="chart-container">
            <canvas id="paymentChart"></canvas>
        </div>
    </div>

    <div class="report-section">
        <h3>Monthly Expenses</h3>
        <table>
            <tr>
                <th>Month-Year</th>
                <th>Total Expense (PKR)</th>
            </tr>
            <?php foreach ($expenseLabels as $i => $label) { ?>
            <tr>
                <td><?php echo $label; ?></td>
                <td><?php echo $expenseTotals[$i]; ?></td>
            </tr>
            <?php } ?>
        </table>

        <div class="chart-container">
            <canvas id="expenseChart"></canvas>
        </div>
    </div>

    <script>
        // Payments Pie Chart
        const paymentCtx = document.getElementById('paymentChart').getContext('2d');
        new Chart(paymentCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_keys($paymentData)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($paymentData)); ?>,
                    backgroundColor: ['#28a745', '#ffc107', '#dc3545']
                }]
            }
        });

        // Expense Line Chart
        const expenseCtx = document.getElementById('expenseChart').getContext('2d');
        new Chart(expenseCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($expenseLabels); ?>,
                datasets: [{
                    label: 'Expenses',
                    data: <?php echo json_encode($expenseTotals); ?>,
                    backgroundColor: '#007bff',
                    borderColor: '#007bff',
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: true } },
                scales: { y: { beginAtZero: true } }
            }
        });
    </script>
</body>
</html>
