<?php
// modules/reports/booking_bilty.php
require_once __DIR__ . '/../bilty/_bootstrap.php';
require_login();

$export = $_GET['export'] ?? '';

// Query: Booking + Bilty summary
$sql = "SELECT bk.id AS booking_id, bk.customer_name, bk.from_location, bk.to_location, bk.distance_km,
        COUNT(b.id) AS bilty_count,
        SUM(CASE WHEN b.status='Delivered' THEN 1 ELSE 0 END) AS delivered_count
        FROM bookings bk
        LEFT JOIN bilties b ON b.booking_id=bk.id
        GROUP BY bk.id
        ORDER BY bk.id DESC
        LIMIT 1000";
$res = $conn->query($sql);
$rows = [];
if ($res) { while($r = $res->fetch_assoc()) { $rows[] = $r; } }

if ($export==='csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="booking_bilty_report.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Booking ID','Customer','From','To','Distance(km)','Bilty Count','Delivered']);
    foreach($rows as $r) {
        fputcsv($out, [
            $r['booking_id'],
            $r['customer_name'],
            $r['from_location'],
            $r['to_location'],
            $r['distance_km'],
            $r['bilty_count'],
            $r['delivered_count']
        ]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Reports — Booking & Bilty</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-4">
<div class="max-w-7xl mx-auto bg-white rounded-xl shadow p-6">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <h1 class="text-xl font-semibold">Booking & Bilty Report</h1>
        <div class="flex gap-2">
            <a href="?export=csv" class="px-3 py-2 rounded bg-emerald-600 text-white hover:bg-emerald-700">Export CSV</a>
            <button onclick="window.print()" class="px-3 py-2 rounded border">Print / Save PDF</button>
            <a href="/admin/dashboard.php" class="px-3 py-2 rounded border">Dashboard</a>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="text-left p-2">Booking #</th>
                    <th class="text-left p-2">Customer</th>
                    <th class="text-left p-2">Route</th>
                    <th class="text-left p-2">Distance (km)</th>
                    <th class="text-left p-2">Bilty Count</th>
                    <th class="text-left p-2">Delivered</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $r): ?>
                <tr class="border-b">
                    <td class="p-2">#<?=$r['booking_id']?></td>
                    <td class="p-2"><?=htmlspecialchars($r['customer_name'])?></td>
                    <td class="p-2"><?=htmlspecialchars(($r['from_location'] ?? '-') . ' → ' . ($r['to_location'] ?? '-'))?></td>
                    <td class="p-2"><?=htmlspecialchars($r['distance_km'] ?? '-')?></td>
                    <td class="p-2"><?=htmlspecialchars($r['bilty_count'])?></td>
                    <td class="p-2"><?=htmlspecialchars($r['delivered_count'])?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($rows)): ?>
                    <tr><td colspan="6" class="p-4 text-center text-gray-500">No data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
