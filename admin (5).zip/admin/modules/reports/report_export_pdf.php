<?php
require('fpdf/fpdf.php');
include 'db.php';

$type = $_GET['type'] ?? 'vehicle';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(190,10,ucfirst($type)." Report",0,1,'C');
$pdf->Ln(10);

if ($type == 'vehicle') {
    $result = $conn->query("SELECT id, vehicle_no, model, capacity FROM vehicles");
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(30,10,"ID",1);
    $pdf->Cell(50,10,"Vehicle No",1);
    $pdf->Cell(50,10,"Model",1);
    $pdf->Cell(50,10,"Capacity",1);
    $pdf->Ln();

    $pdf->SetFont('Arial','',10);
    while($row = $result->fetch_assoc()){
        $pdf->Cell(30,10,$row['id'],1);
        $pdf->Cell(50,10,$row['vehicle_no'],1);
        $pdf->Cell(50,10,$row['model'],1);
        $pdf->Cell(50,10,$row['capacity'],1);
        $pdf->Ln();
    }
}

$pdf->Output();
?>