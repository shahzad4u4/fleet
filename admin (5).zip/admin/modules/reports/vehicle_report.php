<?php include 'db.php'; ?>
<h2>Vehicle Report</h2>
<button onclick="window.print()">🖨 Print</button>
<a href="report_export_pdf.php?type=vehicle">📄 Export PDF</a>
<a href="report_export_excel.php?type=vehicle">📊 Export Excel</a>

<table border="1" cellpadding="5" cellspacing="0">
<tr><th>ID</th><th>Vehicle No</th><th>Model</th><th>Capacity</th></tr>
<?php
$result = $conn->query("SELECT * FROM vehicles");
while($row = $result->fetch_assoc()){
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['vehicle_no']}</td>
        <td>{$row['model']}</td>
        <td>{$row['capacity']}</td>
    </tr>";
}
?>
</table>