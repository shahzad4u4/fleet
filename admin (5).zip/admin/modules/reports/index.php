<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Reports</h2><p>یہاں رپورٹیں آئیں گی۔</p></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
