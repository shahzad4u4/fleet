<?php
// Driver report with Export/Print buttons
?>
<button onclick='window.print()'>Print</button>
<a href='report_export_pdf.php?type=driver'>Export PDF</a>
<a href='report_export_excel.php?type=driver'>Export Excel</a>