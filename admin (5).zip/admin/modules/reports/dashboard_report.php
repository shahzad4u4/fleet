<?php
include 'db.php';

// 1️⃣ Summary Counts
$totalVehicles = $conn->query("SELECT COUNT(*) as total FROM vehicles")->fetch_assoc()['total'];
$totalDrivers = $conn->query("SELECT COUNT(*) as total FROM drivers")->fetch_assoc()['total'];
$totalTrips = $conn->query("SELECT COUNT(*) as total FROM trips")->fetch_assoc()['total'];
$totalExpenses = $conn->query("SELECT IFNULL(SUM(amount),0) as total FROM expenses")->fetch_assoc()['total'];
$totalPayments = $conn->query("SELECT IFNULL(SUM(amount),0) as total FROM payments")->fetch_assoc()['total'];

// 2️⃣ Expenses by Category
$expenseChartResult = $conn->query("SELECT category, SUM(amount) as total FROM expenses GROUP BY category");
$categories = [];
$expenseAmounts = [];
while ($row = $expenseChartResult->fetch_assoc()) {
    $categories[] = $row['category'];
    $expenseAmounts[] = $row['total'];
}

// 3️⃣ Trips by Vehicle
$tripChartResult = $conn->query("
    SELECT vehicles.name, COUNT(trips.id) as total_trips
    FROM vehicles
    LEFT JOIN trips ON trips.vehicle_id = vehicles.id
    GROUP BY vehicles.id, vehicles.name
");
$vehicleNames = [];
$tripCounts = [];
while ($row = $tripChartResult->fetch_assoc()) {
    $vehicleNames[] = $row['name'];
    $tripCounts[] = $row['total_trips'];
}

// 4️⃣ Latest Records
$latestTrips = $conn->query("SELECT id, origin, destination, date FROM trips ORDER BY date DESC LIMIT 5");
$latestExpenses = $conn->query("SELECT id, category, amount, date FROM expenses ORDER BY date DESC LIMIT 5");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Fleet Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        h2 { text-align: center; margin-bottom: 20px; }
        .cards { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .card { background: white; padding: 20px; border-radius: 10px; flex: 1; margin: 5px; text-align: center; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }
        .card h3 { margin: 0; font-size: 22px; color: #007bff; }
        .card p { margin: 5px 0 0; font-size: 18px; }
        .charts { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .chart-container { width: 48%; background: white; padding: 15px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: white; }
        table th, table td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        table th { background: #007bff; color: white; }
    </style>
</head>
<body>
    <h2>Fleet Management Dashboard</h2>

    <!-- Summary Cards -->
    <div class="cards">
        <div class="card"><h3><?php echo $totalVehicles; ?></h3><p>Total Vehicles</p></div>
        <div class="card"><h3><?php echo $totalDrivers; ?></h3><p>Total Drivers</p></div>
        <div class="card"><h3><?php echo $totalTrips; ?></h3><p>Total Trips</p></div>
        <div class="card"><h3><?php echo $totalExpenses; ?> PKR</h3><p>Total Expenses</p></div>
        <div class="card"><h3><?php echo $totalPayments; ?> PKR</h3><p>Total Payments</p></div>
    </div>

    <!-- Charts -->
    <div class="charts">
        <div class="chart-container">
            <h3 style="text-align:center;">Expenses by Category</h3>
            <canvas id="expenseChart"></canvas>
        </div>
        <div class="chart-container">
            <h3 style="text-align:center;">Trips by Vehicle</h3>
            <canvas id="tripChart"></canvas>
        </div>
    </div>

    <!-- Latest Records -->
    <h3>Latest Trips</h3>
    <table>
        <tr><th>ID</th><th>Origin</th><th>Destination</th><th>Date</th></tr>
        <?php while ($row = $latestTrips->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['origin']; ?></td>
            <td><?php echo $row['destination']; ?></td>
            <td><?php echo $row['date']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <h3>Latest Expenses</h3>
    <table>
        <tr><th>ID</th><th>Category</th><th>Amount (PKR)</th><th>Date</th></tr>
        <?php while ($row = $latestExpenses->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['amount']; ?></td>
            <td><?php echo $row['date']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <!-- JS Charts -->
    <script>
        // Expense Pie Chart
        const expCtx = document.getElementById('expenseChart').getContext('2d');
        new Chart(expCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($categories); ?>,
                datasets: [{
                    data: <?php echo json_encode($expenseAmounts); ?>,
                    backgroundColor: ['#ff6384','#36a2eb','#ffcd56','#4bc0c0','#9966ff','#ff9f40']
                }]
            }
        });

        // Trips Bar Chart
        const tripCtx = document.getElementById('tripChart').getContext('2d');
        new Chart(tripCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($vehicleNames); ?>,
                datasets: [{
                    label: 'Total Trips',
                    data: <?php echo json_encode($tripCounts); ?>,
                    backgroundColor: '#28a745'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    </script>
</body>
</html>