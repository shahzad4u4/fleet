<?php
require_once __DIR__ . '/_bootstrap.php';

$msg = $_GET['msg'] ?? '';
$rows = [];
$res = mysqli_query($conn, "SELECT * FROM bookings ORDER BY id DESC");
while($res && $r = mysqli_fetch_assoc($res)) { $rows[] = $r; }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Bookings</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-6xl mx-auto p-6">
    <div class="flex items-center justify-between mb-4">
      <h1 class="text-2xl font-semibold">Bookings</h1>
      <a href="/modules/bookings/add.php" class="px-4 py-2 bg-blue-600 text-white rounded">+ New Booking</a>
    </div>

    <?php if ($msg): ?>
    <div class="mb-4 p-3 rounded bg-green-100 text-green-800"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow overflow-x-auto">
      <table class="min-w-full">
        <thead class="bg-gray-100">
          <tr>
            <th class="text-left px-4 py-3">#</th>
            <th class="text-left px-4 py-3">Booking No</th>
            <th class="text-left px-4 py-3">Pickup</th>
            <th class="text-left px-4 py-3">Drop</th>
            <th class="text-left px-4 py-3">KM</th>
            <th class="text-left px-4 py-3">Advance</th>
            <th class="text-left px-4 py-3">Total</th>
            <th class="text-left px-4 py-3">Status</th>
            <th class="text-left px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($rows as $i=>$r): ?>
          <tr class="border-t">
            <td class="px-4 py-3"><?php echo $i+1; ?></td>
            <td class="px-4 py-3 font-medium"><?php echo htmlspecialchars($r['booking_no']); ?></td>
            <td class="px-4 py-3"><?php echo htmlspecialchars($r['pickup_address']); ?></td>
            <td class="px-4 py-3"><?php echo htmlspecialchars($r['drop_address']); ?></td>
            <td class="px-4 py-3"><?php echo (float)$r['distance_km']; ?></td>
            <td class="px-4 py-3"><?php echo number_format((float)$r['advance_amount'],2); ?></td>
            <td class="px-4 py-3"><?php echo number_format((float)$r['total_amount'],2); ?></td>
            <td class="px-4 py-3"><?php echo htmlspecialchars($r['status']); ?></td>
            <td class="px-4 py-3">
              <a class="text-blue-600" href="/modules/bookings/edit.php?id=<?php echo $r['id']; ?>">Edit</a>
              <span class="mx-1">|</span>
              <a class="text-red-600" href="/modules/bookings/delete.php?id=<?php echo $r['id']; ?>" onclick="return confirm('Delete this booking?')">Delete</a>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($rows)): ?>
          <tr><td colspan="9" class="px-4 py-6 text-center text-gray-500">No bookings yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
