<?php
require_once __DIR__ . '/_bootstrap.php';
$id = (int)($_GET['id'] ?? 0);
mysqli_query($conn, "DELETE FROM bookings WHERE id=$id");
header('Location: /admin/bookings.php?msg=deleted');
exit;
