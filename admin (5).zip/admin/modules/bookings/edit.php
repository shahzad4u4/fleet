<?php
require_once __DIR__ . '/_bootstrap.php';
$id = (int)($_GET['id'] ?? 0);
$res = mysqli_query($conn, "SELECT * FROM bookings WHERE id=$id");
$bk = mysqli_fetch_assoc($res);

if (!$bk) { die('Booking not found'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pickup_address = mysqli_real_escape_string($conn, $_POST['pickup_address'] ?? '');
    $drop_address   = mysqli_real_escape_string($conn, $_POST['drop_address'] ?? '');
    $stops          = $_POST['stops'] ?? [];
    $stops_json     = mysqli_real_escape_string($conn, json_encode(array_values(array_filter($stops))));
    $distance_km    = (float)($_POST['distance_km'] ?? 0);
    $advance_amount = (float)($_POST['advance_amount'] ?? 0);
    $total_amount   = (float)($_POST['total_amount'] ?? 0);
    $status         = mysqli_real_escape_string($conn, $_POST['status'] ?? 'Pending');

    $q = "UPDATE bookings SET pickup_address='$pickup_address', drop_address='$drop_address', stops_json='$stops_json',
          distance_km=$distance_km, advance_amount=$advance_amount, total_amount=$total_amount, status='$status'
          WHERE id=$id";
    mysqli_query($conn, $q) or die(mysqli_error($conn));
    header('Location: /admin/bookings.php?msg=updated');
    exit;
}

$stops = json_decode($bk['stops_json'] ?? '[]', true) ?: [];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Booking</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-5xl mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Edit Booking #<?php echo htmlspecialchars($bk['booking_no']); ?></h1>

    <form method="post" class="space-y-4 bg-white p-6 rounded-xl shadow">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="block text-sm mb-1">Advance Amount</label>
          <input name="advance_amount" type="number" step="0.01" class="w-full border rounded px-3 py-2" value="<?php echo (float)$bk['advance_amount'];?>">
        </div>
        <div>
          <label class="block text-sm mb-1">Total Amount</label>
          <input name="total_amount" type="number" step="0.01" class="w-full border rounded px-3 py-2" value="<?php echo (float)$bk['total_amount'];?>">
        </div>
        <div>
          <label class="block text-sm mb-1">Distance (KM)</label>
          <input id="distance_km" name="distance_km" type="number" step="0.01" class="w-full border rounded px-3 py-2" value="<?php echo (float)$bk['distance_km'];?>">
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm mb-1">Pickup Address</label>
          <input id="pickup_address" name="pickup_address" class="w-full border rounded px-3 py-2" value="<?php echo htmlspecialchars($bk['pickup_address']);?>">
        </div>
        <div>
          <label class="block text-sm mb-1">Drop Address</label>
          <input id="drop_address" name="drop_address" class="w-full border rounded px-3 py-2" value="<?php echo htmlspecialchars($bk['drop_address']);?>">
        </div>
      </div>

      <div>
        <div class="flex items-center justify-between">
          <label class="block text-sm mb-2">Multiple Stops</label>
          <button type="button" id="add-stop" class="px-3 py-2 bg-gray-800 text-white rounded">+ Add Stop</button>
        </div>
        <div id="stops-wrap">
          <?php foreach($stops as $s): ?>
            <div class="mt-2 flex gap-2">
              <input name="stops[]" type="text" class="w-full border rounded px-3 py-2" value="<?php echo htmlspecialchars($s);?>">
              <button type="button" class="remove-stop px-3 py-2 bg-red-500 text-white rounded">×</button>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
        <div>
          <label class="block text-sm mb-1">Status</label>
          <select name="status" class="w-full border rounded px-3 py-2">
            <?php foreach(['Pending','In-Transit','Delivered','Cancelled'] as $st): ?>
            <option <?php echo $bk['status']===$st?'selected':'';?>><?php echo $st;?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="flex gap-2 md:col-span-2">
          <button type="button" id="calc-distance" class="px-4 py-2 bg-blue-600 text-white rounded">Auto-calc Distance</button>
          <button class="px-4 py-2 bg-green-600 text-white rounded">Update Booking</button>
        </div>
      </div>
    </form>
  </div>

  <script src="/modules/bookings/assets/bookings.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_DEMO_KEY&libraries=places"></script>
</body>
</html>
