<?php
require_once __DIR__ . '/_bootstrap.php';

// Form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_no  = $_POST['booking_no'] ?? '';
    $customer_id = $_POST['customer_id'] ?? '';
    $pickup      = $_POST['pickup'] ?? '';
    $drop        = $_POST['drop'] ?? '';
    $km          = $_POST['km'] ?? 0;
    $advance     = $_POST['advance'] ?? 0;
    $total       = $_POST['total'] ?? 0;
    $status      = $_POST['status'] ?? 'Pending';

    if ($booking_no && $customer_id && $pickup && $drop) {
        $stmt = $conn->prepare("INSERT INTO bookings (booking_no, customer_id, pickup, drop_location, km, advance, total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sissiiis", $booking_no, $customer_id, $pickup, $drop, $km, $advance, $total, $status);
        $stmt->execute();

        header("Location: index.php?msg=Booking+added+successfully");
        exit;
    } else {
        $error = "Required fields missing!";
    }
}

// Get customers for dropdown
$customers = $conn->query("SELECT id, name FROM customers");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Booking</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-3xl mx-auto p-6">
    <div class="flex items-center justify-between mb-4">
      <h1 class="text-2xl font-semibold">Add Booking</h1>
      <a href="index.php" class="px-4 py-2 bg-gray-600 text-white rounded">Back</a>
    </div>

    <?php if (!empty($error)): ?>
      <p class="text-red-600 mb-4"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" class="bg-white shadow rounded-xl p-6 space-y-4">

      <div>
        <label class="block mb-1 font-medium">Booking No</label>
        <input type="text" name="booking_no" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Customer</label>
        <select name="customer_id" class="w-full border px-3 py-2 rounded" required>
          <option value="">-- Select Customer --</option>
          <?php while ($c = $customers->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>

      <div>
        <label class="block mb-1 font-medium">Pickup</label>
        <input type="text" name="pickup" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Drop</label>
        <input type="text" name="drop" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">KM</label>
        <input type="number" name="km" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Advance</label>
        <input type="number" step="0.01" name="advance" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Total</label>
        <input type="number" step="0.01" name="total" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Status</label>
        <select name="status" class="w-full border px-3 py-2 rounded">
          <option value="Pending">Pending</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Save Booking</button>
    </form>
  </div>
</body>
</html>
