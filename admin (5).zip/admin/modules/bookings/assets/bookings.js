// modules/bookings/assets/bookings.js
(function() {
  const addStopBtn = document.getElementById('add-stop');
  const stopsWrap  = document.getElementById('stops-wrap');
  const calcBtn    = document.getElementById('calc-distance');
  const distanceEl = document.getElementById('distance_km');
  const pickupEl   = document.getElementById('pickup_address');
  const dropEl     = document.getElementById('drop_address');

  function createStopRow(i) {
    const row = document.createElement('div');
    row.className = 'mt-2 flex gap-2';
    row.innerHTML = `
      <input name="stops[]" type="text" placeholder="Extra stop address" class="w-full border rounded px-3 py-2">
      <button type="button" class="remove-stop px-3 py-2 bg-red-500 text-white rounded">×</button>
    `;
    return row;
  }

  addStopBtn?.addEventListener('click', function() {
    stopsWrap.appendChild(createStopRow(Date.now()));
  });

  stopsWrap?.addEventListener('click', function(e){
    if (e.target && e.target.classList.contains('remove-stop')) {
      e.target.parentElement.remove();
    }
  });

  function haversineKm(lat1, lon1, lat2, lon2) {
    function toRad(d){ return d * Math.PI / 180; }
    const R = 6371;
    const dLat = toRad(lat2-lat1);
    const dLon = toRad(lon2-lon1);
    const a = Math.sin(dLat/2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  async function geocode(addr) {
    // Try Google if available
    if (window.google && google.maps && google.maps.Geocoder) {
      return new Promise((resolve, reject) => {
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: addr }, (results, status) => {
          if (status === 'OK' && results[0]) {
            const loc = results[0].geometry.location;
            resolve({ lat: loc.lat(), lng: loc.lng() });
          } else {
            reject(status);
          }
        });
      });
    } else {
      // Fallback to Nominatim (may require CORS allowance on your host)
      const url = 'https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(addr);
      const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
      const data = await res.json();
      if (data && data.length > 0) {
        return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
      }
      throw new Error('Geocode failed');
    }
  }

  calcBtn?.addEventListener('click', async function(){
    const addresses = [pickupEl.value.trim(), ...Array.from(document.querySelectorAll('input[name="stops[]"]')).map(i=>i.value.trim()), dropEl.value.trim()].filter(Boolean);

    if (addresses.length < 2) {
      alert('Please enter at least Pickup and Drop addresses.');
      return;
    }

    try {
      // Prefer Google Distance Matrix if available
      if (window.google && google.maps && google.maps.DistanceMatrixService) {
        const svc = new google.maps.DistanceMatrixService();
        const origins = [addresses[0]];
        const destinations = addresses.slice(1);
        svc.getDistanceMatrix({
          origins, destinations,
          travelMode: google.maps.TravelMode.DRIVING,
          unitSystem: google.maps.UnitSystem.METRIC
        }, (res, status) => {
          if (status === 'OK' && res.rows && res.rows[0]) {
            let sum = 0;
            res.rows[0].elements.forEach(el => {
              if (el.status === 'OK') {
                sum += (el.distance.value || 0) / 1000.0;
              }
            });
            distanceEl.value = sum.toFixed(2);
          } else {
            alert('Google Distance API failed: ' + status);
          }
        });
      } else {
        // Fallback: geocode all and sum haversine
        const coords = [];
        for (let a of addresses) {
          coords.push(await geocode(a));
        }
        let sum = 0;
        for (let i=0;i<coords.length-1;i++){
          sum += haversineKm(coords[i].lat, coords[i].lng, coords[i+1].lat, coords[i+1].lng);
        }
        distanceEl.value = sum.toFixed(2);
      }
    } catch (e) {
      alert('Auto calculation failed. You can enter distance manually.\n' + e);
    }
  });
})();