<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$page_title = 'Quotations';
include __DIR__ . '/../../includes/header.php';

$res = $conn->query("SELECT id, customer_name, customer_phone, from_location, to_location, status, created_at FROM quotations ORDER BY id DESC");
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Quotations</h2>
    <a href="add.php" class="btn btn-primary">Add Quotation</a>
  </div>
  <div class="card">
    <div class="card-body table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Phone</th>
            <th>Route</th>
            <th>Status</th>
            <th>Created</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if($res && $res->num_rows): while($row=$res->fetch_assoc()): ?>
          <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['customer_name']) ?></td>
            <td><?= htmlspecialchars($row['customer_phone']) ?></td>
            <td><?= htmlspecialchars($row['from_location']) ?> → <?= htmlspecialchars($row['to_location']) ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <a class="btn btn-sm btn-secondary" href="view.php?id=<?= $row['id'] ?>">View</a>
              <a class="btn btn-sm btn-primary" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
              <a class="btn btn-sm btn-danger" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this quotation?')">Delete</a>
            </td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="7" class="text-center">No quotations.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
