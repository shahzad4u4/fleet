<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['customer_name']??'');
  $phone = trim($_POST['customer_phone']??'');
  $email = trim($_POST['customer_email']??'');
  $from = trim($_POST['from_location']??'');
  $to   = trim($_POST['to_location']??'');
  $vehicle = trim($_POST['vehicle_type']??'');
  $goods   = trim($_POST['goods_description']??'');
  $km = (float)($_POST['distance_km']??0);
  $notes = trim($_POST['notes']??'');
  $stops = isset($_POST['stops']) && is_array($_POST['stops']) ? $_POST['stops'] : [];

  if($name===''||$phone===''||$from===''||$to===''){
    $error = 'Required fields missing.';
  }else{
    $stmt = $conn->prepare("INSERT INTO quotations (customer_name, customer_phone, customer_email, from_location, to_location, vehicle_type, goods_description, distance_km, notes) VALUES (?,?,?,?,?,?,?,?,?)");
    if(!$stmt){ die('SQL error: '.$conn->error); }
    $stmt->bind_param('sssssssd s', $name,$phone,$email,$from,$to,$vehicle,$goods,$km,$notes);
    // Workaround for space in types (above), re-bind correctly:
    $stmt->bind_param('sssssssds', $name,$phone,$email,$from,$to,$vehicle,$goods,$km,$notes);
    $stmt->execute();
    $qid = $stmt->insert_id;
    $stmt->close();

    if($stops){
      $ins = $conn->prepare("INSERT INTO quotation_stops (quotation_id, stop_order, stop_name) VALUES (?,?,?)");
      $order=1;
      foreach($stops as $s){
        $s = trim($s);
        if($s==='') continue;
        $ins->bind_param('iis',$qid,$order,$s);
        $ins->execute();
        $order++;
      }
      $ins->close();
    }
    header('Location: index.php'); exit;
  }
}

$page_title = 'Add Quotation';
include __DIR__ . '/../../includes/header.php';
?>
<div class="container py-4">
  <h2><?= htmlspecialchars($page_title) ?></h2>
  <?php if(!empty($error)): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post">
    <div class="row g-3">
      <div class="col-md-4"><label class="form-label">Customer Name *</label><input name="customer_name" class="form-control" required></div>
      <div class="col-md-4"><label class="form-label">Phone *</label><input name="customer_phone" class="form-control" required></div>
      <div class="col-md-4"><label class="form-label">Email</label><input name="customer_email" type="email" class="form-control"></div>

      <div class="col-md-6"><label class="form-label">From *</label><input name="from_location" class="form-control" required></div>
      <div class="col-md-6"><label class="form-label">To *</label><input name="to_location" class="form-control" required></div>

      <div class="col-md-6"><label class="form-label">Vehicle Type</label><input name="vehicle_type" class="form-control"></div>
      <div class="col-md-6"><label class="form-label">Distance (KM)</label><input name="distance_km" type="number" step="0.1" class="form-control"></div>

      <div class="col-md-12"><label class="form-label">Goods Description</label><input name="goods_description" class="form-control"></div>
      <div class="col-md-12"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="3"></textarea></div>

      <div class="col-12"><label class="form-label">Stops (optional)</label>
        <div id="stopsWrap">
          <div class="input-group mb-2">
            <input name="stops[]" class="form-control" placeholder="Add stop e.g., Hyderabad">
            <button class="btn btn-outline-secondary" type="button" onclick="addStop()">+</button>
          </div>
        </div>
        <script>
          function addStop(){
            var d=document.createElement('div');
            d.className='input-group mb-2';
            d.innerHTML='<input name="stops[]" class="form-control" placeholder="Add stop"><button class="btn btn-outline-danger" type="button" onclick="this.parentNode.remove()">×</button>';
            document.getElementById('stopsWrap').appendChild(d);
          }
        </script>
      </div>

      <div class="col-12 text-end"><button class="btn btn-primary">Save</button></div>
    </div>
  </form>
</div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
