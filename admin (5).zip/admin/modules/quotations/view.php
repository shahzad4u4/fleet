<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$id = intval($_GET['id'] ?? 0);

$master = null; $stops = null;
if($id){
  $q = $conn->prepare("SELECT * FROM quotations WHERE id=?");
  $q->bind_param('i',$id); $q->execute(); $master = $q->get_result()->fetch_assoc(); $q->close();

  $s = $conn->prepare("SELECT stop_order, stop_name FROM quotation_stops WHERE quotation_id=? ORDER BY stop_order");
  $s->bind_param('i',$id); $s->execute(); $stops = $s->get_result();
}

$page_title = 'Quotation #'.$id;
include __DIR__ . '/../../includes/header.php';
?>
<div class="container py-4">
  <?php if(!$master): ?><div class="alert alert-danger">Quotation not found.</div>
  <?php else: ?>
  <div class="row g-3">
    <div class="col-md-6">
      <div class="card"><div class="card-header fw-bold">Customer</div><div class="card-body">
        <p class="mb-1"><strong><?= htmlspecialchars($master['customer_name']) ?></strong></p>
        <p class="mb-1"><?= htmlspecialchars($master['customer_phone']) ?> · <?= htmlspecialchars($master['customer_email']) ?></p>
      </div></div>
    </div>
    <div class="col-md-6">
      <div class="card"><div class="card-header fw-bold">Details</div><div class="card-body">
        <p class="mb-1">Vehicle: <?= htmlspecialchars($master['vehicle_type']) ?></p>
        <p class="mb-1">Goods: <?= htmlspecialchars($master['goods_description']) ?></p>
        <p class="mb-0">KM: <?= number_format((float)$master['distance_km'],1) ?> · Status: <strong><?= htmlspecialchars($master['status']) ?></strong></p>
      </div></div>
    </div>
    <div class="col-12">
      <div class="card"><div class="card-header fw-bold">Route</div><div class="card-body">
        <ol class="mb-0">
          <li><?= htmlspecialchars($master['from_location']) ?></li>
          <?php if($stops): while($r=$stops->fetch_assoc()): ?>
            <li><?= htmlspecialchars($r['stop_name']) ?></li>
          <?php endwhile; endif; ?>
          <li><?= htmlspecialchars($master['to_location']) ?></li>
        </ol>
      </div></div>
    </div>
    <div class="col-12">
      <a class="btn btn-primary" href="edit.php?id=<?= $id ?>">Approve / Reject</a>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
