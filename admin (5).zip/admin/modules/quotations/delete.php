<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$id = intval($_GET['id'] ?? 0);
if($id){
  $conn->query("DELETE FROM quotations WHERE id=".$id);
}
header('Location: index.php');
