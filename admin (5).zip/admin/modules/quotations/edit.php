<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$id = intval($_GET['id'] ?? 0);

if($_SERVER['REQUEST_METHOD']==='POST'){
  $status = $_POST['status'] ?? 'Pending';
  $stmt = $conn->prepare("UPDATE quotations SET status=? WHERE id=?");
  $stmt->bind_param('si',$status,$id);
  $stmt->execute();
  header('Location: view.php?id='.$id); exit;
}

$q = $conn->prepare("SELECT id,status FROM quotations WHERE id=?");
$q->bind_param('i',$id); $q->execute(); $data = $q->get_result()->fetch_assoc(); $q->close();

$page_title = 'Edit Quotation #'.$id;
include __DIR__ . '/../../includes/header.php';
?>
<div class="container py-4">
  <?php if(!$data): ?><div class="alert alert-danger">Not found.</div>
  <?php else: ?>
  <form method="post" class="card p-3">
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="Pending"  <?= $data['status']=='Pending'?'selected':''; ?>>Pending</option>
        <option value="Approved" <?= $data['status']=='Approved'?'selected':''; ?>>Approved</option>
        <option value="Rejected" <?= $data['status']=='Rejected'?'selected':''; ?>>Rejected</option>
      </select>
    </div>
    <button class="btn btn-primary">Save</button>
  </form>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
