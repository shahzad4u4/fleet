<?php include 'db.php'; ?>

<h2>Trip List</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Vehicle</th>
        <th>Driver</th>
        <th>Pickup</th>
        <th>Drop</th>
        <th>Distance (KM)</th>
        <th>Fuel</th>
        <th>Toll</th>
        <th>Misc</th>
        <th>Total Expense</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

<?php
$sql = "SELECT t.*, v.reg_no, d.name as driver_name 
        FROM trips t 
        JOIN vehicles v ON t.vehicle_id = v.id 
        JOIN drivers d ON t.driver_id = d.id";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['reg_no']}</td>
            <td>{$row['driver_name']}</td>
            <td>{$row['pickup_location']}</td>
            <td>{$row['drop_location']}</td>
            <td>{$row['distance_km']}</td>
            <td>{$row['fuel_expense']}</td>
            <td>{$row['toll_expense']}</td>
            <td>{$row['misc_expense']}</td>
            <td>{$row['total_expense']}</td>
            <td>{$row['status']}</td>
            <td>
                <a href='edit_trip.php?id={$row['id']}'>Edit</a> | 
                <a href='delete_trip.php?id={$row['id']}'>Delete</a>
            </td>
          </tr>";
}
?>
</table>