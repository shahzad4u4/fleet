CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    driver_id INT NOT NULL,
    pickup_location VARCHAR(255) NOT NULL,
    drop_location VARCHAR(255) NOT NULL,
    start_date DATETIME,
    end_date DATETIME,
    distance_km DECIMAL(10,2),
    fuel_expense DECIMAL(10,2) DEFAULT 0,
    toll_expense DECIMAL(10,2) DEFAULT 0,
    misc_expense DECIMAL(10,2) DEFAULT 0,
    total_expense DECIMAL(10,2) GENERATED ALWAYS AS (fuel_expense + toll_expense + misc_expense) STORED,
    status ENUM('Planned','Ongoing','Completed','Cancelled') DEFAULT 'Planned',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE CASCADE
);