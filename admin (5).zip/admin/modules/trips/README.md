# Fleet Management - Trip Module

## Files
- schema.sql → Trips table (with fuel, toll, misc expense)
- add_trip.php → Form to add new trip
- trip_list.php → Show all trips
- db.php → Use the same connection file as other modules

## Setup
1. Import schema.sql into your MySQL database.
2. Copy add_trip.php and trip_list.php into your project folder.
3. Make sure vehicles and drivers modules are already set up (for dropdowns).
4. Open add_trip.php in browser to add a new trip.
5. Open trip_list.php to view all trips.
