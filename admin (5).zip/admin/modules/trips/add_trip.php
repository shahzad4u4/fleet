<?php include 'db.php'; ?>

<h2>Add New Trip</h2>
<form method="post">
    <label>Vehicle:</label>
    <select name="vehicle_id" required>
        <?php
        $vehicles = $conn->query("SELECT id, reg_no FROM vehicles");
        while($v = $vehicles->fetch_assoc()) {
            echo "<option value='{$v['id']}'>{$v['reg_no']}</option>";
        }
        ?>
    </select><br><br>

    <label>Driver:</label>
    <select name="driver_id" required>
        <?php
        $drivers = $conn->query("SELECT id, name FROM drivers");
        while($d = $drivers->fetch_assoc()) {
            echo "<option value='{$d['id']}'>{$d['name']}</option>";
        }
        ?>
    </select><br><br>

    <label>Pickup Location:</label>
    <input type="text" name="pickup_location" required><br><br>

    <label>Drop Location:</label>
    <input type="text" name="drop_location" required><br><br>

    <label>Start Date:</label>
    <input type="datetime-local" name="start_date"><br><br>

    <label>End Date:</label>
    <input type="datetime-local" name="end_date"><br><br>

    <label>Distance (KM):</label>
    <input type="number" step="0.01" name="distance_km"><br><br>

    <label>Fuel Expense:</label>
    <input type="number" step="0.01" name="fuel_expense"><br><br>

    <label>Toll Expense:</label>
    <input type="number" step="0.01" name="toll_expense"><br><br>

    <label>Misc Expense:</label>
    <input type="number" step="0.01" name="misc_expense"><br><br>

    <label>Status:</label>
    <select name="status">
        <option value="Planned">Planned</option>
        <option value="Ongoing">Ongoing</option>
        <option value="Completed">Completed</option>
        <option value="Cancelled">Cancelled</option>
    </select><br><br>

    <button type="submit" name="submit">Save Trip</button>
</form>

<?php
if(isset($_POST['submit'])){
    $sql = "INSERT INTO trips (vehicle_id, driver_id, pickup_location, drop_location, start_date, end_date, distance_km, fuel_expense, toll_expense, misc_expense, status) 
            VALUES ('{$_POST['vehicle_id']}','{$_POST['driver_id']}','{$_POST['pickup_location']}','{$_POST['drop_location']}','{$_POST['start_date']}','{$_POST['end_date']}','{$_POST['distance_km']}','{$_POST['fuel_expense']}','{$_POST['toll_expense']}','{$_POST['misc_expense']}','{$_POST['status']}')";

    if($conn->query($sql)){
        echo "✅ Trip Added Successfully!";
    } else {
        echo "❌ Error: " . $conn->error;
    }
}
?>