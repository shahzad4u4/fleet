
<?php
require 'db.php';
require 'notify.php';
$ok = send_email($conn, $_GET['to'] ?? 'test@example.com', 'Test Email', '<h3>Hello</h3><p>This is a test.</p>');
echo $ok ? 'Email sent (or queued)' : 'Email failed';
