
<?php
require 'db.php';
require 'notify.php';
$ok = send_sms($conn, $_GET['to'] ?? '03000000000', 'This is a test SMS');
echo $ok ? 'SMS sent (or queued)' : 'SMS failed';
