
<?php
include 'db.php';
$id = intval($_GET['id'] ?? 0);
$s = $conn->query("SELECT * FROM staff WHERE id=$id")->fetch_assoc();
if(!$s) die("Staff not found");
?>
<!DOCTYPE html>
<html>
<head>
  <title>ID Card - <?php echo htmlspecialchars($s['name']); ?></title>
  <style>
    body{font-family:Arial;margin:20px;background:#f3f4f6}
    .wrap{display:flex;justify-content:center}
    .card{
      width: 320px; height: 200px;
      background:#ffffff;
      border-radius:16px; border:1px solid #e5e7eb;
      box-shadow:0 6px 20px rgba(0,0,0,0.08);
      padding:12px; position:relative;
      background-image: radial-gradient(#e5f2ff 1px, transparent 1px);
      background-size: 10px 10px;
    }
    .brand{display:flex;align-items:center;gap:8px}
    .logo{width:28px;height:28px;border-radius:8px;background:#111827;display:inline-block}
    .company{font-weight:bold}
    .row{display:grid;grid-template-columns:84px 1fr;gap:12px;margin-top:10px}
    img.photo{width:84px;height:110px;object-fit:cover;border-radius:10px;border:1px solid #e5e7eb}
    .title{font-size:18px;font-weight:bold;margin:0}
    .muted{color:#374151;font-size:12px;margin:0}
    .field{font-size:13px;margin:2px 0}
    .footer{position:absolute;bottom:10px;left:12px;right:12px;display:flex;justify-content:space-between;font-size:12px;color:#374151}
    .btn{margin-top:16px;padding:8px 12px;border:1px solid #111827;background:#111827;color:#fff;border-radius:8px;text-decoration:none}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card" id="printable">
      <div class="brand">
        <span class="logo"></span>
        <span class="company">Your Company</span>
      </div>
      <div class="row">
        <div>
          <?php if($s['photo_path']){ ?>
            <img class="photo" src="<?php echo $s['photo_path']; ?>">
          <?php } else { ?>
            <div style="width:84px;height:110px;border:1px dashed #cbd5e1;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#9ca3af">No Photo</div>
          <?php } ?>
        </div>
        <div>
          <p class="title"><?php echo htmlspecialchars($s['name']); ?></p>
          <p class="muted"><?php echo htmlspecialchars($s['designation']); ?></p>
          <p class="field"><strong>ID:</strong> <?php echo htmlspecialchars($s['employee_id']); ?></p>
          <p class="field"><strong>Phone:</strong> <?php echo htmlspecialchars($s['phone']); ?></p>
          <p class="field"><strong>WhatsApp:</strong> <?php echo htmlspecialchars($s['whatsapp']); ?></p>
        </div>
      </div>
      <div class="footer">
        <span>Authorized Sign</span>
        <span>www.example.com</span>
      </div>
    </div>
  </div>
  <div style="text-align:center">
    <button class="btn" onclick="window.print()">Print / Save as PDF</button>
    <a class="btn" href="staff_idcard_pdf.php?id=<?php echo $s['id']; ?>" target="_blank">Download PDF</a>
  </div>
</body>
</html>
