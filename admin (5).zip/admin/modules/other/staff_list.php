
<?php
include 'db.php';
$res = $conn->query("SELECT * FROM staff ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Staff List</title>
  <style>
    body{font-family:Arial;margin:20px;background:#f6f8fb}
    .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{border:1px solid #e5e7eb;padding:10px;text-align:center}
    th{background:#111827;color:#fff}
    img.thumb{width:48px;height:48px;border-radius:8px;object-fit:cover}
    .btn{padding:6px 10px;border-radius:6px;border:1px solid #0ea5e9;background:#0ea5e9;color:#fff;text-decoration:none;margin-right:6px}
    .btn.gray{background:#6b7280;border-color:#6b7280}
    .btn.red{background:#ef4444;border-color:#ef4444}
    .btn.green{background:#10b981;border-color:#10b981}
  </style>
</head>
<body>
  <div class="top">
    <h2>Staff List</h2>
    <div>
      <a class="btn" href="staff_add.php">+ Add Staff</a>
    </div>
  </div>
  <table>
    <tr>
      <th>ID</th><th>Photo</th><th>Name</th><th>Emp ID</th><th>Designation</th><th>Phone</th><th>Role</th><th>Actions</th>
    </tr>
    <?php while($s = $res->fetch_assoc()){ ?>
      <tr>
        <td><?php echo $s['id']; ?></td>
        <td><?php if($s['photo_path']){ ?><img class="thumb" src="<?php echo $s['photo_path']; ?>"><?php } ?></td>
        <td><?php echo htmlspecialchars($s['name']); ?></td>
        <td><?php echo htmlspecialchars($s['employee_id']); ?></td>
        <td><?php echo htmlspecialchars($s['designation']); ?></td>
        <td><?php echo htmlspecialchars($s['phone']); ?></td>
        <td><?php echo htmlspecialchars($s['role']); ?></td>
        <td>
          <a class="btn gray" href="staff_edit.php?id=<?php echo $s['id']; ?>">Edit</a>
          <a class="btn red" href="staff_delete.php?id=<?php echo $s['id']; ?>" onclick="return confirm('Delete this staff?')">Delete</a>
          <a class="btn green" href="staff_idcard.php?id=<?php echo $s['id']; ?>" target="_blank">ID Card</a>
        </td>
      </tr>
    <?php } ?>
  </table>
</body>
</html>
