
<?php
include 'db.php';
$id = intval($_GET['id'] ?? 0);
$conn->query("DELETE FROM staff WHERE id=$id");
header("Location: staff_list.php");
exit;
?>
