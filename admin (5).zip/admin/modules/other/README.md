
# Staff Module (with Photo Upload & ID Card PDF)

## Tables
- `schema.sql` -> run in MySQL to create `staff` table.

## Files
- `staff_add.php` — Add staff with photo upload.
- `staff_list.php` — List + actions (Edit/Delete/ID Card).
- `staff_edit.php` — Update staff details (can replace photo).
- `staff_delete.php` — Delete record.
- `staff_idcard.php` — Printable ID Card (browser print works).
- `staff_idcard_pdf.php` — DOMPDF-based PDF (optional).

## Setup
1. Import `schema.sql` in your DB.
2. Place files where `db.php` exists.
3. Ensure folder `uploads/staff/` is writable by PHP (create it if not exists).
4. (Optional) Install PDF lib:
   ```bash
   composer require dompdf/dompdf
   ```

## Notes
- Accepted photo types: JPG, PNG, WEBP. Max size 2 MB.
- You can customize company logo/name and ID card theme inside `staff_idcard.php`.
