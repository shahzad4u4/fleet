
<?php
$trip = htmlspecialchars($data['trip_no'] ?? '');
$status = htmlspecialchars($data['status'] ?? 'Completed');
?>
<div style="font-family:Arial;padding:10px">
  <h3>Trip Update</h3>
  <p>Your trip <?=$trip?> is <?=$status?>.</p>
</div>
