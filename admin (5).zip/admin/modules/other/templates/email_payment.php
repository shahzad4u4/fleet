
<?php
$amount = htmlspecialchars($data['amount'] ?? '');
$ref = htmlspecialchars($data['payment_ref'] ?? '');
?>
<div style="font-family:Arial;padding:10px">
  <h3>Payment Received</h3>
  <p>We have received your payment of <?=$amount?>. Ref: <?=$ref?>.</p>
</div>
