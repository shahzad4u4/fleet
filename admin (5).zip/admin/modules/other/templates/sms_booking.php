Your booking is confirmed. Ref: {{booking_no}}. Thank you.
