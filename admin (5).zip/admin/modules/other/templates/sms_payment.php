Payment received: {{amount}}. Ref: {{payment_ref}}.
