
<?php
$booking_no = $data['consignment_no'] ?? ($data['booking_no'] ?? '');
$customer   = htmlspecialchars($data['customer'] ?? '');
$route      = htmlspecialchars(($data['from'] ?? '').' → '.($data['to'] ?? ''));
$vehicle    = htmlspecialchars($data['vehicle'] ?? '');
$delivery   = htmlspecialchars($data['delivery_date'] ?? '');
?>
<div style="font-family:Arial;padding:10px">
  <h3>Your booking is confirmed</h3>
  <p>Dear <?=$customer?>, your booking <strong><?=$booking_no?></strong> is confirmed.</p>
  <p>Route: <?=$route?><br>Vehicle: <?=$vehicle?><br>Delivery Date: <?=$delivery?></p>
  <p>Thank you for choosing us.</p>
</div>
