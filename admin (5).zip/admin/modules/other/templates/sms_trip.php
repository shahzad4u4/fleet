Trip {{trip_no}} {{status}}.
