
<?php
$inv = htmlspecialchars($data['invoice_no'] ?? '');
$amount = htmlspecialchars($data['amount'] ?? '');
?>
<div style="font-family:Arial;padding:10px">
  <h3>Invoice Generated</h3>
  <p>Your invoice <strong><?=$inv?></strong> has been generated for amount <?=$amount?>.</p>
</div>
