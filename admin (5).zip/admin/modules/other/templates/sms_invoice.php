Invoice {{invoice_no}} generated. Amount: {{amount}}.
