
<?php
session_start();
$config = require __DIR__.'/../config/config.php';
require __DIR__.'/../app/helpers.php';
require __DIR__.'/../app/router.php';
