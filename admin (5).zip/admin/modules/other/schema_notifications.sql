
-- Notifications & Settings schema

CREATE TABLE IF NOT EXISTS notification_settings (
  id INT PRIMARY KEY DEFAULT 1,
  email_enabled TINYINT(1) DEFAULT 1,
  sms_enabled TINYINT(1) DEFAULT 0,
  smtp_host VARCHAR(150),
  smtp_port INT DEFAULT 587,
  smtp_secure ENUM('none','tls','ssl') DEFAULT 'tls',
  smtp_username VARCHAR(150),
  smtp_password VARCHAR(200),
  from_email VARCHAR(150),
  from_name VARCHAR(150),
  sms_api_url VARCHAR(255),
  sms_api_key VARCHAR(255),
  sms_sender_id VARCHAR(50),
  booking_notify TINYINT(1) DEFAULT 1,
  invoice_notify TINYINT(1) DEFAULT 1,
  payment_notify TINYINT(1) DEFAULT 1,
  trip_notify TINYINT(1) DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO notification_settings (id, email_enabled, sms_enabled, smtp_host, smtp_port, smtp_secure, smtp_username, smtp_password, from_email, from_name, sms_api_url, sms_api_key, sms_sender_id) VALUES
(1, 0, 0, NULL, 587, 'tls', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ON DUPLICATE KEY UPDATE id=id;

CREATE TABLE IF NOT EXISTS notifications_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('booking','invoice','payment','trip') NOT NULL,
  channel ENUM('email','sms') NOT NULL,
  recipient VARCHAR(150) NOT NULL,
  subject VARCHAR(200),
  message TEXT,
  status ENUM('queued','sent','failed') DEFAULT 'queued',
  error TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
