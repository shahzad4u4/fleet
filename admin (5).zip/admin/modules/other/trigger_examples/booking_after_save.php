
<?php
// Example usage inside booking_save.php AFTER insert success
require_once __DIR__ . '/../notify.php';

// Build data from your booking/customer tables
$data = [
  'email'          => $customer_email,   // define from your context
  'phone'          => $customer_phone,   // define from your context
  'customer'       => $customer_name,
  'consignment_no' => $consignment_no,
  'from'           => $from_location,
  'to'             => $to_location,
  'vehicle'        => $vehicle_no,
  'delivery_date'  => $delivery_date,
];

notify_trigger($conn, 'booking', $data);
