
<?php
require_once __DIR__ . '/../notify.php';

$data = [
  'email'       => $customer_email,
  'phone'       => $customer_phone,
  'amount'      => $amount,
  'payment_ref' => $payment_ref,
];

notify_trigger($conn, 'payment', $data);
