
<?php
// DOMPDF-based PDF for ID Card
$id = intval($_GET['id'] ?? 0);

if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
  echo "<p style='font-family:Arial'>❗ DOMPDF not installed.<br>
        Run <code>composer require dompdf/dompdf</code> in your project root, then revisit this page.<br>
        Alternatively, open <code>staff_idcard.php?id=$id</code> and use <b>Print / Save as PDF</b>.</p>";
  exit;
}
require __DIR__ . '/vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;
include 'db.php';

$s = $conn->query("SELECT * FROM staff WHERE id=$id")->fetch_assoc();
if(!$s) die("Staff not found");

ob_start();
include 'staff_idcard.php';
$html = ob_get_clean();

// Capture only the card
if (preg_match('/<div class=\"card\".*?<\/div>/s', $html, $m)) {
  $html = '<html><head><meta charset=\"utf-8\"></head><body>'.$m[0].'</body></html>';
}

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A7', 'landscape'); // near ID-card size
$dompdf->render();
$dompdf->stream('staff-id-'.$s['id'].'.pdf');
