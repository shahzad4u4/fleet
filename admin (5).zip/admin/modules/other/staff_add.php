<?php
include 'db.php';

function handle_photo_upload($fieldName = 'photo', $destDir = 'uploads/staff/') {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (!is_dir($destDir)) {
        @mkdir($destDir, 0777, true);
    }
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $type = mime_content_type($_FILES[$fieldName]['tmp_name']);
    if (!isset($allowed[$type])) {
        throw new Exception("Invalid image type. Allowed: JPG, PNG, WEBP");
    }
    if ($_FILES[$fieldName]['size'] > 2*1024*1024) {
        throw new Exception("File too large. Max 2MB");
    }
    $ext = $allowed[$type];
    $newName = uniqid('staff_', true).'.'.$ext;
    $target = rtrim($destDir,'/').'/'.$newName;
    if (!move_uploaded_file($_FILES[$fieldName]['tmp_name'], $target)) {
        throw new Exception("Failed to save file");
    }
    return $target;
}


$error = ""; $ok = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = $_POST['name'];
        $employee_id = $_POST['employee_id'];
        $designation = $_POST['designation'];
        $phone = $_POST['phone'];
        $whatsapp = $_POST['whatsapp'];
        $address = $_POST['address'];
        $role = $_POST['role'];
        $photo_path = handle_photo_upload('photo');

        $stmt = $conn->prepare("INSERT INTO staff (name, employee_id, designation, phone, whatsapp, address, role, photo_path) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param("ssssssss", $name, $employee_id, $designation, $phone, $whatsapp, $address, $role, $photo_path);
        if ($stmt->execute()) { $ok = "Staff added successfully."; }
        else { $error = "DB Error: " . $conn->error; }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Staff</title>
  <style>
    body{font-family:Arial;margin:20px;background:#f6f8fb}
    .card{max-width:800px;margin:auto;background:#fff;padding:20px;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.05)}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
    label{font-weight:bold;margin-top:10px;display:block}
    input,select,textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .actions{margin-top:16px;display:flex;gap:10px}
    .btn{padding:10px 16px;border-radius:8px;border:1px solid #0ea5e9;background:#0ea5e9;color:#fff;cursor:pointer}
    .btn-outline{background:#fff;color:#0ea5e9}
    .alert{padding:10px;border-radius:8px;margin-bottom:10px}
    .success{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
    .error{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
  </style>
</head>
<body>
  <div class="card">
    <h2>Add Staff</h2>
    <?php if($ok) echo "<div class='alert success'>$ok</div>"; ?>
    <?php if($error) echo "<div class='alert error'>$error</div>"; ?>
    <form method="post" enctype="multipart/form-data">
      <div class="row">
        <div>
          <label>Name</label>
          <input type="text" name="name" required>
        </div>
        <div>
          <label>Employee ID</label>
          <input type="text" name="employee_id" required>
        </div>
        <div>
          <label>Designation</label>
          <input type="text" name="designation">
        </div>
        <div>
          <label>Phone</label>
          <input type="text" name="phone">
        </div>
        <div>
          <label>WhatsApp</label>
          <input type="text" name="whatsapp">
        </div>
        <div>
          <label>Role</label>
          <select name="role">
            <option value="staff">Staff</option>
            <option value="admin">Admin</option>
            <option value="driver">Driver</option>
            <option value="accountant">Accountant</option>
          </select>
        </div>
      </div>
      <label>Address</label>
      <textarea name="address" rows="3"></textarea>

      <label>Photo (JPG/PNG/WEBP, Max 2MB)</label>
      <input type="file" name="photo" accept="image/*">

      <div class="actions">
        <button class="btn" type="submit">Save</button>
        <a class="btn btn-outline" href="staff_list.php" style="text-decoration:none;display:inline-block;padding:10px 16px;">Back to List</a>
      </div>
    </form>
  </div>
</body>
</html>
