
<?php /* app/views/home.php */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($title) ?></title>
<link rel="stylesheet" href="/hslogistics/public/css/app.css">
</head>
<body>
<div class="header">
  <img src="/hslogistics/public/uploads/logo.png" alt="logo">
  <div>
    <div style="font-weight:700;font-size:1.1rem">HS Logistics</div>
    <div style="opacity:.85">Fast, Reliable & Secure</div>
  </div>
</div>
<div class="container">
  <div class="card">
    <h2 style="margin-top:0">Public Booking</h2>
    <form method="post" action="/hslogistics/admin">
      <?php csrf_field(); ?>
      <div class="grid grid-2">
        <div><label>Name</label><input name="name" required></div>
        <div><label>Phone</label><input name="phone" required></div>
        <div><label>Pickup</label><input name="pickup" required></div>
        <div><label>Destination</label><input name="destination" required></div>
        <div><label>Vehicle Type</label>
          <select name="vehicle"><option>10ft Truck</option><option>14ft Truck</option><option>18ft Truck</option><option>20ft Container</option></select>
        </div>
        <div><label>Weight (kg)</label><input type="number" name="weight" min="1" required></div>
      </div>
      <div style="margin-top:12px"><button class="btn">Submit</button></div>
    </form>
  </div>

  <div class="card">
    <h3 style="margin-top:0">What’s included</h3>
    <ul>
      <li>Customer & Staff roles with login</li>
      <li>Staff ID cards with your logo</li>
      <li>Invoice on company letterhead (PDF/Print)</li>
      <li>Bilty image upload, hired vehicle details, payments</li>
      <li>Salaries, expenses, and dashboards</li>
      <li>SMS / WhatsApp / Google Maps API pluggable</li>
    </ul>
  </div>
</div>
</body>
</html>
