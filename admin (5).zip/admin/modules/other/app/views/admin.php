
<?php /* app/views/admin.php */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($title) ?></title>
<link rel="stylesheet" href="/hslogistics/public/css/app.css">
</head>
<body>
<div class="header">
  <img src="/hslogistics/public/uploads/logo.png" alt="logo">
  <div>
    <div style="font-weight:700;font-size:1.1rem">HS Logistics — Admin</div>
    <div style="opacity:.85">Secure Panel</div>
  </div>
</div>
<div class="container">
  <div class="grid grid-2">
    <div class="card">
      <h3 style="margin-top:0">Branding</h3>
      <p>Logo already applied. Go to Settings in full build to change.</p>
      <img src="/hslogistics/public/uploads/logo.png" style="max-width:240px">
      <p class="status-ok">PNG with transparent background ✓</p>
    </div>
    <div class="card">
      <h3 style="margin-top:0">Next steps</h3>
      <ol>
        <li>Import DB schema and set credentials in <code>config/config.php</code></li>
        <li>Point your webroot to <code>public/</code></li>
        <li>Open <code>/hslogistics/</code> in browser</li>
      </ol>
    </div>
  </div>
</div>
</body>
</html>
