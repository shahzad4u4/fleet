
<?php
check_csrf();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');
if ($uri === '' || $uri === '/hslogistics' || $uri === '/hslogistics/') {
  view('home', ['title' => 'HS Logistics']);
  return;
}
if ($uri === '/hslogistics/admin') { view('admin', ['title' => 'Admin']); return; }
http_response_code(404);
echo "404 Not Found";
