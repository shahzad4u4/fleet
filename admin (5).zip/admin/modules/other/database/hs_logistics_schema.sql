
-- Minimal schema skeleton (extendable)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('admin','staff','customer') NOT NULL DEFAULT 'customer',
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(30),
  password_hash VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(100), phone VARCHAR(30),
  pickup VARCHAR(200), destination VARCHAR(200),
  vehicle VARCHAR(50), weight_kg INT,
  bilty_path VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(50) PRIMARY KEY, v TEXT
);
INSERT IGNORE INTO settings (k, v) VALUES ('company_name', 'HS Logistics');

INSERT INTO users (role, name, email, phone, password_hash, created_at) VALUES
('admin', 'Administrator', 'admin@example.com', '03000000000', MD5('admin123'), NOW());
