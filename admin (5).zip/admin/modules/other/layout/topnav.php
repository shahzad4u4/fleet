
<?php $user = $_SESSION['user'] ?? null; ?>
<!-- Topbar -->
<header class="flex items-center justify-between bg-white border-b border-slate-200 px-4 py-3 md:ml-64 sticky top-0 z-20">
  <div class="flex items-center gap-2">
    <button class="md:hidden px-3 py-2 rounded-lg border" onclick="toggleSidebar()">☰</button>
    <div class="font-semibold"><?= isset($page_title) ? $page_title : 'Dashboard' ?></div>
  </div>
  <div class="flex items-center gap-3 text-sm">
    <?php if($user){ ?>
      <span class="hidden sm:inline text-slate-600"><?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['role']) ?>)</span>
      <a href="logout.php" class="px-3 py-1.5 rounded-lg border hover:bg-slate-50">Logout</a>
    <?php } else { ?>
      <a href="login.php" class="px-3 py-1.5 rounded-lg border hover:bg-slate-50">Login</a>
    <?php } ?>
  </div>
</header>
