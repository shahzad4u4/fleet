
<?php
$page_title = "Dashboard";
include __DIR__ . "/layout/header.php";
include __DIR__ . "/layout/sidebar.php";
include __DIR__ . "/layout/topnav.php";
?>
<main class="p-4 md:ml-64">
  <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
    <?php
      $cards = [
        ['title'=>'Vehicles','value'=>'128','desc'=>'Active Fleet'],
        ['title'=>'Drivers','value'=>'54','desc'=>'On duty'],
        ['title'=>'Trips','value'=>'23','desc'=>'Today'],
        ['title'=>'Bookings','value'=>'76','desc'=>'This week'],
        ['title'=>'Payments','value'=>'PKR 1.2M','desc'=>'This month'],
        ['title'=>'Expenses','value'=>'PKR 0.8M','desc'=>'This month'],
      ];
      foreach($cards as $c){
        echo '<div class="bg-white border border-slate-200 rounded-2xl p-4">';
        echo '<div class="text-slate-500 text-sm">'.$c['title'].'</div>';
        echo '<div class="text-2xl font-bold">'.$c['value'].'</div>';
        echo '<div class="text-xs text-slate-400 mt-1">'.$c['desc'].'</div>';
        echo '</div>';
      }
    ?>
  </div>

  <div class="mt-6 bg-white border border-slate-200 rounded-2xl p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-semibold">Recent Bookings</h3>
      <div>
        <input class="border rounded-lg px-3 py-1.5 text-sm" placeholder="Search...">
      </div>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-[720px] w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-3 py-2">#</th>
            <th class="text-left px-3 py-2">Consignment</th>
            <th class="text-left px-3 py-2">Customer</th>
            <th class="text-left px-3 py-2">Route</th>
            <th class="text-left px-3 py-2">Freight</th>
            <th class="text-left px-3 py-2">Status</th>
            <th class="text-left px-3 py-2">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php for($i=1;$i<=8;$i++): ?>
          <tr class="border-t">
            <td class="px-3 py-2">B<?=$i?></td>
            <td class="px-3 py-2">CN-10<?=$i?></td>
            <td class="px-3 py-2">Customer <?=$i?></td>
            <td class="px-3 py-2">KHI → LHR</td>
            <td class="px-3 py-2">PKR <?= 50000 + $i*1000 ?></td>
            <td class="px-3 py-2"><span class="px-2 py-1 rounded-full text-xs bg-emerald-50 text-emerald-700 border border-emerald-200">Confirmed</span></td>
            <td class="px-3 py-2"><a href="#" class="px-3 py-1.5 border rounded-lg hover:bg-slate-50">View</a></td>
          </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include __DIR__ . "/layout/footer.php"; ?>
