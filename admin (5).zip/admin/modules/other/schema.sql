
CREATE TABLE IF NOT EXISTS staff (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  employee_id VARCHAR(50) UNIQUE NOT NULL,
  designation VARCHAR(100),
  phone VARCHAR(50),
  whatsapp VARCHAR(50),
  address TEXT,
  role ENUM('admin','staff','driver','accountant') DEFAULT 'staff',
  photo_path VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
