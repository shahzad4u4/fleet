
<?php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'logistics_db',
    'user' => 'root',
    'pass' => ''
  ],
  'app' => [
    'base_url' => 'http://localhost/hslogistics',
    'locale' => 'en',
    'allow_public_booking' => true
  ],
  'security' => [
    'session_name' => 'hs_session',
    'csrf_key' => 'change_this_random_key',
    'upload_max_size' => 5242880
  ]
];
