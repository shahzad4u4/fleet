
<?php
require 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $fields = ['email_enabled','sms_enabled','smtp_host','smtp_port','smtp_secure','smtp_username','smtp_password','from_email','from_name','sms_api_url','sms_api_key','sms_sender_id','booking_notify','invoice_notify','payment_notify','trip_notify'];
  $vals = [];
  foreach($fields as $f){ $vals[$f] = $_POST[$f] ?? null; }

  $stmt = $conn->prepare("REPLACE INTO notification_settings (id,email_enabled,sms_enabled,smtp_host,smtp_port,smtp_secure,smtp_username,smtp_password,from_email,from_name,sms_api_url,sms_api_key,sms_sender_id,booking_notify,invoice_notify,payment_notify,trip_notify) VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->bind_param("iississssssssiiii",
    $vals['email_enabled'],
    $vals['sms_enabled'],
    $vals['smtp_host'],
    $vals['smtp_port'],
    $vals['smtp_secure'],
    $vals['smtp_username'],
    $vals['smtp_password'],
    $vals['from_email'],
    $vals['from_name'],
    $vals['sms_api_url'],
    $vals['sms_api_key'],
    $vals['sms_sender_id'],
    $vals['booking_notify'],
    $vals['invoice_notify'],
    $vals['payment_notify'],
    $vals['trip_notify']
  );
  $stmt->execute();
  $saved = true;
}
$settings = $conn->query("SELECT * FROM notification_settings WHERE id=1")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Notification Settings</title>
  <style>
    body{font-family:Arial;margin:20px;background:#f6f8fb}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;max-width:900px}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    label{font-weight:bold;display:block;margin-top:8px}
    input,select{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .btn{margin-top:12px;padding:10px 14px;border-radius:8px;border:1px solid #111827;background:#111827;color:#fff;cursor:pointer}
    .ok{padding:10px;background:#dcfce7;border:1px solid #86efac;border-radius:8px;margin-bottom:8px}
  </style>
</head>
<body>
  <div class="card">
    <h2>Notification Settings</h2>
    <?php if(!empty($saved)) echo "<div class='ok'>Saved.</div>"; ?>
    <form method="post">
      <div class="grid">
        <div>
          <label>Email Enabled</label>
          <select name="email_enabled"><option value="1" <?=($settings['email_enabled']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['email_enabled']?'selected':'')?>>No</option></select>
        </div>
        <div>
          <label>SMS Enabled</label>
          <select name="sms_enabled"><option value="1" <?=($settings['sms_enabled']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['sms_enabled']?'selected':'')?>>No</option></select>
        </div>
        <div>
          <label>SMTP Host</label>
          <input name="smtp_host" value="<?=htmlspecialchars($settings['smtp_host']??'')?>">
        </div>
        <div>
          <label>SMTP Port</label>
          <input name="smtp_port" type="number" value="<?=htmlspecialchars($settings['smtp_port']??587)?>">
        </div>
        <div>
          <label>SMTP Secure</label>
          <select name="smtp_secure">
            <option value="none" <?=(($settings['smtp_secure']??'tls')==='none'?'selected':'')?>>None</option>
            <option value="tls" <?=(($settings['smtp_secure']??'tls')==='tls'?'selected':'')?>>TLS</option>
            <option value="ssl" <?=(($settings['smtp_secure']??'tls')==='ssl'?'selected':'')?>>SSL</option>
          </select>
        </div>
        <div>
          <label>SMTP Username</label>
          <input name="smtp_username" value="<?=htmlspecialchars($settings['smtp_username']??'')?>">
        </div>
        <div>
          <label>SMTP Password</label>
          <input name="smtp_password" type="password" value="<?=htmlspecialchars($settings['smtp_password']??'')?>">
        </div>
        <div>
          <label>From Email</label>
          <input name="from_email" value="<?=htmlspecialchars($settings['from_email']??'')?>">
        </div>
        <div>
          <label>From Name</label>
          <input name="from_name" value="<?=htmlspecialchars($settings['from_name']??'Fleet System')?>">
        </div>
        <div>
          <label>SMS API URL</label>
          <input name="sms_api_url" value="<?=htmlspecialchars($settings['sms_api_url']??'')?>">
        </div>
        <div>
          <label>SMS API Key</label>
          <input name="sms_api_key" value="<?=htmlspecialchars($settings['sms_api_key']??'')?>">
        </div>
        <div>
          <label>SMS Sender ID</label>
          <input name="sms_sender_id" value="<?=htmlspecialchars($settings['sms_sender_id']??'')?>">
        </div>
        <div>
          <label>Notify on Booking</label>
          <select name="booking_notify"><option value="1" <?=($settings['booking_notify']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['booking_notify']?'selected':'')?>>No</option></select>
        </div>
        <div>
          <label>Notify on Invoice</label>
          <select name="invoice_notify"><option value="1" <?=($settings['invoice_notify']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['invoice_notify']?'selected':'')?>>No</option></select>
        </div>
        <div>
          <label>Notify on Payment</label>
          <select name="payment_notify"><option value="1" <?=($settings['payment_notify']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['payment_notify']?'selected':'')?>>No</option></select>
        </div>
        <div>
          <label>Notify on Trip Complete</label>
          <select name="trip_notify"><option value="1" <?=($settings['trip_notify']?'selected':'')?>>Yes</option><option value="0" <?=(!$settings['trip_notify']?'selected':'')?>>No</option></select>
        </div>
      </div>
      <button class="btn" type="submit">Save</button>
    </form>
  </div>
</body>
</html>
