
<?php
$page_title = "Responsive Table Demo";
include __DIR__ . "/layout/header.php";
include __DIR__ . "/layout/sidebar.php";
include __DIR__ . "/layout/topnav.php";
?>
<main class="p-4 md:ml-64">
  <div class="bg-white border border-slate-200 rounded-2xl p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-semibold">Example Table</h3>
      <div class="flex gap-2">
        <button class="px-3 py-1.5 border rounded-lg hover:bg-slate-50">Export Excel</button>
        <button class="px-3 py-1.5 border rounded-lg hover:bg-slate-50">Export PDF</button>
      </div>
    </div>
    <div class="overflow-x-auto">
      <table class="min-w-[720px] w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-3 py-2">ID</th>
            <th class="text-left px-3 py-2">Name</th>
            <th class="text-left px-3 py-2">Category</th>
            <th class="text-left px-3 py-2">Amount</th>
            <th class="text-left px-3 py-2">Date</th>
            <th class="text-left px-3 py-2">Status</th>
            <th class="text-left px-3 py-2">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php for($i=1;$i<=12;$i++): ?>
          <tr class="border-t">
            <td class="px-3 py-2"><?= $i ?></td>
            <td class="px-3 py-2">Record <?= $i ?></td>
            <td class="px-3 py-2">Type <?= ($i%3)+1 ?></td>
            <td class="px-3 py-2">PKR <?= number_format(10000+$i*700) ?></td>
            <td class="px-3 py-2"><?= date('Y-m-d') ?></td>
            <td class="px-3 py-2">
              <span class="px-2 py-1 rounded-full text-xs bg-amber-50 text-amber-700 border border-amber-200">Pending</span>
            </td>
            <td class="px-3 py-2">
              <button class="px-3 py-1.5 border rounded-lg hover:bg-slate-50">View</button>
            </td>
          </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include __DIR__ . "/layout/footer.php"; ?>
