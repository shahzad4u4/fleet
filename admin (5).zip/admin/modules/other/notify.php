
<?php
// Simple notification helper (email via SMTP or mail(); SMS via HTTP POST)
// Requires: a $conn mysqli connection (from db.php) and tables from schema_notifications.sql

function notif_get_settings($conn){
  $res = $conn->query("SELECT * FROM notification_settings WHERE id=1");
  return $res && $res->num_rows ? $res->fetch_assoc() : null;
}

function log_notification($conn, $type, $channel, $recipient, $subject, $message, $status, $error=''){
  $stmt = $conn->prepare("INSERT INTO notifications_log (type, channel, recipient, subject, message, status, error) VALUES (?,?,?,?,?,?,?)");
  $stmt->bind_param("sssssss", $type, $channel, $recipient, $subject, $message, $status, $error);
  $stmt->execute();
}

function send_email($conn, $to, $subject, $html){
  $s = notif_get_settings($conn);
  if(!$s || !$s['email_enabled']) return false;

  $from = $s['from_email'] ?: 'no-reply@example.com';
  $fromName = $s['from_name'] ?: 'Fleet System';

  // If SMTP creds exist, try SMTP via fsockopen (basic). Otherwise fallback to mail().
  $ok = false; $error = '';

  if(!empty($s['smtp_host']) && !empty($s['smtp_username']) && !empty($s['smtp_password'])){
    // Very simple SMTP using PHPMail headers + mail() as fallback, because raw SMTP is complex.
    // We'll try PHP's mail() with proper headers first.
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: ".$fromName." <".$from.">\r\n";
    $headers .= "Reply-To: ".$from."\r\n";
    $ok = @mail($to, $subject, $html, $headers);
    if(!$ok){ $error = 'mail() failed; please configure a proper SMTP library like PHPMailer.'; }
  } else {
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: ".$fromName." <".$from.">\r\n";
    $headers .= "Reply-To: ".$from."\r\n";
    $ok = @mail($to, $subject, $html, $headers);
    if(!$ok){ $error = 'mail() failed; no SMTP configured.'; }
  }

  log_notification($conn, 'booking', 'email', $to, $subject, $html, $ok ? 'sent' : 'failed', $ok ? '' : $error);
  return $ok;
}

function send_sms($conn, $to, $text){
  $s = notif_get_settings($conn);
  if(!$s || !$s['sms_enabled']) return false;

  $url = $s['sms_api_url'];
  if(!$url){ log_notification($conn, 'booking', 'sms', $to, '', $text, 'failed', 'sms_api_url not set'); return false; }

  $payload = [
    'api_key' => $s['sms_api_key'],
    'sender'  => $s['sms_sender_id'],
    'to'      => $to,
    'message' => $text
  ];

  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $resp = curl_exec($ch);
  $err  = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  $ok = ($err=='' && $code>=200 && $code<300);
  log_notification($conn, 'booking', 'sms', $to, '', $text, $ok ? 'sent' : 'failed', $ok ? '' : ($err ?: ('HTTP '.$code.' '.$resp)));
  return $ok;
}

// Master trigger
function notify_trigger($conn, $type, $data){
  // $type: booking | invoice | payment | trip
  $s = notif_get_settings($conn);
  if(!$s){ return; }

  $map = [
    'booking' => 'booking_notify',
    'invoice' => 'invoice_notify',
    'payment' => 'payment_notify',
    'trip'    => 'trip_notify',
  ];
  if(isset($map[$type]) && intval($s[$map[$type]]) !== 1){ return; }

  // Prepare templates
  $email_to = $data['email'] ?? null;
  $phone_to = $data['phone'] ?? null;

  $subject = '';
  $html = '';
  $sms = '';

  ob_start();
  include __DIR__ . "/templates/email_{$type}.php";
  $html = ob_get_clean();

  ob_start();
  include __DIR__ . "/templates/sms_{$type}.php";
  $sms = trim(ob_get_clean());

  if($email_to){ send_email($conn, $email_to, "[Fleet] ".$type." notification", $html); }
  if($phone_to){ send_sms($conn, $phone_to, $sms); }
}
