<?php include 'db.php'; ?>

<h2>Add Payment</h2>
<form method="post">
    <label>Trip:</label>
    <select name="trip_id" required>
        <?php
        $trips = $conn->query("SELECT id, pickup_location, drop_location FROM trips");
        while($t = $trips->fetch_assoc()) {
            echo "<option value='{$t['id']}'>Trip #{$t['id']} - {$t['pickup_location']} → {$t['drop_location']}</option>";
        }
        ?>
    </select><br><br>

    <label>Amount:</label>
    <input type="number" step="0.01" name="amount" required><br><br>

    <label>Payment Date:</label>
    <input type="date" name="payment_date" required><br><br>

    <label>Method:</label>
    <select name="method">
        <option value="Cash">Cash</option>
        <option value="Bank">Bank</option>
        <option value="Online">Online</option>
    </select><br><br>

    <label>Status:</label>
    <select name="status">
        <option value="Pending">Pending</option>
        <option value="Paid">Paid</option>
    </select><br><br>

    <label>Notes:</label>
    <textarea name="notes"></textarea><br><br>

    <button type="submit" name="submit">Save Payment</button>
</form>

<?php
if(isset($_POST['submit'])){
    $sql = "INSERT INTO payments (trip_id, amount, payment_date, method, status, notes) 
            VALUES ('{$_POST['trip_id']}','{$_POST['amount']}','{$_POST['payment_date']}',
            '{$_POST['method']}','{$_POST['status']}','{$_POST['notes']}')";

    if($conn->query($sql)){
        echo "✅ Payment Added Successfully!";
    } else {
        echo "❌ Error: " . $conn->error;
    }
}
?>