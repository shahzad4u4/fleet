<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$page_title = 'Bilty Upload';
include __DIR__ . '/../../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['bilty'])) {
    $dir = __DIR__ . '/../../uploads/bilty/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $name = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['bilty']['name']);
    $path = $dir . $name;

    if (move_uploaded_file($_FILES['bilty']['tmp_name'], $path)) {
        $rel = '/uploads/bilty/' . $name;
        $stmt = $conn->prepare("INSERT INTO bilty (booking_id, file_path, notes) VALUES (?,?,?)");
        $booking_id = intval($_POST['booking_id'] ?? 0);
        $notes = $_POST['notes'] ?? '';
        $stmt->bind_param('iss', $booking_id, $rel, $notes);
        $stmt->execute();
        $success = "Bilty uploaded successfully!";
    } else {
        $error = "Upload failed.";
    }
}

$records = $conn->query("SELECT b.id, b.booking_id, b.file_path, b.notes, b.created_at FROM bilty b ORDER BY b.id DESC");
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Upload Bilty</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success"><?= $success ?></div>
                    <?php elseif (!empty($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Booking ID</label>
                            <input type="number" name="booking_id" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Select Bilty File</label>
                            <input type="file" name="bilty" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-success">Upload</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Records -->
        <div class="col-md-12 mt-4">
            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">Uploaded Bilty Records</h5>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Booking ID</th>
                                <th>Notes</th>
                                <th>File</th>
                                <th>Uploaded At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($records && $records->num_rows > 0): ?>
                                <?php while ($row = $records->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= $row['booking_id'] ?></td>
                                        <td><?= htmlspecialchars($row['notes']) ?></td>
                                        <td><a href="<?= $row['file_path'] ?>" target="_blank" class="btn btn-sm btn-primary">View</a></td>
                                        <td><?= $row['created_at'] ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center">No records found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
