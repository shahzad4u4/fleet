# Payment Module (Fleet System)

## Files
- schema.sql → Payments table
- db.php → Database connection
- add_payment.php → Add payment form
- payment_list.php → List payments

## Setup
1. Import `schema.sql` into your `fleet` database.
2. Place all PHP files into your project folder.
3. Update `db.php` with your MySQL credentials.
4. Open `add_payment.php` in browser to add a payment.
5. Open `payment_list.php` to view payments.
