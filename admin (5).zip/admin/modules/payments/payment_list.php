<?php include 'db.php'; ?>

<h2>Payment List</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Trip</th>
        <th>Amount</th>
        <th>Date</th>
        <th>Method</th>
        <th>Status</th>
        <th>Notes</th>
    </tr>

<?php
$sql = "SELECT p.*, t.pickup_location, t.drop_location 
        FROM payments p 
        JOIN trips t ON p.trip_id = t.id";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
    echo "<tr>
            <td>{$row['id']}</td>
            <td>Trip #{$row['trip_id']} - {$row['pickup_location']} → {$row['drop_location']}</td>
            <td>{$row['amount']}</td>
            <td>{$row['payment_date']}</td>
            <td>{$row['method']}</td>
            <td>{$row['status']}</td>
            <td>{$row['notes']}</td>
          </tr>";
}
?>
</table>