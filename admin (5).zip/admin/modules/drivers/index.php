<?php
include("../../admin/includes/header.php");
?>

<div class="content">
    <div class="container">
        <h2 class="mb-4">Drivers Module</h2>
        <p class="text-muted">Manage all driver related records here.</p>

        <div class="card shadow-sm p-4">
            <h5 class="mb-3">Available Options</h5>
            <a href="driver_list.php" class="btn btn-primary mb-2">Driver List</a>
            <a href="driver_add.php" class="btn btn-success mb-2">Add New Driver</a>
            <a href="driver_report.php" class="btn btn-info mb-2">Driver Report</a>
        </div>
    </div>
</div>

<?php
include("../../admin/includes/footer.php");
?>