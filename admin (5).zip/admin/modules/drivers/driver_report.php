<?php
include 'db.php';

// Driver usage report
$driverResult = $conn->query("
    SELECT drivers.id, drivers.name, drivers.cnic,
           COUNT(trips.id) as total_trips,
           IFNULL(SUM(expenses.amount),0) as total_expense,
           IFNULL(SUM(payments.amount),0) as total_payment
    FROM drivers
    LEFT JOIN trips ON trips.driver_id = drivers.id
    LEFT JOIN expenses ON expenses.driver_id = drivers.id
    LEFT JOIN payments ON payments.driver_id = drivers.id
    GROUP BY drivers.id, drivers.name, drivers.cnic
");

$drivers = [];
$driverNames = [];
$tripCounts = [];
while ($row = $driverResult->fetch_assoc()) {
    $drivers[] = $row;
    $driverNames[] = $row['name'] . " (" . $row['cnic'] . ")";
    $tripCounts[] = $row['total_trips'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Driver Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; background: white; }
        table th, table td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        table th { background: #007bff; color: white; }
        .chart-container { width: 70%; margin: auto; }
    </style>
</head>
<body>
    <h2>Driver Report</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Driver</th>
            <th>CNIC</th>
            <th>Total Trips</th>
            <th>Total Expense (PKR)</th>
            <th>Total Payment (PKR)</th>
        </tr>
        <?php foreach ($drivers as $row) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['cnic']; ?></td>
            <td><?php echo $row['total_trips']; ?></td>
            <td><?php echo $row['total_expense']; ?></td>
            <td><?php echo $row['total_payment']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <div class="chart-container">
        <canvas id="driverChart"></canvas>
    </div>

    <script>
        const ctx = document.getElementById('driverChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($driverNames); ?>,
                datasets: [{
                    label: 'Total Trips',
                    data: <?php echo json_encode($tripCounts); ?>,
                    backgroundColor: '#007bff'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    </script>
</body>
</html>
