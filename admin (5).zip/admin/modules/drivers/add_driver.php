<?php include 'db.php'; ?>

<h2>Add Driver</h2>
<form method="post" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" required><br><br>

    <label>CNIC:</label>
    <input type="text" name="cnic" required><br><br>

    <label>License No:</label>
    <input type="text" name="license_no" required><br><br>

    <label>Phone:</label>
    <input type="text" name="phone"><br><br>

    <label>Address:</label>
    <textarea name="address"></textarea><br><br>

    <label>Assigned Vehicle:</label>
    <select name="vehicle_id">
        <option value="">-- None --</option>
        <?php
        $vehicles = $conn->query("SELECT id, reg_no FROM vehicles");
        while($v = $vehicles->fetch_assoc()) {
            echo "<option value='{$v['id']}'>{$v['reg_no']}</option>";
        }
        ?>
    </select><br><br>

    <label>Joining Date:</label>
    <input type="date" name="joining_date"><br><br>

    <label>Status:</label>
    <select name="status">
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
    </select><br><br>

    <label>Profile Photo:</label>
    <input type="file" name="photo"><br><br>

    <label>CNIC File:</label>
    <input type="file" name="cnic_file"><br><br>

    <label>License File:</label>
    <input type="file" name="license_file"><br><br>

    <button type="submit" name="submit">Save Driver</button>
</form>

<?php
if(isset($_POST['submit'])){
    $uploadDir = "driver_uploads/";
    if(!is_dir($uploadDir)) mkdir($uploadDir);

    $photo = $_FILES['photo']['name'] ? $uploadDir . time() . "_photo_" . basename($_FILES['photo']['name']) : "";
    $cnic_file = $_FILES['cnic_file']['name'] ? $uploadDir . time() . "_cnic_" . basename($_FILES['cnic_file']['name']) : "";
    $license_file = $_FILES['license_file']['name'] ? $uploadDir . time() . "_lic_" . basename($_FILES['license_file']['name']) : "";

    if($photo) move_uploaded_file($_FILES['photo']['tmp_name'], $photo);
    if($cnic_file) move_uploaded_file($_FILES['cnic_file']['tmp_name'], $cnic_file);
    if($license_file) move_uploaded_file($_FILES['license_file']['tmp_name'], $license_file);

    $sql = "INSERT INTO drivers (name, cnic, license_no, phone, address, vehicle_id, joining_date, status, photo, cnic_file, license_file) 
            VALUES ('{$_POST['name']}','{$_POST['cnic']}','{$_POST['license_no']}','{$_POST['phone']}','{$_POST['address']}','{$_POST['vehicle_id']}','{$_POST['joining_date']}','{$_POST['status']}','$photo','$cnic_file','$license_file')";
    
    if($conn->query($sql)){
        echo "✅ Driver Added Successfully!";
    } else {
        echo "❌ Error: " . $conn->error;
    }
}
?>