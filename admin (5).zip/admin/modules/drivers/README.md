# Driver Module

## Files Included
- db.php (Database connection)
- schema.sql (Drivers table schema)
- add_driver.php (Form to add driver with file uploads)
- driver_list.php (List of drivers with edit/delete)

## Setup
1. Import schema.sql into your MySQL `fleet` database.
2. Place files in your PHP server root.
3. Create folder `driver_uploads/` with write permissions.
4. Open `add_driver.php` to add drivers.
5. View `driver_list.php` to manage drivers.
