<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/db.php';
$id=(int)($_GET['id']??0); $dr=$conn->query("SELECT * FROM drivers WHERE id=$id")->fetch_assoc(); if(!$dr){ header('Location:index.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $n=$conn->real_escape_string($_POST['name']); $p=$conn->real_escape_string($_POST['phone']);
  $l=$conn->real_escape_string($_POST['license_no']); $s=$conn->real_escape_string($_POST['status']);
  $conn->query("UPDATE drivers SET name='$n',phone='$p',license_no='$l',status='$s' WHERE id=$id");
  header('Location:index.php'); exit;
}
require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Edit Driver</h2>
<form method="post"><div class="row">
<div><label>Name</label><input name="name" value="<?=$dr['name']?>" required></div>
<div><label>Phone</label><input name="phone" value="<?=$dr['phone']?>"></div>
<div><label>License No</label><input name="license_no" value="<?=$dr['license_no']?>"></div>
<div><label>Status</label><select name="status">
<option <?=$dr['status']=='active'?'selected':''?> value="active">Active</option>
<option <?=$dr['status']=='inactive'?'selected':''?> value="inactive">Inactive</option></select></div>
</div><br><button class="btn">Update</button> <a class="btn" href="index.php">Cancel</a></form></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
