CREATE TABLE drivers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    cnic VARCHAR(20) NOT NULL,
    license_no VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    vehicle_id INT DEFAULT NULL,
    joining_date DATE,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    photo VARCHAR(255),
    cnic_file VARCHAR(255),
    license_file VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL
);