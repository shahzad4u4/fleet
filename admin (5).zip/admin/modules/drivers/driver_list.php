<?php include 'db.php'; ?>

<h2>Driver List</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>CNIC</th>
        <th>License</th>
        <th>Phone</th>
        <th>Vehicle</th>
        <th>Status</th>
        <th>Files</th>
        <th>Action</th>
    </tr>

<?php
$sql = "SELECT d.*, v.reg_no FROM drivers d 
        LEFT JOIN vehicles v ON d.vehicle_id = v.id";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['cnic']}</td>
            <td>{$row['license_no']}</td>
            <td>{$row['phone']}</td>
            <td>".($row['reg_no'] ?? '-')."</td>
            <td>{$row['status']}</td>
            <td>
                ".($row['photo'] ? "<a href='{$row['photo']}' target='_blank'>Photo</a>" : "")." |
                ".($row['cnic_file'] ? "<a href='{$row['cnic_file']}' target='_blank'>CNIC</a>" : "")." |
                ".($row['license_file'] ? "<a href='{$row['license_file']}' target='_blank'>License</a>" : "")."
            </td>
            <td>
                <a href='edit_driver.php?id={$row['id']}'>Edit</a> | 
                <a href='delete_driver.php?id={$row['id']}'>Delete</a>
            </td>
          </tr>";
}
?>
</table>