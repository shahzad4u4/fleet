<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $n=$conn->real_escape_string($_POST['name']); $p=$conn->real_escape_string($_POST['phone']);
  $l=$conn->real_escape_string($_POST['license_no']); $s=$conn->real_escape_string($_POST['status']);
  $conn->query("INSERT INTO drivers(name,phone,license_no,status) VALUES('$n','$p','$l','$s')");
  header('Location:index.php'); exit;
}
require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Add Driver</h2>
<form method="post"><div class="row">
<div><label>Name</label><input name="name" required></div>
<div><label>Phone</label><input name="phone"></div>
<div><label>License No</label><input name="license_no"></div>
<div><label>Status</label><select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
</div><br><button class="btn">Save</button> <a class="btn" href="index.php">Cancel</a></form></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
