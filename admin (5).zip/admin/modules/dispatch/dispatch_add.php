
<?php
$page_title = "Add Dispatch";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

// Auto dispatch number
$r = $conn->query("SELECT MAX(id) AS max_id FROM dispatches");
$nextId = ($r && ($row=$r->fetch_assoc())) ? intval($row['max_id'])+1 : 1;
$dispatchNo = "DIS-" . str_pad($nextId, 4, "0", STR_PAD_LEFT);

if(isset($_POST['save'])){
  $dispatch_date = $_POST['dispatch_date'];
  $booking_id    = intval($_POST['booking_id']);
  $vehicle_id    = intval($_POST['vehicle_id']);
  $driver_id     = intval($_POST['driver_id']);
  $route         = $conn->real_escape_string($_POST['route']);
  $remarks       = $conn->real_escape_string($_POST['remarks']);
  $status        = "Dispatched";

  $sql = "INSERT INTO dispatches (dispatch_no, dispatch_date, booking_id, vehicle_id, driver_id, route, remarks, status)
          VALUES ('$dispatchNo','$dispatch_date',$booking_id,$vehicle_id,$driver_id,'$route','$remarks','$status')";
  if($conn->query($sql)){
    // update booking status
    $conn->query("UPDATE bookings SET status='Dispatched' WHERE id=$booking_id");
    echo "<script>alert('Dispatch created'); location.href='dispatch_list.php';</script>";
    exit;
  } else {
    echo "<div class='p-4 text-red-600'>Error: ".$conn->error."</div>";
  }
}
?>
<main class="p-6 md:ml-64">
  <form method="post" class="bg-white border border-slate-200 rounded-2xl p-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-semibold">Dispatch No</label>
        <input class="w-full border p-2 rounded" value="<?=$dispatchNo?>" readonly>
      </div>
      <div>
        <label class="block text-sm font-semibold">Dispatch Date</label>
        <input type="date" name="dispatch_date" value="<?=date('Y-m-d')?>" class="w-full border p-2 rounded" required>
      </div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Booking & Trip</div>
      <div>
        <label class="block text-sm">Booking (Pending only)</label>
        <select name="booking_id" class="w-full border p-2 rounded" required>
          <option value="">Select Booking</option>
          <?php
            $b = $conn->query("SELECT id, booking_no, goods FROM bookings WHERE status='Pending' ORDER BY id DESC");
            if($b){ while($r=$b->fetch_assoc()){ echo "<option value='{$r['id']}'>".$r['booking_no']." — ".htmlspecialchars($r['goods'])."</option>"; } }
          ?>
        </select>
      </div>
      <div>
        <label class="block text-sm">Vehicle</label>
        <select name="vehicle_id" class="w-full border p-2 rounded" required>
          <option value="">Select Vehicle</option>
          <?php $v=$conn->query("SELECT id, plate_no FROM vehicles"); if($v){ while($r=$v->fetch_assoc()){ echo "<option value='{$r['id']}'>".htmlspecialchars($r['plate_no'])."</option>"; }} ?>
        </select>
      </div>
      <div>
        <label class="block text-sm">Driver</label>
        <select name="driver_id" class="w-full border p-2 rounded" required>
          <option value="">Select Driver</option>
          <?php $d=$conn->query("SELECT id, name FROM drivers"); if($d){ while($r=$d->fetch_assoc()){ echo "<option value='{$r['id']}'>".htmlspecialchars($r['name'])."</option>"; }} ?>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm">Route / Destination</label>
        <input name="route" class="w-full border p-2 rounded" placeholder="KHI → LHR">
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm">Remarks</label>
        <input name="remarks" class="w-full border p-2 rounded" placeholder="Any notes">
      </div>
    </div>
    <div class="mt-4">
      <button name="save" class="bg-blue-600 text-white px-4 py-2 rounded">Save Dispatch</button>
      <a href="dispatch_list.php" class="ml-2 px-4 py-2 border rounded">Cancel</a>
    </div>
  </form>
</main>
<?php include "layout/footer.php"; ?>
