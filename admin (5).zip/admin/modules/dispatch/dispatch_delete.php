
<?php
include "db.php";
$id = intval($_GET['id'] ?? 0);
if($id>0){
  // Optional: revert booking status if needed (not safe if multiple dispatches)
  $conn->query("DELETE FROM dispatches WHERE id=$id");
}
header("Location: dispatch_list.php");
exit;
