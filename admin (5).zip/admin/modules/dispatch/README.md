
# Dispatch Module (Full)

## Includes
- `schema_dispatch.sql` — dispatches table
- `db.php`
- `layout/` (Tailwind minimal)
- `dispatch_add.php` — create dispatch (updates booking to Dispatched)
- `dispatch_list.php` — filter by status, actions
- `dispatch_edit.php` — update status (syncs booking status)
- `dispatch_delete.php` — delete
- `dispatch_print.php` — print-friendly note

## Setup
1) Import `schema_dispatch.sql` to DB.
2) Ensure `bookings`, `vehicles`, `drivers` tables exist (from Booking module).
3) Update credentials in `db.php`.
4) Use `dispatch_add.php` to create a dispatch. Manage via `dispatch_list.php`.
