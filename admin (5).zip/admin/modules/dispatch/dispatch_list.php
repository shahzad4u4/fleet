
<?php
$page_title = "Dispatch List";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

$filter = $_GET['status'] ?? '';
$where = $filter ? "WHERE d.status='".$conn->real_escape_string($filter)."'" : "";
$sql = "SELECT d.*, b.booking_no, b.goods, v.plate_no, dr.name AS driver_name
        FROM dispatches d
        LEFT JOIN bookings b ON d.booking_id=b.id
        LEFT JOIN vehicles v ON d.vehicle_id=v.id
        LEFT JOIN drivers dr ON d.driver_id=dr.id
        $where
        ORDER BY d.id DESC";
$rs = $conn->query($sql);
?>
<main class="p-6 md:ml-64">
  <div class="flex items-center justify-between mb-4">
    <h2 class="text-xl font-bold">Dispatches</h2>
    <a href="dispatch_add.php" class="bg-green-600 text-white px-4 py-2 rounded">+ Add Dispatch</a>
  </div>
  <div class="bg-white border border-slate-200 rounded-2xl p-4 mb-3">
    <form method="get" class="flex items-center gap-2">
      <label>Status</label>
      <select name="status" class="border rounded p-2">
        <option value="">All</option>
        <?php foreach(['Dispatched','In Transit','Delivered'] as $s){ $sel = ($filter==$s)?'selected':''; echo "<option $sel>$s</option>"; } ?>
      </select>
      <button class="px-3 py-2 border rounded">Filter</button>
      <?php if($filter){ ?><a class="px-3 py-2 border rounded" href="dispatch_list.php">Reset</a><?php } ?>
    </form>
  </div>

  <div class="bg-white border border-slate-200 rounded-2xl overflow-x-auto">
    <table class="min-w-[980px] w-full text-sm">
      <thead class="bg-slate-50 text-slate-600">
        <tr>
          <th class="text-left px-3 py-2">#</th>
          <th class="text-left px-3 py-2">Dispatch No</th>
          <th class="text-left px-3 py-2">Date</th>
          <th class="text-left px-3 py-2">Booking</th>
          <th class="text-left px-3 py-2">Goods</th>
          <th class="text-left px-3 py-2">Vehicle</th>
          <th class="text-left px-3 py-2">Driver</th>
          <th class="text-left px-3 py-2">Route</th>
          <th class="text-left px-3 py-2">Status</th>
          <th class="text-left px-3 py-2">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $i=1; if($rs){ while($row=$rs->fetch_assoc()){ ?>
        <tr class="border-t">
          <td class="px-3 py-2"><?=$i++?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['dispatch_no'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['dispatch_date'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['booking_no'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['goods'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['plate_no'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['driver_name'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['route'])?></td>
          <td class="px-3 py-2"><?=htmlspecialchars($row['status'])?></td>
          <td class="px-3 py-2">
            <a href="dispatch_edit.php?id=<?=$row['id']?>" class="px-2 py-1 border rounded hover:bg-slate-50">Edit</a>
            <a href="dispatch_print.php?id=<?=$row['id']?>" class="px-2 py-1 border rounded hover:bg-slate-50">Print</a>
            <a href="dispatch_delete.php?id=<?=$row['id']?>" onclick="return confirm('Delete this record?')" class="px-2 py-1 border rounded hover:bg-slate-50 text-red-600">Delete</a>
          </td>
        </tr>
        <?php } } ?>
      </tbody>
    </table>
  </div>
</main>
<?php include "layout/footer.php"; ?>
