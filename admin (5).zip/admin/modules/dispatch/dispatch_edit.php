
<?php
$page_title = "Edit Dispatch";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

$id = intval($_GET['id'] ?? 0);
$dp = $conn->query("SELECT * FROM dispatches WHERE id=$id")->fetch_assoc();
if(!$dp){ echo "<main class='p-6 md:ml-64'>Not found.</main>"; include "layout/footer.php"; exit; }

if(isset($_POST['update'])){
  $dispatch_date = $_POST['dispatch_date'];
  $booking_id    = intval($_POST['booking_id']);
  $vehicle_id    = intval($_POST['vehicle_id']);
  $driver_id     = intval($_POST['driver_id']);
  $route         = $conn->real_escape_string($_POST['route']);
  $remarks       = $conn->real_escape_string($_POST['remarks']);
  $status        = $_POST['status'];

  $sql = "UPDATE dispatches SET dispatch_date='$dispatch_date', booking_id=$booking_id, vehicle_id=$vehicle_id, driver_id=$driver_id, route='$route', remarks='$remarks', status='$status' WHERE id=$id";
  if($conn->query($sql)){
    // Sync booking status if Delivered / Dispatched
    if($status=='Delivered'){ $conn->query("UPDATE bookings SET status='Delivered' WHERE id=$booking_id"); }
    elseif($status=='Dispatched' || $status=='In Transit'){ $conn->query("UPDATE bookings SET status='Dispatched' WHERE id=$booking_id"); }
    echo "<script>alert('Updated'); location.href='dispatch_list.php';</script>";
    exit;
  } else {
    echo "<div class='p-4 text-red-600'>Error: ".$conn->error."</div>";
  }
}
?>
<main class="p-6 md:ml-64">
  <form method="post" class="bg-white border border-slate-200 rounded-2xl p-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm">Dispatch No</label>
        <input class="w-full border p-2 rounded" value="<?=htmlspecialchars($dp['dispatch_no'])?>" readonly>
      </div>
      <div>
        <label class="block text-sm">Dispatch Date</label>
        <input type="date" name="dispatch_date" value="<?=htmlspecialchars($dp['dispatch_date'])?>" class="w-full border p-2 rounded" required>
      </div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Booking & Trip</div>
      <div>
        <label class="block text-sm">Booking</label>
        <select name="booking_id" class="w-full border p-2 rounded" required>
          <?php
            $b = $conn->query("SELECT id, booking_no FROM bookings ORDER BY id DESC");
            if($b){ while($r=$b->fetch_assoc()){ $sel = ($dp['booking_id']==$r['id'])?'selected':''; echo "<option value='{$r['id']}' $sel>".htmlspecialchars($r['booking_no'])."</option>"; } }
          ?>
        </select>
      </div>
      <div>
        <label class="block text-sm">Vehicle</label>
        <select name="vehicle_id" class="w-full border p-2 rounded" required>
          <?php $v=$conn->query("SELECT id, plate_no FROM vehicles"); if($v){ while($r=$v->fetch_assoc()){ $sel=($dp['vehicle_id']==$r['id'])?'selected':''; echo "<option value='{$r['id']}' $sel>".htmlspecialchars($r['plate_no'])."</option>"; }} ?>
        </select>
      </div>
      <div>
        <label class="block text-sm">Driver</label>
        <select name="driver_id" class="w-full border p-2 rounded" required>
          <?php $d=$conn->query("SELECT id, name FROM drivers"); if($d){ while($r=$d->fetch_assoc()){ $sel=($dp['driver_id']==$r['id'])?'selected':''; echo "<option value='{$r['id']}' $sel>".htmlspecialchars($r['name'])."</option>"; }} ?>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm">Route</label>
        <input name="route" class="w-full border p-2 rounded" value="<?=htmlspecialchars($dp['route'])?>">
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm">Remarks</label>
        <input name="remarks" class="w-full border p-2 rounded" value="<?=htmlspecialchars($dp['remarks'])?>">
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm">Status</label>
        <select name="status" class="w-full border p-2 rounded">
          <?php foreach(['Dispatched','In Transit','Delivered'] as $s){ $sel=($dp['status']==$s)?'selected':''; echo "<option $sel>$s</option>"; } ?>
        </select>
      </div>
    </div>
    <div class="mt-4">
      <button name="update" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
      <a href="dispatch_list.php" class="ml-2 px-4 py-2 border rounded">Back</a>
    </div>
  </form>
</main>
<?php include "layout/footer.php"; ?>
