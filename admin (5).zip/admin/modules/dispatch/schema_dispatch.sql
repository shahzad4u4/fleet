
CREATE TABLE IF NOT EXISTS dispatches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dispatch_no VARCHAR(30) UNIQUE,
  dispatch_date DATE,
  booking_id INT,
  vehicle_id INT,
  driver_id INT,
  route VARCHAR(255),
  remarks VARCHAR(255),
  status ENUM('Dispatched','In Transit','Delivered') DEFAULT 'Dispatched',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (booking_id),
  INDEX (vehicle_id),
  INDEX (driver_id)
);

-- Ensure bookings, vehicles, drivers exist
-- bookings.status should be 'Pending' | 'Dispatched' | 'Delivered'
