
<?php
include "db.php";
$id = intval($_GET['id'] ?? 0);
$dp = $conn->query("SELECT d.*, b.booking_no, b.consignor, b.consignee, b.goods, b.qty, b.weight, b.rate, v.plate_no, dr.name AS driver_name
  FROM dispatches d
  LEFT JOIN bookings b ON d.booking_id=b.id
  LEFT JOIN vehicles v ON d.vehicle_id=v.id
  LEFT JOIN drivers dr ON d.driver_id=dr.id
  WHERE d.id=$id")->fetch_assoc();
if(!$dp){ die("Not found"); }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Dispatch Note - <?=$dp['dispatch_no']?></title>
  <style>
    body{font-family:Arial; margin:20px;}
    .head{display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #222; padding-bottom:8px; margin-bottom:10px}
    .title{font-size:20px; font-weight:bold}
    table{width:100%; border-collapse:collapse}
    td,th{padding:6px; border:1px solid #ddd; font-size:13px}
    .no-border td,.no-border th{border:none}
    .muted{color:#666}
    .right{text-align:right}
    .badge{display:inline-block; padding:2px 8px; border:1px solid #999; border-radius:12px; font-size:12px}
    @media print{ .noprint{display:none} }
  </style>
</head>
<body>
  <div class="noprint" style="text-align:right;margin-bottom:10px">
    <button onclick="window.print()">Print</button>
  </div>

  <div class="head">
    <div>
      <div class="title">Dispatch Note</div>
      <div class="muted">Fleet System</div>
    </div>
    <div class="right">
      <div><strong>No:</strong> <?=$dp['dispatch_no']?></div>
      <div><strong>Date:</strong> <?=$dp['dispatch_date']?></div>
      <div><span class="badge"><?=$dp['status']?></span></div>
    </div>
  </div>

  <table class="no-border">
    <tr>
      <td style="width:50%">
        <strong>Booking</strong><br>
        <?=$dp['booking_no']?><br>
        <span class="muted"><?=$dp['consignor']?> → <?=$dp['consignee']?></span>
      </td>
      <td style="width:50%">
        <strong>Vehicle / Driver</strong><br>
        <?=$dp['plate_no']?> / <?=$dp['driver_name']?><br>
        <span class="muted">Route: <?=$dp['route']?></span>
      </td>
    </tr>
  </table>

  <h4>Goods</h4>
  <table>
    <thead>
      <tr><th>Description</th><th class="right">Qty</th><th class="right">Weight(kg)</th><th class="right">Rate</th></tr>
    </thead>
    <tbody>
      <tr>
        <td><?=htmlspecialchars($dp['goods'])?></td>
        <td class="right"><?=number_format($dp['qty'],2)?></td>
        <td class="right"><?=number_format($dp['weight'],2)?></td>
        <td class="right"><?=number_format($dp['rate'],2)?></td>
      </tr>
    </tbody>
  </table>

  <p class="muted" style="margin-top:20px">Note: System generated dispatch note.</p>
</body>
</html>
