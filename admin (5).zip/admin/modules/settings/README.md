# System Settings Module

## Setup
1. Import schema.sql into your DB.
2. Copy files into your project root (where db.php is located).
3. Make folder `uploads/logo/` with write permissions.
4. Open `settings.php` in browser.

Now you can update company info + see **live preview** instantly.
