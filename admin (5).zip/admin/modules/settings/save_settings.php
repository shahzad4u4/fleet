<?php
include '../includes/db.php';

// File upload paths
$upload_dir = "uploads/";
if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);

$logo = $_FILES['logo']['name'] ? time()."_".$_FILES['logo']['name'] : null;
$letterhead = $_FILES['letterhead']['name'] ? time()."_".$_FILES['letterhead']['name'] : null;

if($logo) move_uploaded_file($_FILES['logo']['tmp_name'], $upload_dir.$logo);
if($letterhead) move_uploaded_file($_FILES['letterhead']['tmp_name'], $upload_dir.$letterhead);

$sql = "INSERT INTO settings (company_name, contact_person, phone, email, address, logo, letterhead, whatsapp_api, google_api)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sssssssss',
    $_POST['company_name'], $_POST['contact_person'], $_POST['phone'],
    $_POST['email'], $_POST['address'], $logo, $letterhead,
    $_POST['whatsapp_api'], $_POST['google_api']
);
$stmt->execute();

header("Location: index.php");
exit;
?>
