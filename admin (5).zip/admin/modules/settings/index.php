<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../../config/db.php';

// Fetch latest settings
$result = $conn->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $result->fetch_assoc();

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_name   = $_POST['company_name'];
    $contact_person = $_POST['contact_person'];
    $email          = $_POST['email'];
    $phone          = $_POST['phone'];
    $address        = $_POST['address'];
    $sms_api_key    = $_POST['sms_api_key'];
    $whatsapp_api   = $_POST['whatsapp_api_key'];
    $google_api     = $_POST['google_api_key'];

    // File Uploads
    $logoFile = $settings['logo'] ?? '';
    $letterFile = $settings['letterhead'] ?? '';

    if (!empty($_FILES['logo']['name'])) {
        $logoFile = 'uploads/' . time() . "_logo_" . basename($_FILES['logo']['name']);
        move_uploaded_file($_FILES['logo']['tmp_name'], $logoFile);
    }
    if (!empty($_FILES['letterhead']['name'])) {
        $letterFile = 'uploads/' . time() . "_letter_" . basename($_FILES['letterhead']['name']);
        move_uploaded_file($_FILES['letterhead']['tmp_name'], $letterFile);
    }

    // If record exists → update, else insert
    if ($settings) {
        $sql = "UPDATE settings SET company_name=?, contact_person=?, email=?, phone=?, address=?, sms_api_key=?, whatsapp_api_key=?, google_api_key=?, logo=?, letterhead=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssi", $company_name, $contact_person, $email, $phone, $address, $sms_api_key, $whatsapp_api, $google_api, $logoFile, $letterFile, $settings['id']);
    } else {
        $sql = "INSERT INTO settings (company_name, contact_person, email, phone, address, sms_api_key, whatsapp_api_key, google_api_key, logo, letterhead) VALUES (?,?,?,?,?,?,?,?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssss", $company_name, $contact_person, $email, $phone, $address, $sms_api_key, $whatsapp_api, $google_api, $logoFile, $letterFile);
    }

    if ($stmt->execute()) {
        header("Location: index.php?success=1");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Company Settings</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
  <div class="max-w-3xl mx-auto bg-white shadow-md rounded p-6 mt-10">
    <h1 class="text-xl font-bold mb-4">⚙ Company Settings</h1>

    <?php if(isset($_GET['success'])): ?>
      <p class="bg-green-100 text-green-800 p-2 mb-3 rounded">✅ Settings updated successfully</p>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">

      <div>
        <label class="block text-sm">Company Name</label>
        <input type="text" name="company_name" value="<?= htmlspecialchars($settings['company_name'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block text-sm">Contact Person</label>
        <input type="text" name="contact_person" value="<?= htmlspecialchars($settings['contact_person'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm">Email</label>
          <input type="email" name="email" value="<?= htmlspecialchars($settings['email'] ?? '') ?>" class="w-full border rounded p-2">
        </div>
        <div>
          <label class="block text-sm">Phone</label>
          <input type="text" name="phone" value="<?= htmlspecialchars($settings['phone'] ?? '') ?>" class="w-full border rounded p-2">
        </div>
      </div>

      <div>
        <label class="block text-sm">Address</label>
        <textarea name="address" class="w-full border rounded p-2"><?= htmlspecialchars($settings['address'] ?? '') ?></textarea>
      </div>

      <div class="grid grid-cols-3 gap-4">
        <div>
          <label class="block text-sm">SMS API Key</label>
          <input type="text" name="sms_api_key" value="<?= htmlspecialchars($settings['sms_api_key'] ?? '') ?>" class="w-full border rounded p-2">
        </div>
        <div>
          <label class="block text-sm">WhatsApp API</label>
          <input type="text" name="whatsapp_api_key" value="<?= htmlspecialchars($settings['whatsapp_api_key'] ?? '') ?>" class="w-full border rounded p-2">
        </div>
        <div>
          <label class="block text-sm">Google API Key</label>
          <input type="text" name="google_api_key" value="<?= htmlspecialchars($settings['google_api_key'] ?? '') ?>" class="w-full border rounded p-2">
        </div>
      </div>

      <div>
        <label class="block text-sm">Logo</label>
        <input type="file" name="logo" class="w-full border rounded p-2">
        <?php if(!empty($settings['logo'])): ?>
          <img src="../../<?= $settings['logo'] ?>" alt="logo" class="h-16 mt-2">
        <?php endif; ?>
      </div>

      <div>
        <label class="block text-sm">Letterhead (JPG)</label>
        <input type="file" name="letterhead" class="w-full border rounded p-2">
        <?php if(!empty($settings['letterhead'])): ?>
          <img src="../../<?= $settings['letterhead'] ?>" alt="letterhead" class="h-32 mt-2 border">
        <?php endif; ?>
      </div>

      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">💾 Save Settings</button>
    </form>
  </div>
</body>
</html>
