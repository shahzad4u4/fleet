<?php
include '../includes/db.php';
$result = $conn->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <style>
        body { font-family: Arial; margin: 0; padding: 0; }
        .letterhead { width: 100%; }
        .content { margin: 20px; }
    </style>
</head>
<body>
    <?php if(!empty($settings['letterhead'])): ?>
        <img src="../settings/uploads/<?= $settings['letterhead'] ?>" class="letterhead">
    <?php endif; ?>

    <div class="content">
        <h2>Invoice</h2>
        <p><strong>Company:</strong> <?= $settings['company_name'] ?></p>
        <p><strong>Contact:</strong> <?= $settings['contact_person'] ?> (<?= $settings['phone'] ?>)</p>
        <p><strong>Email:</strong> <?= $settings['email'] ?></p>
        <p><strong>Address:</strong> <?= $settings['address'] ?></p>
        <hr>
        <p>Invoice details will be here...</p>
    </div>
</body>
</html>
