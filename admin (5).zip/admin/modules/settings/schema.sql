CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(200),
    logo VARCHAR(255),
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    invoice_header TEXT,
    invoice_footer TEXT,
    currency VARCHAR(20) DEFAULT 'PKR'
);