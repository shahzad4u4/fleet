<?php
include 'db.php';
$result = $conn->query("SELECT * FROM settings LIMIT 1");
$settings = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
<title>System Settings</title>
<style>
.form-section { float:left; width:45%; padding:20px; }
.preview-section { float:right; width:45%; padding:20px; border:1px solid #ccc; }
.preview-card { padding:20px; border:1px solid #999; }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="form-section">
<h2>Update Settings</h2>
<form id="settingsForm" enctype="multipart/form-data">
    Company Name: <input type="text" name="company_name" value="<?= $settings['company_name'] ?>"><br><br>
    Logo: <input type="file" name="logo"><br><br>
    Address: <textarea name="address"><?= $settings['address'] ?></textarea><br><br>
    Phone: <input type="text" name="phone" value="<?= $settings['phone'] ?>"><br><br>
    Email: <input type="text" name="email" value="<?= $settings['email'] ?>"><br><br>
    Invoice Header: <textarea name="invoice_header"><?= $settings['invoice_header'] ?></textarea><br><br>
    Invoice Footer: <textarea name="invoice_footer"><?= $settings['invoice_footer'] ?></textarea><br><br>
    Currency: <input type="text" name="currency" value="<?= $settings['currency'] ?>"><br><br>
    <button type="submit">Save</button>
</form>
</div>

<div class="preview-section">
<h2>Live Preview</h2>
<div id="preview" class="preview-card"></div>
</div>

<script>
function loadPreview(){
    $.get("settings_load.php", function(data){
        $("#preview").html(data);
    });
}
$(document).ready(function(){
    loadPreview();
    $("#settingsForm").on("submit", function(e){
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: "settings_save.php",
            type: "POST",
            data: formData,
            contentType:false,
            processData:false,
            success:function(){
                loadPreview();
                alert("Settings updated!");
            }
        });
    });
});
</script>
</body>
</html>