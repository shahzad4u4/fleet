<?php
include 'db.php';

// file upload
$logoName = null;
if(isset($_FILES['logo']) && $_FILES['logo']['error']==0){
    $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
    $logoName = "logo_".time().".".$ext;
    move_uploaded_file($_FILES['logo']['tmp_name'], "uploads/logo/".$logoName);
}

// update or insert
$result = $conn->query("SELECT id FROM settings LIMIT 1");
if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    $id = $row['id'];
    $sql = "UPDATE settings SET company_name='{$_POST['company_name']}', address='{$_POST['address']}', 
            phone='{$_POST['phone']}', email='{$_POST['email']}', invoice_header='{$_POST['invoice_header']}',
            invoice_footer='{$_POST['invoice_footer']}', currency='{$_POST['currency']}'";
    if($logoName) $sql .= ", logo='$logoName'";
    $sql .= " WHERE id=$id";
    $conn->query($sql);
} else {
    $sql = "INSERT INTO settings (company_name,logo,address,phone,email,invoice_header,invoice_footer,currency)
            VALUES ('{$_POST['company_name']}','$logoName','{$_POST['address']}','{$_POST['phone']}','{$_POST['email']}',
            '{$_POST['invoice_header']}','{$_POST['invoice_footer']}','{$_POST['currency']}')";
    $conn->query($sql);
}
?>