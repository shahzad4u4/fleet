<?php
include 'db.php';
$result = $conn->query("SELECT * FROM settings LIMIT 1");
if($result->num_rows>0){
    $s = $result->fetch_assoc();
    echo "<div>";
    if($s['logo']) echo "<img src='uploads/logo/".$s['logo']."' style='max-width:150px'><br>";
    echo "<h2>".$s['company_name']."</h2>";
    echo "<p>".$s['address']."</p>";
    echo "<p>Phone: ".$s['phone']." | Email: ".$s['email']."</p>";
    echo "<h4>".$s['invoice_header']."</h4>";
    echo "<h4>".$s['invoice_footer']."</h4>";
    echo "<p>Currency: ".$s['currency']."</p>";
    echo "</div>";
}else{
    echo "No settings found.";
}
?>