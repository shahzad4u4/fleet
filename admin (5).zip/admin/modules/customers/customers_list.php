<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$dbPath = __DIR__ . '/../../config/db.php';
if (file_exists($dbPath)) { include $dbPath; }
$guardPath = __DIR__ . '/../../app/auth_guard.php';
if (file_exists($guardPath)) { include $guardPath; }
$layoutBase = __DIR__ . '/../../app/layout';
include $layoutBase . '/header.php';
include $layoutBase . '/sidebar.php';
include $layoutBase . '/topnav.php';
?>
<main class="p-6 md:ml-64">
<div class="flex items-center justify-between mb-4">
  <h1 class="text-xl font-bold">Customers</h1>
  <a href="customers_add.php" class="px-3 py-2 border rounded-lg hover:bg-slate-50">+ Add Customer</a>
</div>
<div class="bg-white rounded-xl border shadow-sm overflow-auto">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="px-3 py-2 text-left">#</th>
        <th class="px-3 py-2 text-left">Name</th>
        <th class="px-3 py-2 text-left">Company</th>
        <th class="px-3 py-2 text-left">Phone</th>
        <th class="px-3 py-2 text-left">Email</th>
        <th class="px-3 py-2 text-left">City</th>
        <th class="px-3 py-2 text-left">Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php
    if (!isset($conn)) { echo "<tr><td class='px-3 py-2' colspan='7'>DB config missing (config/db.php)</td></tr>"; }
    else {
      $res = $conn->query("SELECT * FROM customers ORDER BY id DESC");
      while($r = $res && $r->fetch_assoc()){
        echo "<tr class='border-t'>
          <td class='px-3 py-2'>{$r['id']}</td>
          <td class='px-3 py-2'>".htmlspecialchars($r['name'])."</td>
          <td class='px-3 py-2'>".htmlspecialchars($r['company'])."</td>
          <td class='px-3 py-2'>".htmlspecialchars($r['phone'])."</td>
          <td class='px-3 py-2'>".htmlspecialchars($r['email'])."</td>
          <td class='px-3 py-2'>".htmlspecialchars($r['city'])."</td>
          <td class='px-3 py-2 space-x-2'>
            <a class='underline text-blue-600' href='customers_edit.php?id={$r['id']}'>Edit</a>
            <a class='underline text-red-600' href='customers_delete.php?id={$r['id']}' onclick='return confirm("Delete this customer?")'>Delete</a>
          </td>
        </tr>";
      }
    }
    ?>
    </tbody>
  </table>
</div>

</main>
<?php include $layoutBase . '/footer.php'; ?>
