<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$dbPath = __DIR__ . '/../../config/db.php';
if (file_exists($dbPath)) { include $dbPath; }
$guardPath = __DIR__ . '/../../app/auth_guard.php';
if (file_exists($guardPath)) { include $guardPath; }
$id = intval($_GET['id'] ?? 0);
if (isset($conn) && $id>0){
  $conn->query("DELETE FROM customers WHERE id=$id");
}
header("Location: customers_list.php");
exit;
