<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$dbPath = __DIR__ . '/../../config/db.php';
if (file_exists($dbPath)) { include $dbPath; }
$guardPath = __DIR__ . '/../../app/auth_guard.php';
if (file_exists($guardPath)) { include $guardPath; }
$layoutBase = __DIR__ . '/../../app/layout';
include $layoutBase . '/header.php';
include $layoutBase . '/sidebar.php';
include $layoutBase . '/topnav.php';
?>
<main class="p-6 md:ml-64">
<h1 class="text-xl font-bold mb-4">Edit Customer</h1>
<?php
if (!isset($conn)){ echo "<div class='text-red-600'>DB not configured.</div>"; }
else {
  $id = intval($_GET['id'] ?? 0);
  if ($_SERVER['REQUEST_METHOD']==='POST'){
    $name = $conn->real_escape_string($_POST['name'] ?? '');
    $company = $conn->real_escape_string($_POST['company'] ?? '');
    $phone = $conn->real_escape_string($_POST['phone'] ?? '');
    $email = $conn->real_escape_string($_POST['email'] ?? '');
    $address = $conn->real_escape_string($_POST['address'] ?? '');
    $city = $conn->real_escape_string($_POST['city'] ?? '');
    $tax_no = $conn->real_escape_string($_POST['tax_no'] ?? '');
    if ($name==='') echo "<div class='mb-3 text-red-600'>Name is required.</div>";
    else {
      $conn->query("UPDATE customers SET name='$name', company='$company', phone='$phone', email='$email', address='$address', city='$city', tax_no='$tax_no' WHERE id=$id");
      echo "<div class='mb-3 text-green-700'>Customer updated.</div>";
      echo "<script>setTimeout(()=>location.href='customers_list.php',800);</script>";
    }
  }
  $res = $conn->query("SELECT * FROM customers WHERE id=$id");
  $r = $res ? $res->fetch_assoc() : null;
}
?>
<?php if($r): ?>
<form method="post" class="bg-white rounded-xl border shadow-sm p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
  <label class="text-sm">Name*<input name="name" value="<?= htmlspecialchars($r['name']) ?>" class="mt-1 w-full border rounded px-3 py-2" required></label>
  <label class="text-sm">Company<input name="company" value="<?= htmlspecialchars($r['company']) ?>" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Phone<input name="phone" value="<?= htmlspecialchars($r['phone']) ?>" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Email<input name="email" value="<?= htmlspecialchars($r['email']) ?>" type="email" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm md:col-span-2">Address<textarea name="address" class="mt-1 w-full border rounded px-3 py-2"><?= htmlspecialchars($r['address']) ?></textarea></label>
  <label class="text-sm">City<input name="city" value="<?= htmlspecialchars($r['city']) ?>" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Tax No<input name="tax_no" value="<?= htmlspecialchars($r['tax_no']) ?>" class="mt-1 w-full border rounded px-3 py-2"></label>
  <div class="md:col-span-2 flex gap-2 pt-2">
    <button class="px-4 py-2 border rounded-lg">Update</button>
    <a href="customers_list.php" class="px-4 py-2 border rounded-lg">Back</a>
  </div>
</form>
<?php else: ?>
  <div class="text-red-600">Customer not found.</div>
<?php endif; ?>

</main>
<?php include $layoutBase . '/footer.php'; ?>
