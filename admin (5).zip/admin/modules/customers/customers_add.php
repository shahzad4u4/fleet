<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$dbPath = __DIR__ . '/../../config/db.php';
if (file_exists($dbPath)) { include $dbPath; }
$guardPath = __DIR__ . '/../../app/auth_guard.php';
if (file_exists($guardPath)) { include $guardPath; }
$layoutBase = __DIR__ . '/../../app/layout';
include $layoutBase . '/header.php';
include $layoutBase . '/sidebar.php';
include $layoutBase . '/topnav.php';
?>
<main class="p-6 md:ml-64">
<h1 class="text-xl font-bold mb-4">Add Customer</h1>
<?php
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($conn)){
  $name = $conn->real_escape_string($_POST['name'] ?? '');
  $company = $conn->real_escape_string($_POST['company'] ?? '');
  $phone = $conn->real_escape_string($_POST['phone'] ?? '');
  $email = $conn->real_escape_string($_POST['email'] ?? '');
  $address = $conn->real_escape_string($_POST['address'] ?? '');
  $city = $conn->real_escape_string($_POST['city'] ?? '');
  $tax_no = $conn->real_escape_string($_POST['tax_no'] ?? '');
  if ($name==='') echo "<div class='mb-3 text-red-600'>Name is required.</div>";
  else {
    $conn->query("INSERT INTO customers(name,company,phone,email,address,city,tax_no) VALUES('$name','$company','$phone','$email','$address','$city','$tax_no')");
    echo "<div class='mb-3 text-green-700'>Customer saved.</div>";
    echo "<script>setTimeout(()=>location.href='customers_list.php',800);</script>";
  }
}
?>
<form method="post" class="bg-white rounded-xl border shadow-sm p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
  <label class="text-sm">Name*<input name="name" class="mt-1 w-full border rounded px-3 py-2" required></label>
  <label class="text-sm">Company<input name="company" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Phone<input name="phone" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Email<input name="email" type="email" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm md:col-span-2">Address<textarea name="address" class="mt-1 w-full border rounded px-3 py-2"></textarea></label>
  <label class="text-sm">City<input name="city" class="mt-1 w-full border rounded px-3 py-2"></label>
  <label class="text-sm">Tax No<input name="tax_no" class="mt-1 w-full border rounded px-3 py-2"></label>
  <div class="md:col-span-2 flex gap-2 pt-2">
    <button class="px-4 py-2 border rounded-lg">Save</button>
    <a href="customers_list.php" class="px-4 py-2 border rounded-lg">Back</a>
  </div>
</form>

</main>
<?php include $layoutBase . '/footer.php'; ?>
