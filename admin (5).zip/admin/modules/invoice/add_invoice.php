<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../../config/db.php';

// fetch company settings
$result = $conn->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $result->fetch_assoc();

// dummy invoice data (later DB se ayega)
$invoice_no = "INV-1001";
$invoice_date = date("d-m-Y");
$customer_name = "Ali Khan";
$customer_phone = "0300-1234567";
$items = [
    ["name" => "Freight Charges", "qty" => 1, "price" => 5000],
    ["name" => "Custom Duty", "qty" => 1, "price" => 12000],
];
$total = array_sum(array_map(fn($i) => $i['qty'] * $i['price'], $items));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice <?= $invoice_no ?></title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    body {
      background: #f3f4f6;
    }
    .invoice-container {
      position: relative;
      width: 800px;
      margin: auto;
      background: white;
      padding: 20px;
    }
    .letterhead {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      z-index: -1;
      opacity: 0.2; /* faint background */
    }
  </style>
</head>
<body>
  <div class="invoice-container shadow-lg">
    <!-- Letterhead background -->
    <?php if(!empty($settings['letterhead'])): ?>
      <img src="../../<?= $settings['letterhead'] ?>" class="letterhead">
    <?php endif; ?>

    <!-- Header with logo + company info -->
    <div class="flex justify-between items-center mb-6">
      <div>
        <?php if(!empty($settings['logo'])): ?>
          <img src="../../<?= $settings['logo'] ?>" class="h-16 mb-2">
        <?php endif; ?>
        <h2 class="text-xl font-bold"><?= $settings['company_name'] ?? '' ?></h2>
        <p><?= $settings['address'] ?? '' ?></p>
        <p><?= $settings['phone'] ?? '' ?> | <?= $settings['email'] ?? '' ?></p>
      </div>
      <div class="text-right">
        <h3 class="text-lg font-bold">Invoice</h3>
        <p>No: <?= $invoice_no ?></p>
        <p>Date: <?= $invoice_date ?></p>
      </div>
    </div>

    <!-- Customer Info -->
    <div class="mb-4">
      <h4 class="font-semibold">Bill To:</h4>
      <p><?= $customer_name ?></p>
      <p><?= $customer_phone ?></p>
    </div>

    <!-- Items -->
    <table class="w-full border-collapse border border-gray-300 mb-6">
      <thead>
        <tr class="bg-gray-100">
          <th class="border p-2">Item</th>
          <th class="border p-2">Qty</th>
          <th class="border p-2">Price</th>
          <th class="border p-2">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($items as $i): ?>
          <tr>
            <td class="border p-2"><?= $i['name'] ?></td>
            <td class="border p-2 text-center"><?= $i['qty'] ?></td>
            <td class="border p-2 text-right"><?= number_format($i['price']) ?></td>
            <td class="border p-2 text-right"><?= number_format($i['qty'] * $i['price']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="3" class="border p-2 text-right font-bold">Total</td>
          <td class="border p-2 text-right font-bold"><?= number_format($total) ?></td>
        </tr>
      </tfoot>
    </table>

    <!-- Footer -->
    <div class="text-center text-sm mt-10">
      <p>Thank you for your business!</p>
    </div>
  </div>

  <div class="text-center mt-4">
    <button onclick="window.print()" class="bg-blue-600 text-white px-4 py-2 rounded">🖨 Print Invoice</button>
  </div>
</body>
</html>
