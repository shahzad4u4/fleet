<?php
require_once __DIR__ . "/db.php";

// Optional delete via query param (redirects to dedicated delete page for confirmation UX)
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    header("Location: delete_invoice.php?id=".$id);
    exit();
}

$q = isset($_GET['q']) ? trim($_GET['q']) : "";
$where = "";
if ($q !== "") {
    $qEsc = $conn->real_escape_string($q);
    $where = "WHERE invoices.invoice_no LIKE '%$qEsc%' OR invoices.customer_name LIKE '%$qEsc%' OR vehicles.reg_no LIKE '%$qEsc%'";
}

$sql = "SELECT invoices.*, vehicles.reg_no 
        FROM invoices 
        JOIN vehicles ON invoices.vehicle_id = vehicles.id
        $where
        ORDER BY invoices.id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice List</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:1200px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
table{width:100%;border-collapse:collapse;margin-top:16px}th,td{border:1px solid #e5e5e5;padding:10px;text-align:center}th{background:#f8fafc}
.actions a{padding:6px 10px;border-radius:6px;text-decoration:none;margin:0 4px;display:inline-block}
.searchbar{margin-top:12px}input[type="text"]{padding:8px;border:1px solid #ccc;border-radius:6px;width:300px}
.badge{padding:4px 8px;border-radius:10px;display:inline-block}
.badge.Paid{background:#dcfce7} .badge.Unpaid{background:#fee2e2} .badge.Pending{background:#fef9c3}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h2>Invoice List</h2>
    <a class="btn" href="add_invoice.php">+ Add Invoice</a>
  </div>
  <div class="searchbar">
    <form method="get">
      <input type="text" name="q" placeholder="Search (Invoice No, Customer, Vehicle)" value="<?= htmlspecialchars($q) ?>">
      <button class="btn" type="submit">Search</button>
    </form>
  </div>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Vehicle</th>
        <th>Invoice No</th>
        <th>Customer</th>
        <th>Invoice Date</th>
        <th>Due Date</th>
        <th>Amount</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['reg_no']) ?></td>
        <td><?= htmlspecialchars($row['invoice_no']) ?></td>
        <td><?= htmlspecialchars($row['customer_name']) ?></td>
        <td><?= htmlspecialchars($row['invoice_date']) ?></td>
        <td><?= htmlspecialchars($row['due_date']) ?></td>
        <td><?= number_format($row['amount'], 2) ?></td>
        <td><span class="badge <?= htmlspecialchars($row['status']) ?>"><?= htmlspecialchars($row['status']) ?></span></td>
        <td class="actions">
          <a href="edit_invoice.php?id=<?= $row['id'] ?>">Edit</a>
          <a href="delete_invoice.php?id=<?= $row['id'] ?>">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
