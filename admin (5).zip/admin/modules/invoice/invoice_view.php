
<?php
include 'db.php';
$id = intval($_GET['id'] ?? 0);
$inv = $conn->query("SELECT i.*, t.pickup_location, t.drop_location, v.reg_no, d.name as driver
                     FROM invoices i 
                     JOIN trips t ON i.trip_id=t.id
                     JOIN vehicles v ON t.vehicle_id=v.id
                     JOIN drivers d ON t.driver_id=d.id
                     WHERE i.id=$id")->fetch_assoc();
if(!$inv){ die("Invoice not found"); }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Invoice #<?php echo $inv['id']; ?></title>
  <style>
    body{font-family:Arial;margin:20px}
    .invoice{max-width:800px;margin:auto;border:1px solid #ddd;padding:20px;border-radius:10px}
    .header{display:flex;justify-content:space-between;align-items:center}
    .muted{color:#555}
    table{width:100%;border-collapse:collapse;margin-top:20px}
    th,td{border:1px solid #ddd;padding:10px;text-align:left}
    th{background:#f8f8f8}
    .right{text-align:right}
    .btn{padding:8px 12px;border:1px solid #333;background:#fff;border-radius:6px;cursor:pointer}
    .center{text-align:center;margin-top:10px}
  </style>
</head>
<body>
<div class="invoice" id="printable">
  <div class="header">
    <div>
      <h2>Invoice #<?php echo $inv['id']; ?></h2>
      <div class="muted">Issue: <?php echo $inv['issue_date']; ?><?php if($inv['due_date']) echo " | Due: ".$inv['due_date']; ?></div>
      <div class="muted">Status: <?php echo $inv['status']; ?></div>
    </div>
    <div style="text-align:right">
      <strong>Company</strong><br>
      Your Company Name<br>
      Address line 1<br>
      Phone: 0000-0000000
    </div>
  </div>

  <h3>Bill To</h3>
  <p>
    <strong><?php echo htmlspecialchars($inv['client_name']); ?></strong><br>
    <?php echo nl2br(htmlspecialchars($inv['client_address'])); ?><br>
    <?php echo htmlspecialchars($inv['client_phone']); ?>
  </p>

  <h3>Trip Details</h3>
  <table>
    <tr><th>Vehicle</th><th>Driver</th><th>Route</th></tr>
    <tr>
      <td><?php echo $inv['reg_no']; ?></td>
      <td><?php echo $inv['driver']; ?></td>
      <td><?php echo $inv['pickup_location']; ?> → <?php echo $inv['drop_location']; ?></td>
    </tr>
  </table>

  <h3>Amount</h3>
  <table>
    <tr><th>Description</th><th class="right">Amount (PKR)</th></tr>
    <tr><td>Trip Charges</td><td class="right"><?php echo number_format($inv['subtotal'],2); ?></td></tr>
    <tr><td>Tax (<?php echo $inv['tax_percent']; ?>%)</td><td class="right"><?php echo number_format($inv['subtotal']*$inv['tax_percent']/100,2); ?></td></tr>
    <tr><td>Discount</td><td class="right">-<?php echo number_format($inv['discount'],2); ?></td></tr>
    <tr><th>Total</th><th class="right"><?php echo number_format($inv['total'],2); ?></th></tr>
  </table>

  <?php if(!empty($inv['notes'])){ ?>
  <p><strong>Notes:</strong><br><?php echo nl2br(htmlspecialchars($inv['notes'])); ?></p>
  <?php } ?>
</div>

<div class="center">
  <button class="btn" onclick="window.print()">Print / Save as PDF</button>
  <a class="btn" href="generate_pdf.php?id=<?php echo $inv['id']; ?>" target="_blank">Download PDF</a>
</div>
</body>
</html>
