# Fleet Invoice Module (PHP + MySQL)

This bundle includes a minimal Invoice system linked to vehicles:

- `add_invoice.php` — create invoice
- `invoice_list.php` — search/list invoices
- `edit_invoice.php` — update invoice
- `delete_invoice.php` — confirm & delete
- `schema.sql` — table DDL
- `db.php` — DB connection (same db as vehicle module)

## Setup
1) Copy files to your server folder, e.g. `htdocs/fleet/`.
2) Import `schema.sql` into your `fleet` database (or edit credentials in `db.php`).
3) Ensure you already have the `vehicles` table (from the Vehicle Module).
4) Open:
   - `http://localhost/fleet/add_invoice.php`
   - `http://localhost/fleet/invoice_list.php`

Tip: For production, add authentication and prepared statements.
