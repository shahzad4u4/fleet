
<?php
// Simple DOMPDF integration. Requires dompdf library installed.
// If dompdf is not installed, the script will show a helpful message.

$id = intval($_GET['id'] ?? 0);

if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
  echo "<p style='font-family:Arial'>❗ DOMPDF not installed.<br>
        Run <code>composer require dompdf/dompdf</code> in your project root, then revisit this page.<br>
        As an alternative, open <code>invoice_view.php?id=$id</code> and use the <b>Print / Save as PDF</b> button.</p>";
  exit;
}

require __DIR__ . '/vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

include 'db.php';

$inv = $conn->query("SELECT i.*, t.pickup_location, t.drop_location, v.reg_no, d.name as driver
                     FROM invoices i 
                     JOIN trips t ON i.trip_id=t.id
                     JOIN vehicles v ON t.vehicle_id=v.id
                     JOIN drivers d ON t.driver_id=d.id
                     WHERE i.id=$id")->fetch_assoc();
if(!$inv){ die("Invoice not found"); }

ob_start();
include 'invoice_view.php';
$html = ob_get_clean();

// Extract only the invoice div for PDF
$pattern = '/<div class=\"invoice\".*?<\/div>/s';
if (preg_match($pattern, $html, $m)) {
  $html = '<html><head><meta charset=\"utf-8\"></head><body>'.$m[0].'</body></html>';
}

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('invoice-'.$inv['id'].'.pdf');
