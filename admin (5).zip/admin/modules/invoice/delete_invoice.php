<?php
require_once __DIR__ . "/db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (isset($_POST['confirm'])) {
    $conn->query("DELETE FROM invoices WHERE id=$id");
    header("Location: invoice_list.php");
    exit();
}

$inv = $conn->query("SELECT invoices.*, vehicles.reg_no FROM invoices JOIN vehicles ON vehicles.id=invoices.vehicle_id WHERE invoices.id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Delete Invoice</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:600px;margin:0 auto}
.card{background:#fff;border:1px solid #e5e5e5;border-radius:8px;padding:16px}
h3{margin-top:0}.row{margin:6px 0}.danger{color:#b91c1c}
.btn{padding:8px 12px;border-radius:6px;text-decoration:none;display:inline-block;margin-right:8px}
.btn-danger{background:#ef4444;color:#fff}.btn-secondary{background:#9ca3af;color:#fff}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h3 class="danger">Are you sure you want to delete this invoice?</h3>
    <?php if($inv): ?>
      <div class="row"><strong>ID:</strong> <?= $inv['id'] ?></div>
      <div class="row"><strong>Vehicle:</strong> <?= htmlspecialchars($inv['reg_no']) ?></div>
      <div class="row"><strong>Invoice No:</strong> <?= htmlspecialchars($inv['invoice_no']) ?></div>
      <div class="row"><strong>Customer:</strong> <?= htmlspecialchars($inv['customer_name']) ?></div>
      <div class="row"><strong>Amount:</strong> <?= number_format($inv['amount'],2) ?></div>
    <?php else: ?>
      <p>Invoice not found.</p>
    <?php endif; ?>
    <form method="post" style="margin-top:12px">
      <button class="btn btn-danger" type="submit" name="confirm">Yes, Delete</button>
      <a class="btn btn-secondary" href="invoice_list.php">Cancel</a>
    </form>
  </div>
</div>
</body>
</html>
