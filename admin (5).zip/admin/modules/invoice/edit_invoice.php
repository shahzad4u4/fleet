<?php
require_once __DIR__ . "/db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = $conn->query("SELECT * FROM invoices WHERE id=$id");
if (!$res || !$res->num_rows) { die("Invoice not found."); }
$inv = $res->fetch_assoc();

if (isset($_POST['update'])) {
    $vehicle_id    = (int)$_POST['vehicle_id'];
    $invoice_no    = $conn->real_escape_string($_POST['invoice_no']);
    $customer_name = $conn->real_escape_string($_POST['customer_name']);
    $invoice_date  = $conn->real_escape_string($_POST['invoice_date']);
    $due_date      = $conn->real_escape_string($_POST['due_date']);
    $amount        = (float)$_POST['amount'];
    $status        = $conn->real_escape_string($_POST['status']);
    $notes         = $conn->real_escape_string($_POST['notes'] ?? "");

    $sql = "UPDATE invoices SET
                vehicle_id=$vehicle_id,
                invoice_no='$invoice_no',
                customer_name='$customer_name',
                invoice_date='$invoice_date',
                due_date='$due_date',
                amount=$amount,
                status='$status',
                notes='$notes'
            WHERE id=$id";
    if ($conn->query($sql)) {
        header("Location: invoice_list.php");
        exit();
    } else {
        $err = "Error: " . $conn->error;
    }
}
$vehicles = $conn->query("SELECT id, reg_no FROM vehicles ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Invoice</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:720px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
form{background:#fafafa;padding:16px;border:1px solid #e5e5e5;border-radius:8px}label{font-weight:600;display:block;margin-top:10px}
input,select,textarea{width:100%;padding:10px;margin-top:6px;border:1px solid #ccc;border-radius:6px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.actions{margin-top:16px}
button{padding:10px 14px;background:#f59e0b;border:none;color:#fff;border-radius:6px;cursor:pointer}
.err{color:#b91c1c;font-weight:600}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h2>Edit Invoice</h2>
    <a class="btn" href="invoice_list.php">Back to List</a>
  </div>
  <?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>
  <form method="post">
    <label>Vehicle</label>
    <select name="vehicle_id" required>
      <?php while($v = $vehicles->fetch_assoc()): ?>
        <option value="<?= $v['id'] ?>" <?= $inv['vehicle_id']==$v['id'] ? 'selected' : '' ?>><?= htmlspecialchars($v['reg_no']) ?></option>
      <?php endwhile; ?>
    </select>

    <div class="row">
      <div>
        <label>Invoice No</label>
        <input type="text" name="invoice_no" value="<?= htmlspecialchars($inv['invoice_no']) ?>" required>
      </div>
      <div>
        <label>Customer Name</label>
        <input type="text" name="customer_name" value="<?= htmlspecialchars($inv['customer_name']) ?>" required>
      </div>
      <div>
        <label>Invoice Date</label>
        <input type="date" name="invoice_date" value="<?= htmlspecialchars($inv['invoice_date']) ?>" required>
      </div>
      <div>
        <label>Due Date</label>
        <input type="date" name="due_date" value="<?= htmlspecialchars($inv['due_date']) ?>" required>
      </div>
      <div>
        <label>Amount</label>
        <input type="number" step="0.01" name="amount" value="<?= htmlspecialchars($inv['amount']) ?>" required>
      </div>
      <div>
        <label>Status</label>
        <select name="status">
            <option value="Unpaid" <?= $inv['status']=='Unpaid'?'selected':''; ?>>Unpaid</option>
            <option value="Paid" <?= $inv['status']=='Paid'?'selected':''; ?>>Paid</option>
            <option value="Pending" <?= $inv['status']=='Pending'?'selected':''; ?>>Pending</option>
        </select>
      </div>
    </div>

    <label>Notes</label>
    <textarea name="notes" rows="3"><?= htmlspecialchars($inv['notes']) ?></textarea>

    <div class="actions">
      <button type="submit" name="update">Update Invoice</button>
    </div>
  </form>
</div>
</body>
</html>
