
  </div>
  <footer class="md:ml-64 px-4 py-6 text-center text-xs text-slate-500">
    © <?= date('Y') ?> Fleet System — Bookings Module.
  </footer>
</body>
</html>
