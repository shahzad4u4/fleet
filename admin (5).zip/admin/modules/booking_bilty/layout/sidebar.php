
<!-- Sidebar -->
<aside id="sidebar" class="w-64 bg-white border-r border-slate-200 p-4 space-y-2 fixed inset-y-0 left-0 transform -translate-x-full md:translate-x-0 transition-transform duration-200 ease-in-out z-40">
  <div class="flex items-center justify-between">
    <a href="dashboard.php" class="text-lg font-bold">Fleet System</a>
    <button class="md:hidden p-2" onclick="toggleSidebar()">✕</button>
  </div>
  <nav class="mt-4 space-y-1 text-sm">
    <a href="dashboard.php" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Dashboard</a>
    <a href="booking_add.php" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Add Booking</a>
    <a href="booking_list.php" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Bookings List</a>
  </nav>
</aside>
<div id="overlay" class="fixed inset-0 bg-black/30 z-30 hidden md:hidden" onclick="toggleSidebar()"></div>
<script>
function toggleSidebar(){
  const s = document.getElementById('sidebar');
  const o = document.getElementById('overlay');
  if(s.classList.contains('-translate-x-full')){ s.classList.remove('-translate-x-full'); o.classList.remove('hidden'); }
  else { s.classList.add('-translate-x-full'); o.classList.add('hidden'); }
}
</script>
