
<?php
include 'db.php';
$id = intval($_GET['id'] ?? 0);
$status = $_GET['status'] ?? 'Pending';
$allowed = ['Pending','In-Transit','Delivered','Cancelled'];
if(!in_array($status, $allowed)) $status = 'Pending';
$conn->query("UPDATE bookings SET status='$status' WHERE id=$id");
header("Location: booking_list.php");
exit;
