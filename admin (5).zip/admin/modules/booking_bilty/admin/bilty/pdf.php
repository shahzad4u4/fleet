<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager','staff']);
require __DIR__ . '/../../lib/db.php';

$id = (int)($_GET['id'] ?? 0);
$lang = strtolower($_GET['lang'] ?? 'en'); // 'en' or 'ur'

$stmt = pdo()->prepare("SELECT * FROM bilty WHERE id=?");
$stmt->execute([$id]);
$B = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$B){ die('Not found'); }

$S = function_exists('get_settings') ? (get_settings() ?? []) : [];
$logo = !empty($S['logo_path']) ? ('/'.trim($S['logo_path'],'/')) : '';
$letterhead = !empty($S['letterhead_path']) ? ('/'.trim($S['letterhead_path'],'/')) : '';
$pub_link = base_url('/public/bilty/view.php?token=' . urlencode($B['share_token']));

// Labels
$L = [
  'title' => $lang==='ur' ? 'بلٹی' : 'Bilty',
  'transporter' => $lang==='ur' ? 'ٹرांसپورٹر' : 'Transporter',
  'vehicle' => $lang==='ur' ? 'گاڑی نمبر' : 'Vehicle',
  'from' => $lang==='ur' ? 'جہاں سے' : 'From',
  'to' => $lang==='ur' ? 'جہاں تک' : 'To',
  'distance' => $lang==='ur' ? 'فاصلہ (کلومیٹر)' : 'Distance (KM)',
  'payment' => $lang==='ur' ? 'ادائیگی' : 'Payment',
  'amount' => $lang==='ur' ? 'رقم' : 'Amount',
  'goods' => $lang==='ur' ? 'سامان / نوٹس' : 'Goods / Remarks',
  'scan' => $lang==='ur' ? 'اس لنک کے لیے QR اسکین کریں' : 'Scan QR for link'
];

$html = '<html><head><meta charset="utf-8"><style>
body{font-family: DejaVu Sans, Arial, sans-serif; font-size:12px;}
.header{display:flex;align-items:center;margin-bottom:10px;border-bottom:1px solid #ccc;padding-bottom:8px;}
.header img{max-height:60px;margin-right:10px;}
.h-title{font-size:18px;font-weight:bold;}
.table{width:100%;border-collapse:collapse;margin-top:10px;}
.table th,.table td{border:1px solid #ddd;padding:6px;text-align:left;}
.small{color:#777;font-size:11px;}
.right{ text-align:right; }
.flex{ display:flex; justify-content:space-between; align-items:center; gap:10px;}
.qr{ text-align:center; }
</style></head><body>';

if ($letterhead) { $html .= '<div><img src="'.$letterhead.'" style="width:100%;max-height:180px"></div>'; }

$html .= '<div class="header">';
if ($logo) { $html .= '<img src="'.$logo.'" />'; }
$html .= '<div><div class="h-title">'.$L['title'].' #'.htmlspecialchars($B['bilty_number']).'</div>
<div class="small">'.htmlspecialchars($S['company_name'] ?? 'Company').'</div></div></div>';

$html .= '<div class="flex"><div style="flex:1">';
$html .= '<table class="table">
<tr><th>'.$L['transporter'].'</th><td>'.htmlspecialchars($B['transporter_name']).'</td>
    <th>'.$L['vehicle'].'</th><td>'.htmlspecialchars($B['vehicle_number']).'</td></tr>
<tr><th>'.$L['from'].'</th><td>'.htmlspecialchars($B['from_location']).'</td>
    <th>'.$L['to'].'</th><td>'.htmlspecialchars($B['to_location']).'</td></tr>
<tr><th>'.$L['distance'].'</th><td>'.htmlspecialchars($B['distance_km']).'</td>
    <th>'.$L['payment'].'</th><td>'.htmlspecialchars($B['payment_mode']).' / '.number_format((float)$B['amount'],2).'</td></tr>
<tr><th colspan="1">'.$L['goods'].'</th><td colspan="3">'.nl2br(htmlspecialchars($B['goods_description'])).'</td></tr>
</table>';
$html .= '</div><div class="qr" style="min-width:140px">';
$qrlink = 'https://api.qrserver.com/v1/create-qr-code/?size=130x130&data='.urlencode($pub_link);
$html .= '<img src="'.$qrlink.'" alt="QR"><div class="small">'.$L['scan'].'</div>';
$html .= '</div></div>';

$html .= '<div class="small" style="margin-top:14px">'.htmlspecialchars($S['invoice_footer'] ?? '').'</div>';
$html .= '</body></html>';

// Dompdf if available
$vendor = __DIR__ . '/../../vendor/autoload.php';
if (is_file($vendor)) {
  require_once $vendor;
  $dompdf = new Dompdf\Dompdf();
  $dompdf->loadHtml($html);
  $dompdf->setPaper('A4', 'portrait');
  $dompdf->render();
  $dompdf->stream('bilty_'.$B['bilty_number'].'.pdf', ['Attachment' => false]);
  exit;
}

// fallback
header('Content-Type: text/html; charset=utf-8');
echo $html;
