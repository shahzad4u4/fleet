<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin']); // only admin can create
require __DIR__ . '/../../lib/db.php';

$errors = [];
$ok = false;

// Pre-fill support (from booking, if any)
$prefill = $_SESSION['bilty_prefill'] ?? [];
unset($_SESSION['bilty_prefill']);

// Handle post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $bilty_number     = trim($_POST['bilty_number'] ?? '');
  $transporter_name = trim($_POST['transporter_name'] ?? '');
  $vehicle_number   = trim($_POST['vehicle_number'] ?? '');
  $from_location    = trim($_POST['from_location'] ?? '');
  $to_location      = trim($_POST['to_location'] ?? '');
  $distance_km      = trim($_POST['distance_km'] ?? '');
  $payment_mode     = trim($_POST['payment_mode'] ?? '');
  $amount           = trim($_POST['amount'] ?? '');
  $goods_description= trim($_POST['goods_description'] ?? '');

  // validate
  if ($bilty_number==='')      $errors[]='Bilty Number required';
  if ($transporter_name==='')  $errors[]='Transporter Name required';
  if ($vehicle_number==='')    $errors[]='Vehicle Number required';
  if ($from_location==='')     $errors[]='From required';
  if ($to_location==='')       $errors[]='To required';
  if ($distance_km==='')       $errors[]='Distance required';
  if ($payment_mode==='')      $errors[]='Payment Mode required';
  if ($amount==='')            $errors[]='Amount required';
  if ($goods_description==='') $errors[]='Goods/Remarks required';

  // upload
  $savedFile = null;
  if (!empty($_FILES['bilty_file']['name'])) {
    $savedFile = handle_upload('bilty_file', 'uploads/bilty');
    if (!$savedFile) $errors[] = 'File upload failed';
  }

  if (!$errors) {
    $stmt = pdo()->prepare("INSERT INTO bilty 
      (bilty_number, transporter_name, vehicle_number, from_location, to_location, distance_km, payment_mode, amount, goods_description, bilty_file, created_by, created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())");
    $stmt->execute([
      $bilty_number, $transporter_name, $vehicle_number, $from_location, $to_location,
      $distance_km, $payment_mode, $amount, $goods_description, $savedFile, ($_SESSION['user']['id'] ?? 0)
    ]);
    $ok = true;
  }
}

$F = [
  'bilty_number'     => $_POST['bilty_number']     ?? '',
  'transporter_name' => $_POST['transporter_name'] ?? '',
  'vehicle_number'   => $_POST['vehicle_number']   ?? '',
  'from_location'    => $_POST['from_location']    ?? ($prefill['origin'] ?? ''),
  'to_location'      => $_POST['to_location']      ?? ($prefill['destination'] ?? ''),
  'distance_km'      => $_POST['distance_km']      ?? ($prefill['distance_km'] ?? ''),
  'payment_mode'     => $_POST['payment_mode']     ?? '',
  'amount'           => $_POST['amount']           ?? ($prefill['freight_amount'] ?? ''),
  'goods_description'=> $_POST['goods_description']?? ''
];

?>
<?php
// Soft-include project header (Bootstrap, layout, session)
$__tplHeader = __DIR__ . '/../../templates/header.php';
if (is_file($__tplHeader)) { include $__tplHeader; } else {
    // Minimal standalone head if template missing
    ?><!doctype html><html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bilty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head><body class="bg-light"><div class="container py-4"><?php
}
?>
<div class="d-flex align-items-center mb-3">
  <h3 class="mb-0">New Bilty</h3>
  <a class="btn btn-outline-secondary ms-auto" href="index.php">Back to List</a>
</div>
<?php if($ok): ?>
  <div class="alert alert-success">Bilty added successfully.</div>
<?php endif; ?>
<?php if(!empty($errors)): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e){ echo '<li>'.htmlspecialchars($e).'</li>'; } ?></ul></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card p-3 shadow-sm bg-white">
<?php $F = $F; include __DIR__ . '/_form.php'; ?>
</form>

<?php
$__tplFooter = __DIR__ . '/../../templates/footer.php';
if (is_file($__tplFooter)) { include $__tplFooter; } else {
    ?></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body></html><?php
}
?>