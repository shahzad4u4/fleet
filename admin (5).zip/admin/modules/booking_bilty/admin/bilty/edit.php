<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin']); // only admin can edit/delete
require __DIR__ . '/../../lib/db.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = pdo()->prepare("SELECT * FROM bilty WHERE id=?");
$stmt->execute([$id]);
$B = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$B){ die('Not found'); }

$errors = []; $ok=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
  $bilty_number     = trim($_POST['bilty_number'] ?? '');
  $transporter_name = trim($_POST['transporter_name'] ?? '');
  $vehicle_number   = trim($_POST['vehicle_number'] ?? '');
  $from_location    = trim($_POST['from_location'] ?? '');
  $to_location      = trim($_POST['to_location'] ?? '');
  $distance_km      = trim($_POST['distance_km'] ?? '');
  $payment_mode     = trim($_POST['payment_mode'] ?? '');
  $amount           = trim($_POST['amount'] ?? '');
  $goods_description= trim($_POST['goods_description'] ?? '');

  if ($bilty_number==='')      $errors[]='Bilty Number required';
  if ($transporter_name==='')  $errors[]='Transporter Name required';
  if ($vehicle_number==='')    $errors[]='Vehicle Number required';
  if ($from_location==='')     $errors[]='From required';
  if ($to_location==='')       $errors[]='To required';
  if ($distance_km==='')       $errors[]='Distance required';
  if ($payment_mode==='')      $errors[]='Payment Mode required';
  if ($amount==='')            $errors[]='Amount required';
  if ($goods_description==='') $errors[]='Goods/Remarks required';

  $savedFile = $B['bilty_file'];
  if (!empty($_FILES['bilty_file']['name'])) {
    $tmp = handle_upload('bilty_file', 'uploads/bilty');
    if ($tmp) $savedFile = $tmp; else $errors[]='File upload failed';
  }

  if(!$errors){
    $upd = pdo()->prepare("UPDATE bilty SET bilty_number=?, transporter_name=?, vehicle_number=?, from_location=?, to_location=?, distance_km=?, payment_mode=?, amount=?, goods_description=?, bilty_file=? WHERE id=?");
    $upd->execute([$bilty_number,$transporter_name,$vehicle_number,$from_location,$to_location,$distance_km,$payment_mode,$amount,$goods_description,$savedFile,$id]);
    $ok=true;
    // refresh current record
    $stmt->execute([$id]);
    $B = $stmt->fetch(PDO::FETCH_ASSOC);
  }
}

$F = $B;
?>
<?php
// Soft-include project header (Bootstrap, layout, session)
$__tplHeader = __DIR__ . '/../../templates/header.php';
if (is_file($__tplHeader)) { include $__tplHeader; } else {
    // Minimal standalone head if template missing
    ?><!doctype html><html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bilty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head><body class="bg-light"><div class="container py-4"><?php
}
?>
<div class="d-flex align-items-center mb-3">
  <h3 class="mb-0">Edit Bilty</h3>
  <a class="btn btn-outline-secondary ms-auto" href="index.php">Back to List</a>
</div>
<?php if($ok): ?><div class="alert alert-success">Updated.</div><?php endif; ?>
<?php if(!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e){ echo '<li>'.htmlspecialchars($e).'</li>'; } ?></ul></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card p-3 shadow-sm bg-white">
<?php include __DIR__ . '/_form.php'; ?>
</form>

<?php
$__tplFooter = __DIR__ . '/../../templates/footer.php';
if (is_file($__tplFooter)) { include $__tplFooter; } else {
    ?></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body></html><?php
}
?>