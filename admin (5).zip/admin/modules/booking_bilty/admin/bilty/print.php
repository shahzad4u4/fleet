<?php
// /admin/bilty/print.php (print-friendly with letterhead/logo)
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager','staff']);

$id = (int)($_GET['id'] ?? 0);
$stmt = pdo()->prepare("SELECT b.*, c.name AS customer_name, c.phone AS customer_phone,
                               t.name AS transporter_name,
                               ci.name AS company_name, ci.logo_path,
                               s.invoice_footer, lh.image_path AS letterhead_path
                        FROM bilty b
                        LEFT JOIN bookings k ON k.id=b.booking_id
                        LEFT JOIN customers c ON c.id=k.customer_id
                        LEFT JOIN transporters t ON t.id=b.transporter_id
                        LEFT JOIN company_info ci ON ci.id=1
                        LEFT JOIN settings s ON s.id=1
                        LEFT JOIN letterheads lh ON lh.id=ci.default_letterhead_id
                        WHERE b.id=?");
$stmt->execute([$id]);
$r = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$r){ die('Not found'); }

header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="ur" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>پرنٹ بِلٹی <?= htmlspecialchars($r['bilty_no']) ?></title>
  <style>
    body { font-family: DejaVu Sans, Arial, Noto Nastaliq Urdu, Tahoma; margin:0; padding:0; }
    .sheet { width: 210mm; min-height: 297mm; padding: 15mm; margin: auto; background: #fff; }
    .lh { margin-bottom: 10mm; }
    .head { display:flex; align-items:center; justify-content:space-between; }
    .logo { height: 60px; }
    table { width:100%; border-collapse: collapse; margin-top:10px; }
    th, td { border: 1px solid #ddd; padding: 8px; }
    .muted { color:#666; font-size: 12px; }
    @media print { .no-print { display:none; } .sheet { box-shadow:none; margin:0; } }
  </style>
</head>
<body>
  <div class="no-print" style="text-align:center;margin:10px">
    <button onclick="window.print()">پرنٹ</button>
  </div>
  <div class="sheet">
    <?php if(!empty($r['letterhead_path'])): ?>
      <div class="lh"><img src="<?= base_url('/'.htmlspecialchars($r['letterhead_path'])) ?>" style="width:100%"></div>
    <?php endif; ?>

    <div class="head">
      <div>
        <h2 style="margin:0">بِلٹی</h2>
        <div class="muted"># <?= htmlspecialchars($r['bilty_no']) ?> — <?= htmlspecialchars($r['issue_date']) ?></div>
      </div>
      <div>
        <?php if(!empty($r['logo_path'])): ?>
          <img class="logo" src="<?= base_url('/'.htmlspecialchars($r['logo_path'])) ?>">
        <?php endif; ?>
      </div>
    </div>

    <table>
      <tr><th style="width:30%">کسٹمر</th><td><?= htmlspecialchars($r['customer_name'] ?? '-') ?></td></tr>
      <tr><th>فون</th><td><?= htmlspecialchars($r['customer_phone'] ?? '-') ?></td></tr>
      <tr><th>ٹرانسپورٹر</th><td><?= htmlspecialchars($r['transporter_name'] ?? '-') ?></td></tr>
      <tr><th>روٹ</th><td><?= htmlspecialchars(($r['origin'] ?? '').' → '.($r['destination'] ?? '')) ?></td></tr>
      <tr><th>وزن (KG)</th><td><?= htmlspecialchars($r['weight_kg'] ?? '-') ?></td></tr>
      <tr><th>تعداد</th><td><?= htmlspecialchars($r['quantity'] ?? '-') ?></td></tr>
      <tr><th>کرایہ</th><td><?= number_format((float)($r['freight_amount'] ?? 0),2) ?></td></tr>
      <tr><th>نوٹس</th><td><?= htmlspecialchars($r['remarks'] ?? '-') ?></td></tr>
    </table>

    <?php if(!empty($r['file_path'])): ?>
      <p class="muted">منسلک فائل: <?= htmlspecialchars(basename($r['file_path'])) ?></p>
    <?php endif; ?>

    <?php if(!empty($r['invoice_footer'])): ?>
      <div style="margin-top:20mm" class="muted"><?= nl2br(htmlspecialchars($r['invoice_footer'])) ?></div>
    <?php endif; ?>
  </div>
</body>
</html>
