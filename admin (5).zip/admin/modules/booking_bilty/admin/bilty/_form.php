<?php
// admin/bilty/_form.php (included by new.php and edit.php)
$F = $F ?? []; // field values
$isEdit = isset($F['id']);
?>
<div class="row g-3">
  <div class="col-md-4">
    <label class="form-label">Bilty Number</label>
    <input type="text" name="bilty_number" class="form-control" required
           value="<?= htmlspecialchars($F['bilty_number'] ?? ($_POST['bilty_number'] ?? '')) ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">Transporter Name</label>
    <input type="text" name="transporter_name" class="form-control" required
           value="<?= htmlspecialchars($F['transporter_name'] ?? ($_POST['transporter_name'] ?? '')) ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">Vehicle Number</label>
    <input type="text" name="vehicle_number" class="form-control" required
           value="<?= htmlspecialchars($F['vehicle_number'] ?? ($_POST['vehicle_number'] ?? '')) ?>">
  </div>

  <div class="col-md-6">
    <label class="form-label">From (Origin)</label>
    <input type="text" name="from_location" class="form-control" required
           value="<?= htmlspecialchars($F['from_location'] ?? ($_POST['from_location'] ?? '')) ?>">
  </div>
  <div class="col-md-6">
    <label class="form-label">To (Destination)</label>
    <input type="text" name="to_location" class="form-control" required
           value="<?= htmlspecialchars($F['to_location'] ?? ($_POST['to_location'] ?? '')) ?>">
  </div>

  <div class="col-md-4">
    <label class="form-label">Distance (KM)</label>
    <input type="number" step="0.01" name="distance_km" class="form-control" required
           value="<?= htmlspecialchars($F['distance_km'] ?? ($_POST['distance_km'] ?? '')) ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">Payment Mode</label>
    <select name="payment_mode" class="form-select" required>
      <?php $pm = ($F['payment_mode'] ?? ($_POST['payment_mode'] ?? '')); ?>
      <option value="">Select</option>
      <option value="Cash"   <?= $pm==='Cash'?'selected':'' ?>>Cash</option>
      <option value="Cheque" <?= $pm==='Cheque'?'selected':'' ?>>Cheque</option>
    </select>
  </div>
  <div class="col-md-4">
    <label class="form-label">Amount</label>
    <input type="number" step="0.01" name="amount" class="form-control" required
           value="<?= htmlspecialchars($F['amount'] ?? ($_POST['amount'] ?? '')) ?>">
  </div>

  <div class="col-md-12">
    <label class="form-label">Goods / Remarks</label>
    <textarea name="goods_description" class="form-control" rows="3" required><?= htmlspecialchars($F['goods_description'] ?? ($_POST['goods_description'] ?? '')) ?></textarea>
  </div>

  <div class="col-md-6">
    <label class="form-label">Attach Bilty (image/PDF)</label>
    <input type="file" name="bilty_file" class="form-control" <?= $isEdit ? '' : '' ?>>
    <?php if (!empty($F['bilty_file'])): ?>
      <div class="form-text mt-1">Current: <a target="_blank" href="<?= htmlspecialchars('/'.trim($F['bilty_file'],'/')) ?>">View/Download</a></div>
    <?php endif; ?>
  </div>

  <div class="col-12">
    <button class="btn btn-primary"><?= $isEdit ? 'Update Bilty' : 'Save Bilty' ?></button>
    <a class="btn btn-secondary" href="index.php">Cancel</a>
  </div>
</div>
