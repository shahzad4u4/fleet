<?php
// /admin/bilty/from_booking.php
// Create a new Bilty pre-filled from a booking (or auto-insert)
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager','staff']);

$booking_id = (int)($_GET['booking_id'] ?? 0);
if (!$booking_id) { die('booking_id required'); }

$bk = pdo()->prepare("SELECT id, pickup_location, drop_location, estimated_distance_km, customer_id, amount FROM bookings WHERE id=?");
$bk->execute([$booking_id]);
$B = $bk->fetch(PDO::FETCH_ASSOC);
if (!$B) { die('Booking not found'); }

// Pre-fill and redirect to new.php with initial values via session flash
$_SESSION['bilty_prefill'] = [
  'booking_id' => $B['id'],
  'origin' => $B['pickup_location'],
  'destination' => $B['drop_location'],
  'freight_amount' => $B['amount'],
];

header('Location: '.base_url('/admin/bilty/new.php'));
