<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin']); // only admin
require __DIR__ . '/../../lib/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id) {
  $stmt = pdo()->prepare("DELETE FROM bilty WHERE id=?");
  $stmt->execute([$id]);
}
header('Location: index.php');
exit;
