<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager']);
require __DIR__ . '/../../lib/db.php';

$id = (int)($_GET['id'] ?? 0);
$channel = strtolower($_GET['channel'] ?? 'whatsapp');
$to = trim($_GET['to'] ?? '');

$stmt = pdo()->prepare("SELECT * FROM bilty WHERE id=?");
$stmt->execute([$id]);
$B = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$B){ die('Not found'); }

$S = function_exists('get_settings') ? (get_settings() ?? []) : [];
if ($channel === 'whatsapp') {
  $api_url = trim($S['whatsapp_api_url'] ?? '');
  $api_token = trim($S['whatsapp_api_token'] ?? '');
} else {
  $api_url = trim($S['sms_api_url'] ?? '');
  $api_token = trim($S['sms_api_token'] ?? '');
}

if ($api_url === '' || $api_token === '') { die('API settings missing in Admin > Settings'); }

$link = base_url('/public/bilty/view.php?token='.urlencode($B['share_token']));
$msg = "Bilty #".$B['bilty_number']."\nTransporter: ".$B['transporter_name']."\nVehicle: ".$B['vehicle_number']."\nAmount: ".$B['amount']."\nLink: ".$link;

$payload = ['message' => $msg];
if ($to !== '') $payload['to'] = $to;

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$api_token, 'Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
$resp = curl_exec($ch);
$err = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

header('Content-Type: text/plain; charset=utf-8');
if($err){ echo "Send failed: ".$err; } else { echo "Status: ".$code."\nResponse: ".$resp; }
