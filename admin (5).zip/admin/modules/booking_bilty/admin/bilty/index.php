<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager','staff']);
require __DIR__ . '/../../lib/db.php';

$q = trim($_GET['q'] ?? '');
$sql = "SELECT b.*, u.name as created_by_name
        FROM bilty b
        LEFT JOIN users u ON u.id=b.created_by";
$params = [];
if ($q !== '') {
  $sql .= " WHERE b.bilty_number LIKE ? OR b.transporter_name LIKE ? OR b.vehicle_number LIKE ? OR b.from_location LIKE ? OR b.to_location LIKE ?";
  $like = "%$q%";
  $params = [$like,$like,$like,$like,$like];
}
$sql .= " ORDER BY b.id DESC LIMIT 100";
$stmt = pdo()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
// Soft-include project header (Bootstrap, layout, session)
$__tplHeader = __DIR__ . '/../../templates/header.php';
if (is_file($__tplHeader)) { include $__tplHeader; } else {
    // Minimal standalone head if template missing
    ?><!doctype html><html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bilty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head><body class="bg-light"><div class="container py-4"><?php
}
?>
<div class="d-flex align-items-center mb-3">
  <h3 class="mb-0">Bilty Management</h3>
  <?php if(in_array(($_SESSION['user']['role'] ?? ''), ['admin'])): ?>
    <a class="btn btn-primary ms-auto" href="new.php">+ New Bilty</a>
  <?php endif; ?>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-auto">
    <input name="q" class="form-control" placeholder="Search..." value="<?= htmlspecialchars($q) ?>">
  </div>
  <div class="col-auto">
    <button class="btn btn-outline-secondary">Search</button>
    <a class="btn btn-outline-dark" href="index.php">Reset</a>
  </div>
</form>

<div class="card shadow-sm">
  <div class="table-responsive">
    <table class="table table-striped table-hover mb-0">
      <thead class="table-light">
        <tr>
          <th>ID</th>
          <th>Bilty #</th>
          <th>Transporter</th>
          <th>Vehicle</th>
          <th>Route</th>
          <th>Amount</th>
          <th>Created</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= htmlspecialchars($r['bilty_number']) ?></td>
          <td><?= htmlspecialchars($r['transporter_name']) ?></td>
          <td><?= htmlspecialchars($r['vehicle_number']) ?></td>
          <td><?= htmlspecialchars($r['from_location'].' → '.$r['to_location']) ?></td>
          <td><?= number_format((float)$r['amount'],2) ?></td>
          <td><?= htmlspecialchars($r['created_at']) ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-secondary" href="view.php?id=<?= (int)$r['id'] ?>">View</a>
            <?php if(in_array(($_SESSION['user']['role'] ?? ''), ['admin'])): ?>
              <a class="btn btn-sm btn-outline-primary" href="edit.php?id=<?= (int)$r['id'] ?>">Edit</a>
              <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= (int)$r['id'] ?>" onclick="return confirm('Delete this bilty?')">Delete</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($rows)): ?>
          <tr><td colspan="8" class="text-center text-muted">No records</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$__tplFooter = __DIR__ . '/../../templates/footer.php';
if (is_file($__tplFooter)) { include $__tplFooter; } else {
    ?></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body></html><?php
}
?>