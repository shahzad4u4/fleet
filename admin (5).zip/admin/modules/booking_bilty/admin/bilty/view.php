<?php
session_start();
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/auth.php';
require_role(['admin','manager','staff']);
require __DIR__ . '/../../lib/db.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = pdo()->prepare("SELECT b.*, u.name as created_by_name FROM bilty b LEFT JOIN users u ON u.id=b.created_by WHERE b.id=?");
$stmt->execute([$id]);
$B = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$B){ die('Not found'); }
?>
<?php
// Soft-include project header (Bootstrap, layout, session)
$__tplHeader = __DIR__ . '/../../templates/header.php';
if (is_file($__tplHeader)) { include $__tplHeader; } else {
    // Minimal standalone head if template missing
    ?><!doctype html><html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bilty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head><body class="bg-light"><div class="container py-4"><?php
}
?>
<div class="d-flex align-items-center mb-3">
  <h3 class="mb-0">Bilty #<?= htmlspecialchars($B['bilty_number']) ?></h3>
  <a class="btn btn-outline-secondary ms-auto" href="index.php">Back</a>
</div>

<div class="row g-3">
  <div class="col-md-8">
    <div class="card p-3 shadow-sm">
      <div class="row">
        <div class="col-md-6"><strong>Transporter:</strong> <?= htmlspecialchars($B['transporter_name']) ?></div>
        <div class="col-md-6"><strong>Vehicle:</strong> <?= htmlspecialchars($B['vehicle_number']) ?></div>
        <div class="col-md-6"><strong>From:</strong> <?= htmlspecialchars($B['from_location']) ?></div>
        <div class="col-md-6"><strong>To:</strong> <?= htmlspecialchars($B['to_location']) ?></div>
        <div class="col-md-6"><strong>Distance (KM):</strong> <?= htmlspecialchars($B['distance_km']) ?></div>
        <div class="col-md-6"><strong>Payment Mode:</strong> <?= htmlspecialchars($B['payment_mode']) ?></div>
        <div class="col-md-6"><strong>Amount:</strong> <?= number_format((float)$B['amount'],2) ?></div>
        <div class="col-md-6"><strong>Created:</strong> <?= htmlspecialchars($B['created_at']) ?></div>
      </div>
      <div class="mt-2"><strong>Goods/Remarks:</strong><br><?= nl2br(htmlspecialchars($B['goods_description'])) ?></div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card p-3 shadow-sm">
      <div class="fw-bold mb-2">Attachments</div>
      <?php if(!empty($B['bilty_file'])): ?>
        <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars('/'.trim($B['bilty_file'],'/')) ?>" target="_blank">View / Download</a>
      <?php else: ?>
        <div class="text-muted">No file</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$__tplFooter = __DIR__ . '/../../templates/footer.php';
if (is_file($__tplFooter)) { include $__tplFooter; } else {
    ?></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body></html><?php
}
?>