
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_no VARCHAR(30) UNIQUE,
  date DATE,
  consignor VARCHAR(150),
  c_address VARCHAR(255),
  c_phone VARCHAR(60),
  consignee VARCHAR(150),
  cs_address VARCHAR(255),
  cs_phone VARCHAR(60),
  goods VARCHAR(255),
  qty DECIMAL(12,2) DEFAULT 0,
  weight DECIMAL(12,2) DEFAULT 0,
  rate DECIMAL(12,2) DEFAULT 0,
  total DECIMAL(12,2) DEFAULT 0,
  vehicle INT,
  driver INT,
  payment_type ENUM('Cash','Credit') DEFAULT 'Cash',
  advance DECIMAL(12,2) DEFAULT 0,
  balance DECIMAL(12,2) DEFAULT 0,
  status ENUM('Pending','Dispatched','Delivered') DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample vehicles & drivers tables (if not exist) for dropdowns
CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate_no VARCHAR(50) UNIQUE
);

CREATE TABLE IF NOT EXISTS drivers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120)
);
