
<?php
include 'db.php';
$settings = ['company_name'=>'Company', 'address'=>'Address', 'phone'=>'', 'email'=>'', 'currency'=>'PKR', 'logo'=>null];
if ($res = $conn->query("SELECT * FROM settings LIMIT 1")) { if($res->num_rows>0){ $settings = $res->fetch_assoc(); } }

$id = intval($_GET['id'] ?? 0);
$sql = "SELECT bl.*, b.consignment_no, b.customer_name, b.customer_contact, b.from_location, b.to_location, b.booking_date, b.delivery_date,
        v.reg_no, d.name AS driver, d.phone AS driver_phone
        FROM bilty bl 
        JOIN bookings b ON bl.booking_id=b.id
        LEFT JOIN vehicles v ON b.vehicle_id=v.id
        LEFT JOIN drivers d ON b.driver_id=d.id
        WHERE bl.id=$id";
$bilty = $conn->query($sql)->fetch_assoc();
if(!$bilty) die("Bilty not found");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Bilty #<?php echo $bilty['id']; ?></title>
  <style>
    body{font-family:Arial;margin:20px;background:#f3f4f6}
    .sheet{max-width:900px;margin:auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px}
    .header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px dashed #d1d5db;padding-bottom:10px}
    .logo{width:64px;height:64px;border-radius:8px;background:#111827;display:inline-block}
    h2{margin:0}
    table{width:100%;border-collapse:collapse;margin-top:16px}
    th,td{border:1px solid #e5e7eb;padding:8px;text-align:left}
    th{background:#f9fafb}
    .right{text-align:right}
    .muted{color:#6b7280}
    .btn{margin-top:14px;padding:8px 12px;border:1px solid #111827;background:#111827;color:#fff;border-radius:8px;text-decoration:none}
    .twocol{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px}
    .title{font-weight:bold}
  </style>
</head>
<body>
  <div class="sheet" id="printable">
    <div class="header">
      <div>
        <h2><?php echo htmlspecialchars($settings['company_name'] ?? 'Company'); ?></h2>
        <div class="muted"><?php echo htmlspecialchars($settings['address'] ?? ''); ?></div>
        <div class="muted">Phone: <?php echo htmlspecialchars($settings['phone'] ?? ''); ?> | Email: <?php echo htmlspecialchars($settings['email'] ?? ''); ?></div>
      </div>
      <div>
        <?php if(!empty($settings['logo'])){ ?>
          <img class="logo" src="uploads/logo/<?php echo $settings['logo']; ?>">
        <?php } else { ?>
          <span class="logo"></span>
        <?php } ?>
      </div>
    </div>

    <table>
      <tr><th colspan="4">Bilty / LR</th></tr>
      <tr>
        <td><strong>Bilty No</strong> <?php echo htmlspecialchars($bilty['bilty_no']); ?></td>
        <td><strong>Consignment No</strong> <?php echo htmlspecialchars($bilty['consignment_no']); ?></td>
        <td><strong>Date</strong> <?php echo date('Y-m-d', strtotime($bilty['generated_at'])); ?></td>
        <td><strong>Booking Date</strong> <?php echo $bilty['booking_date']; ?></td>
      </tr>
      <tr>
        <td colspan="2"><strong>Vehicle</strong> <?php echo htmlspecialchars($bilty['reg_no']); ?></td>
        <td colspan="2"><strong>Driver</strong> <?php echo htmlspecialchars($bilty['driver']); ?> (<?php echo htmlspecialchars($bilty['driver_phone']); ?>)</td>
      </tr>
    </table>

    <div class="twocol">
      <div>
        <div class="title">Consignor (Sender)</div>
        <div><?php echo htmlspecialchars($bilty['consignor_name']); ?></div>
        <div class="muted"><?php echo htmlspecialchars($bilty['consignor_address']); ?></div>
        <div class="muted"><?php echo htmlspecialchars($bilty['consignor_contact']); ?></div>
      </div>
      <div>
        <div class="title">Consignee (Receiver)</div>
        <div><?php echo htmlspecialchars($bilty['consignee_name']); ?></div>
        <div class="muted"><?php echo htmlspecialchars($bilty['consignee_address']); ?></div>
        <div class="muted"><?php echo htmlspecialchars($bilty['consignee_contact']); ?></div>
      </div>
    </div>

    <table>
      <tr>
        <th>Item</th><th>Qty</th><th>Weight (kg)</th><th>Rate</th><th class="right">Freight</th>
      </tr>
      <tr>
        <td><?php echo htmlspecialchars($bilty['item_name']); ?></td>
        <td><?php echo (int)$bilty['goods_quantity']; ?></td>
        <td><?php echo number_format($bilty['goods_weight'],2); ?></td>
        <td><?php echo number_format($bilty['rate_per_unit'],2); ?></td>
        <td class="right"><?php echo number_format($bilty['freight_charges'],2); ?></td>
      </tr>
      <tr>
        <td colspan="4" class="right"><strong>Advance</strong></td>
        <td class="right"><?php echo number_format($bilty['advance_amount'],2); ?></td>
      </tr>
      <tr>
        <td colspan="4" class="right"><strong>Balance</strong></td>
        <td class="right"><?php echo number_format($bilty['balance_amount'],2); ?></td>
      </tr>
      <tr>
        <td colspan="5"><strong>Route:</strong> <?php echo htmlspecialchars($bilty['from_location']); ?> → <?php echo htmlspecialchars($bilty['to_location']); ?> &nbsp; | &nbsp; <strong>E-way Bill:</strong> <?php echo htmlspecialchars($bilty['eway_bill_no']); ?></td>
      </tr>
      <tr>
        <td colspan="5"><strong>Remarks:</strong> <?php echo nl2br(htmlspecialchars($bilty['remarks'])); ?></td>
      </tr>
    </table>

    <p class="muted">Signature (Consignor): _____________________ &nbsp;&nbsp; Signature (Driver): _____________________</p>
    <p class="muted">Delivery Date: <?php echo htmlspecialchars($bilty['delivery_date']); ?></p>
  </div>

  <div style="text-align:center">
    <button class="btn" onclick="window.print()">Print / Save as PDF</button>
  </div>
</body>
</html>
