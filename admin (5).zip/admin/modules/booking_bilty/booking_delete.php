
<?php
include "db.php";
$id = intval($_GET['id'] ?? 0);
if($id>0){
  $conn->query("DELETE FROM bookings WHERE id=$id");
}
header("Location: booking_list.php");
exit;
