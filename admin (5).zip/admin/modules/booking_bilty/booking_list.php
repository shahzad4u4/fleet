
<?php
$page_title = "Bookings List";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

$result = $conn->query("SELECT b.*, v.plate_no, d.name as driver_name 
                        FROM bookings b
                        LEFT JOIN vehicles v ON b.vehicle = v.id
                        LEFT JOIN drivers d ON b.driver = d.id
                        ORDER BY b.id DESC");
?>
<main class="p-6 md:ml-64">
  <div class="flex items-center justify-between mb-4">
    <h2 class="text-xl font-bold">All Bookings / Bilty</h2>
    <a href="booking_add.php" class="bg-green-600 text-white px-4 py-2 rounded">+ Add New</a>
  </div>

  <div class="bg-white border border-slate-200 rounded-2xl">
    <div class="overflow-x-auto">
      <table class="min-w-[980px] w-full text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th class="text-left px-3 py-2">#</th>
            <th class="text-left px-3 py-2">Booking No</th>
            <th class="text-left px-3 py-2">Date</th>
            <th class="text-left px-3 py-2">Consignor</th>
            <th class="text-left px-3 py-2">Consignee</th>
            <th class="text-left px-3 py-2">Goods</th>
            <th class="text-left px-3 py-2">Qty</th>
            <th class="text-left px-3 py-2">Vehicle</th>
            <th class="text-left px-3 py-2">Driver</th>
            <th class="text-left px-3 py-2">Total</th>
            <th class="text-left px-3 py-2">Advance</th>
            <th class="text-left px-3 py-2">Balance</th>
            <th class="text-left px-3 py-2">Status</th>
            <th class="text-left px-3 py-2">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = $result && $result->fetch_assoc()) { ?>
          <tr class="border-t">
            <td class="px-3 py-2"><?php echo $i++; ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['booking_no']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['date']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['consignor']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['consignee']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['goods']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['qty']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['plate_no']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['driver_name']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['total']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['advance']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['balance']); ?></td>
            <td class="px-3 py-2"><?php echo htmlspecialchars($row['status']); ?></td>
            <td class="px-3 py-2">
              <a href="booking_print.php?id=<?php echo $row['id']; ?>" class="px-2 py-1 border rounded hover:bg-slate-50">Print</a>
              <a href="booking_edit.php?id=<?php echo $row['id']; ?>" class="px-2 py-1 border rounded hover:bg-slate-50">Edit</a>
              <a href="booking_delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this booking?')" class="px-2 py-1 border rounded hover:bg-slate-50 text-red-600">Delete</a>
            </td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include "layout/footer.php"; ?>
