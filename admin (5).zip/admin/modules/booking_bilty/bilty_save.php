
<?php
include 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $bilty_no = $_POST['bilty_no'];
  if(!$bilty_no || trim($bilty_no)==''){
    $bilty_no = 'BL-' . date('ymd-His');
  }
  $stmt = $conn->prepare("INSERT INTO bilty (booking_id, bilty_no, consignor_name, consignor_address, consignor_contact, consignee_name, consignee_address, consignee_contact, item_name, goods_quantity, goods_weight, rate_per_unit, freight_charges, advance_amount, balance_amount, eway_bill_no, remarks) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->bind_param("issssssssidddddddss",
    $_POST['booking_id'],
    $bilty_no,
    $_POST['consignor_name'],
    $_POST['consignor_address'],
    $_POST['consignor_contact'],
    $_POST['consignee_name'],
    $_POST['consignee_address'],
    $_POST['consignee_contact'],
    $_POST['item_name'],
    $_POST['goods_quantity'],
    $_POST['goods_weight'],
    $_POST['rate_per_unit'],
    $_POST['freight_charges'],
    $_POST['advance_amount'],
    $_POST['balance_amount'],
    $_POST['eway_bill_no'],
    $_POST['remarks']
  );
  if($stmt->execute()){
    $id = $stmt->insert_id;
    header("Location: bilty_view.php?id=".$id);
  } else {
    echo "Error: ".$conn->error;
  }
}
