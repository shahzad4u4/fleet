
<?php include 'db.php'; $res = $conn->query("SELECT bl.*, b.consignment_no, b.customer_name, b.from_location, b.to_location FROM bilty bl JOIN bookings b ON bl.booking_id=b.id ORDER BY bl.id DESC"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Bilty List (PRO)</title>
  <style>
    body{font-family:Arial;margin:20px;background:#f6f8fb}
    .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{border:1px solid #e5e7eb;padding:8px;text-align:center}
    th{background:#111827;color:#fff}
    .btn{padding:6px 10px;border-radius:6px;border:1px solid #0ea5e9;background:#0ea5e9;color:#fff;text-decoration:none}
    .btn.green{background:#10b981;border-color:#10b981}
  </style>
</head>
<body>
  <div class="top">
    <h2>Bilty List (PRO)</h2>
    <a class="btn green" href="bilty_add.php">+ Generate Bilty</a>
  </div>
  <table>
    <tr>
      <th>ID</th><th>Bilty No.</th><th>Booking</th><th>Customer</th><th>Route</th><th>Qty</th><th>Weight</th><th>Freight</th><th>Advance</th><th>Balance</th><th>Actions</th>
    </tr>
    <?php while($r = $res->fetch_assoc()){ ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['bilty_no']); ?></td>
        <td>#<?php echo $r['booking_id']; ?> / <?php echo htmlspecialchars($r['consignment_no']); ?></td>
        <td><?php echo htmlspecialchars($r['customer_name']); ?></td>
        <td><?php echo htmlspecialchars($r['from_location'])." → ".htmlspecialchars($r['to_location']); ?></td>
        <td><?php echo $r['goods_quantity']; ?></td>
        <td><?php echo number_format($r['goods_weight'],2); ?> kg</td>
        <td><?php echo number_format($r['freight_charges'],2); ?></td>
        <td><?php echo number_format($r['advance_amount'],2); ?></td>
        <td><?php echo number_format($r['balance_amount'],2); ?></td>
        <td><a class="btn" href="bilty_view.php?id=<?php echo $r['id']; ?>" target="_blank">View / Print</a></td>
      </tr>
    <?php } ?>
  </table>
</body>
</html>
