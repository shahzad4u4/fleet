<?php
// public/bilty/view.php
require __DIR__ . '/../../lib/helpers.php';
require __DIR__ . '/../../lib/db.php';
$token = trim($_GET['token'] ?? '');
if ($token === '') { http_response_code(400); die('Missing token'); }

$stmt = pdo()->prepare("SELECT * FROM bilty WHERE share_token=?");
$stmt->execute([$token]);
$B = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$B){ http_response_code(404); die('Not found'); }

$S = function_exists('get_settings') ? (get_settings() ?? []) : [];
$logo = !empty($S['logo_path']) ? ('/'.trim($S['logo_path'],'/')) : '';
$letterhead = !empty($S['letterhead_path']) ? ('/'.trim($S['letterhead_path'],'/')) : '';
$pdf_link = base_url('/admin/bilty/pdf.php?id=' . (int)$B['id'] . '&lang=ur');
?><!doctype html><html lang="ur" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>بلٹی #<?= htmlspecialchars($B['bilty_number']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#f7f7f7}</style>
</head><body>
<div class="container py-4">
  <div class="card shadow-sm p-3">
    <div class="d-flex align-items-center mb-3">
      <?php if($logo): ?><img src="<?= $logo ?>" style="height:48px" class="me-2"><?php endif; ?>
      <div>
        <div class="fw-bold"><?= htmlspecialchars($S['company_name'] ?? 'Company') ?></div>
        <div class="text-muted small"><?= htmlspecialchars($S['invoice_footer'] ?? '') ?></div>
      </div>
      <a class="btn btn-success ms-auto" target="_blank" href="<?= $pdf_link ?>">Download PDF</a>
    </div>
    <h4 class="mb-3">بلٹی #: <?= htmlspecialchars($B['bilty_number']) ?></h4>
    <div class="row">
      <div class="col-md-6"><strong>ٹرانسپورٹر:</strong> <?= htmlspecialchars($B['transporter_name']) ?></div>
      <div class="col-md-6"><strong>گاڑی نمبر:</strong> <?= htmlspecialchars($B['vehicle_number']) ?></div>
      <div class="col-md-6"><strong>جہاں سے:</strong> <?= htmlspecialchars($B['from_location']) ?></div>
      <div class="col-md-6"><strong>جہاں تک:</strong> <?= htmlspecialchars($B['to_location']) ?></div>
      <div class="col-md-6"><strong>فاصلہ (کلومیٹر):</strong> <?= htmlspecialchars($B['distance_km']) ?></div>
      <div class="col-md-6"><strong>ادائیگی:</strong> <?= htmlspecialchars($B['payment_mode']) ?> / <?= number_format((float)$B['amount'],2) ?></div>
      <div class="col-12 mt-2"><strong>سامان / نوٹس:</strong><br><?= nl2br(htmlspecialchars($B['goods_description'])) ?></div>
      <?php if(!empty($B['bilty_file'])): ?>
        <div class="col-12 mt-3">
          <a class="btn btn-outline-primary" href="<?= '/'.trim($B['bilty_file'],'/') ?>" target="_blank">Attachment</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body></html>
