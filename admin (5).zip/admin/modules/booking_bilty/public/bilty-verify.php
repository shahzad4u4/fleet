<?php
// /public/bilty-verify.php
session_start();
require __DIR__ . '/../lib/helpers.php';

$bilty_no = trim($_GET['bilty_no'] ?? '');
$row = null;
if ($bilty_no !== '') {
  $stmt = pdo()->prepare("SELECT b.*, t.name AS transporter_name FROM bilty b
                          LEFT JOIN transporters t ON t.id=b.transporter_id
                          WHERE b.bilty_no=?");
  $stmt->execute([$bilty_no]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
include __DIR__ . '/../templates/header.php';
?>
<h3>بِلٹی ویریفکیشن</h3>
<form class="mb-3" method="get">
  <div class="input-group">
    <input class="form-control" name="bilty_no" value="<?= htmlspecialchars($bilty_no) ?>" placeholder="بِلٹی نمبر درج کریں">
    <button class="btn btn-primary">چیک کریں</button>
  </div>
</form>

<?php if($bilty_no !== ''): ?>
  <?php if($row): ?>
    <div class="alert alert-success">بِلٹی موجود ہے۔</div>
    <ul>
      <li><strong>تاریخ:</strong> <?= htmlspecialchars($row['issue_date']) ?></li>
      <li><strong>ٹرانسپورٹر:</strong> <?= htmlspecialchars($row['transporter_name'] ?? '-') ?></li>
      <li><strong>روٹ:</strong> <?= htmlspecialchars(($row['origin'] ?? '').' → '.($row['destination'] ?? '')) ?></li>
      <li><strong>کرایہ:</strong> <?= number_format((float)$row['freight_amount'],2) ?></li>
      <?php if($row['file_path']): ?>
        <li><a target="_blank" href="<?= base_url('/'.$row['file_path']) ?>">فائل دیکھیں/ڈاؤن لوڈ</a></li>
      <?php endif; ?>
    </ul>
  <?php else: ?>
    <div class="alert alert-danger">بِلٹی نمبر نہیں ملا۔</div>
  <?php endif; ?>
<?php endif; ?>
<?php include __DIR__ . '/../templates/footer.php'; ?>
