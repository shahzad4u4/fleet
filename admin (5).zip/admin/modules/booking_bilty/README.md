
# Booking / Bilty Module (Full)

## Includes
- `schema_bookings.sql` → `bookings` table + sample `vehicles`, `drivers` tables
- `db.php` → mysqli connection (edit credentials)
- `layout/` → Tailwind-based simple layout
- `booking_add.php` → Add Booking
- `booking_list.php` → List + actions
- `booking_edit.php` → Edit Booking
- `booking_delete.php` → Delete Booking
- `booking_print.php` → Print-friendly Bilty

## Setup
1) Import `schema_bookings.sql` into your database.
2) Update DB credentials inside `db.php`.
3) Open `booking_add.php` to create first booking, then use `booking_list.php`.

## Notes
- Auto booking no format: `BILTY-0001` (based on max ID).
- Replace simple SQL with prepared statements in production.
- Print page is A4 friendly and includes a print button.
