
-- PRO: Booking & Bilty schema (full fields)

CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consignment_no VARCHAR(50) UNIQUE,
    customer_name VARCHAR(120) NOT NULL,
    customer_contact VARCHAR(50),
    from_location VARCHAR(150) NOT NULL,
    to_location VARCHAR(150) NOT NULL,
    vehicle_id INT,
    driver_id INT,
    goods_description TEXT,
    booking_date DATE NOT NULL,
    delivery_date DATE,
    freight_charges DECIMAL(12,2) DEFAULT 0,
    advance_amount DECIMAL(12,2) DEFAULT 0,
    balance_amount DECIMAL(12,2) GENERATED ALWAYS AS (freight_charges - advance_amount) STORED,
    status ENUM('Pending','In-Transit','Delivered','Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bilty (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    bilty_no VARCHAR(50) UNIQUE,
    consignor_name VARCHAR(120) NOT NULL,
    consignor_address VARCHAR(200),
    consignor_contact VARCHAR(50),
    consignee_name VARCHAR(120) NOT NULL,
    consignee_address VARCHAR(200),
    consignee_contact VARCHAR(50),
    item_name VARCHAR(150),
    goods_quantity INT DEFAULT 0,
    goods_weight DECIMAL(12,2) DEFAULT 0,
    rate_per_unit DECIMAL(12,2) DEFAULT 0,
    freight_charges DECIMAL(12,2) DEFAULT 0,
    advance_amount DECIMAL(12,2) DEFAULT 0,
    balance_amount DECIMAL(12,2) DEFAULT 0,
    eway_bill_no VARCHAR(80),
    remarks TEXT,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);
