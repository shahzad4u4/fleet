
<?php
include 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  // Auto consignment if empty
  $cons_no = $_POST['consignment_no'];
  if(!$cons_no || trim($cons_no)==''){
    $cons_no = 'CNS-' . date('ymd-His');
  }
  $stmt = $conn->prepare("INSERT INTO bookings (consignment_no, customer_name, customer_contact, from_location, to_location, vehicle_id, driver_id, goods_description, booking_date, delivery_date, freight_charges, advance_amount, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'Pending')");
  $stmt->bind_param("sssssiisssdd",
    $cons_no,
    $_POST['customer_name'],
    $_POST['customer_contact'],
    $_POST['from_location'],
    $_POST['to_location'],
    $_POST['vehicle_id'],
    $_POST['driver_id'],
    $_POST['goods_description'],
    $_POST['booking_date'],
    $_POST['delivery_date'],
    $_POST['freight_charges'],
    $_POST['advance_amount']
  );
  if($stmt->execute()){
    header("Location: booking_list.php?ok=1");
  } else {
    echo "Error: ".$conn->error;
  }
}
