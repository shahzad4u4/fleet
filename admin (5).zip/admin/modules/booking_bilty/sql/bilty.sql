-- Bilty module table (drop/create safe)
CREATE TABLE IF NOT EXISTS bilty (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bilty_number VARCHAR(50) NOT NULL,
  transporter_name VARCHAR(100) NOT NULL,
  vehicle_number VARCHAR(50) NOT NULL,
  from_location VARCHAR(255) NOT NULL,
  to_location VARCHAR(255) NOT NULL,
  distance_km DECIMAL(10,2) NOT NULL,
  payment_mode ENUM('Cash','Cheque') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  goods_description TEXT NOT NULL,
  bilty_file VARCHAR(255) DEFAULT NULL,
  created_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
