-- fleet2 – Bilty Module Migration
USE fleet2;

CREATE TABLE IF NOT EXISTS bilty (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bilty_no       VARCHAR(40) NOT NULL UNIQUE,
  booking_id     INT NULL,
  transporter_id INT NULL,
  issue_date     DATE NOT NULL,
  origin         VARCHAR(150) NOT NULL,
  destination    VARCHAR(150) NOT NULL,
  weight_kg      DECIMAL(10,2) NULL,
  quantity       INT NULL,
  freight_amount DECIMAL(12,2) NULL,
  remarks        VARCHAR(255) NULL,
  file_path      VARCHAR(255) NULL,         -- PDF/JPG/PNG
  created_by     INT NULL,
  created_at     TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  FOREIGN KEY (transporter_id) REFERENCES transporters(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX (bilty_no),
  INDEX (issue_date),
  INDEX (transporter_id),
  INDEX (booking_id)
);
