
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Generate Bilty (PRO)</title>
  <style>
    body{font-family:Arial;margin:20px;background:#f6f8fb}
    .card{max-width:1000px;margin:auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    label{display:block;margin-top:8px;font-weight:bold}
    input,select,textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .actions{margin-top:14px}
    .btn{padding:10px 14px;border-radius:8px;border:1px solid #10b981;background:#10b981;color:#fff;cursor:pointer}
    .btn.gray{background:#6b7280;border-color:#6b7280}
    .muted{color:#6b7280;font-size:12px}
  </style>
  <script>
    function calcBiltyBalance(){
      var f = parseFloat(document.querySelector('[name=freight_charges]').value||0);
      var a = parseFloat(document.querySelector('[name=advance_amount]').value||0);
      var b = (f - a).toFixed(2);
      document.querySelector('[name=balance_amount]').value = b;
    }
  </script>
</head>
<body>
<div class="card">
  <h2>Generate Bilty (PRO)</h2>
  <form method="post" action="bilty_save.php">
    <div class="row">
      <div>
        <label>Booking</label>
        <select name="booking_id" required>
          <?php
            $bk = $conn->query("SELECT id, consignment_no, customer_name, from_location, to_location FROM bookings ORDER BY id DESC");
            while($b = $bk->fetch_assoc()){ 
              $label = "#{$b['id']} / {$b['consignment_no']} - {$b['customer_name']} ({$b['from_location']} → {$b['to_location']})";
              echo "<option value='{$b['id']}'>".$label."</option>"; 
            }
          ?>
        </select>
      </div>
      <div>
        <label>Bilty No.</label>
        <input type="text" name="bilty_no" placeholder="Auto/Manual">
      </div>
      <div>
        <label>Consignor Name</label>
        <input type="text" name="consignor_name" required>
      </div>
      <div>
        <label>Consignor Address</label>
        <input type="text" name="consignor_address">
      </div>
      <div>
        <label>Consignor Contact</label>
        <input type="text" name="consignor_contact">
      </div>
      <div>
        <label>Consignee Name</label>
        <input type="text" name="consignee_name" required>
      </div>
      <div>
        <label>Consignee Address</label>
        <input type="text" name="consignee_address">
      </div>
      <div>
        <label>Consignee Contact</label>
        <input type="text" name="consignee_contact">
      </div>
      <div>
        <label>Item Name</label>
        <input type="text" name="item_name">
      </div>
      <div>
        <label>Quantity</label>
        <input type="number" name="goods_quantity" value="0">
      </div>
      <div>
        <label>Weight (kg)</label>
        <input type="number" step="0.01" name="goods_weight" value="0">
      </div>
      <div>
        <label>Rate per Unit</label>
        <input type="number" step="0.01" name="rate_per_unit" value="0">
      </div>
      <div>
        <label>Freight Charges</label>
        <input type="number" step="0.01" name="freight_charges" value="0" oninput="calcBiltyBalance()">
      </div>
      <div>
        <label>Advance Payment</label>
        <input type="number" step="0.01" name="advance_amount" value="0" oninput="calcBiltyBalance()">
      </div>
      <div>
        <label>Balance</label>
        <input type="number" step="0.01" name="balance_amount" value="0" readonly>
        <div class="muted">Auto Calculate</div>
      </div>
      <div>
        <label>E-way Bill No. (optional)</label>
        <input type="text" name="eway_bill_no">
      </div>
    </div>
    <label>Remarks</label>
    <textarea name="remarks" rows="3"></textarea>
    <div class="actions">
      <button class="btn" type="submit">Generate</button>
      <a class="btn gray" href="bilty_list.php" style="text-decoration:none;color:#fff">Back to List</a>
    </div>
  </form>
</div>
<script>calcBiltyBalance();</script>
</body>
</html>
