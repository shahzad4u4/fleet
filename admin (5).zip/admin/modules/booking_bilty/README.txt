Bilty Module (Ready-to-Use)
===========================

Folders/Files:
- admin/bilty/index.php   (list/search + role check)
- admin/bilty/new.php     (create + file upload + validation)
- admin/bilty/edit.php    (edit)
- admin/bilty/view.php    (view details)
- admin/bilty/delete.php  (delete)
- admin/bilty/_form.php   (shared form)
- sql/bilty.sql           (table schema)

Requirements in your project root (already present in fleet2):
- lib/helpers.php  -> must provide pdo(), base_url(), handle_upload(field, 'uploads/bilty')
- lib/auth.php     -> must provide require_role([...]) and $_SESSION['user'] with 'role' and 'id'
- lib/db.php       -> creates $pdo or pdo() connection

Install:
1) Copy `admin/bilty` folder to your project: D:\xampp\htdocs\fleet2\admin\bilty\
2) Run `sql/bilty.sql` in MySQL on database `fleet2`.
3) Make sure `uploads/bilty/` is writable.
4) Add menu link to `/admin/bilty/index.php` in your dashboard.

Notes:
- If your templates are at templates/header.php and templates/footer.php, they will be used automatically.
- Otherwise these pages include Bootstrap CDN and render standalone.
- Only Admin can Create/Edit/Delete. Staff/Manager can view and list.
