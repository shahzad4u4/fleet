
<?php
$page_title = "Edit Booking";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

$id = intval($_GET['id'] ?? 0);
$bk = $conn->query("SELECT * FROM bookings WHERE id=$id")->fetch_assoc();
if(!$bk){ echo "<main class='p-6 md:ml-64'>Not found.</main>"; include "layout/footer.php"; exit; }

if(isset($_POST['update'])){
  $date       = $_POST['date'];
  $consignor  = $conn->real_escape_string($_POST['consignor']);
  $c_address  = $conn->real_escape_string($_POST['c_address']);
  $c_phone    = $conn->real_escape_string($_POST['c_phone']);
  $consignee  = $conn->real_escape_string($_POST['consignee']);
  $cs_address = $conn->real_escape_string($_POST['cs_address']);
  $cs_phone   = $conn->real_escape_string($_POST['cs_phone']);
  $goods      = $conn->real_escape_string($_POST['goods']);
  $qty        = floatval($_POST['qty']);
  $weight     = floatval($_POST['weight']);
  $rate       = floatval($_POST['rate']);
  $total      = $qty * $rate;
  $vehicle    = intval($_POST['vehicle']);
  $driver     = intval($_POST['driver']);
  $payment_type = $_POST['payment_type'];
  $advance      = floatval($_POST['advance']);
  $balance      = $total - $advance;
  $status       = $_POST['status'];

  $sql = "UPDATE bookings SET date='$date', consignor='$consignor', c_address='$c_address', c_phone='$c_phone',
          consignee='$consignee', cs_address='$cs_address', cs_phone='$cs_phone', goods='$goods', qty=$qty, weight=$weight,
          rate=$rate, total=$total, vehicle=$vehicle, driver=$driver, payment_type='$payment_type', advance=$advance, balance=$balance, status='$status'
          WHERE id=$id";
  if($conn->query($sql)){
    echo "<script>alert('Updated'); location.href='booking_list.php';</script>";
    exit;
  } else {
    echo "<div class='p-4 text-red-600'>Error: ".$conn->error."</div>";
  }
}
?>
<main class="p-6 md:ml-64">
  <form method="post" class="bg-white border border-slate-200 rounded-2xl p-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-semibold">Booking No</label>
        <input type="text" value="<?=htmlspecialchars($bk['booking_no'])?>" readonly class="w-full border p-2 rounded">
      </div>
      <div>
        <label class="block text-sm font-semibold">Date</label>
        <input type="date" name="date" value="<?=htmlspecialchars($bk['date'])?>" class="w-full border p-2 rounded">
      </div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Consignor</div>
      <div><input name="consignor" value="<?=htmlspecialchars($bk['consignor'])?>" class="w-full border p-2 rounded"></div>
      <div><input name="c_address" value="<?=htmlspecialchars($bk['c_address'])?>" class="w-full border p-2 rounded"></div>
      <div><input name="c_phone" value="<?=htmlspecialchars($bk['c_phone'])?>" class="w-full border p-2 rounded"></div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Consignee</div>
      <div><input name="consignee" value="<?=htmlspecialchars($bk['consignee'])?>" class="w-full border p-2 rounded"></div>
      <div><input name="cs_address" value="<?=htmlspecialchars($bk['cs_address'])?>" class="w-full border p-2 rounded"></div>
      <div><input name="cs_phone" value="<?=htmlspecialchars($bk['cs_phone'])?>" class="w-full border p-2 rounded"></div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Goods</div>
      <div><input name="goods" value="<?=htmlspecialchars($bk['goods'])?>" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="qty" value="<?=htmlspecialchars($bk['qty'])?>" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="weight" value="<?=htmlspecialchars($bk['weight'])?>" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="rate" value="<?=htmlspecialchars($bk['rate'])?>" class="w-full border p-2 rounded"></div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Trip Assignment</div>
      <div>
        <select name="vehicle" class="w-full border p-2 rounded">
          <option value="">Select Vehicle</option>
          <?php $v = $conn->query("SELECT id, plate_no FROM vehicles"); if($v){ while($r = $v->fetch_assoc()){ $sel = ($bk['vehicle']==$r['id'])?'selected':''; echo "<option value='{$r['id']}' $sel>".htmlspecialchars($r['plate_no'])."</option>"; } } ?>
        </select>
      </div>
      <div>
        <select name="driver" class="w-full border p-2 rounded">
          <option value="">Select Driver</option>
          <?php $d = $conn->query("SELECT id, name FROM drivers"); if($d){ while($r = $d->fetch_assoc()){ $sel = ($bk['driver']==$r['id'])?'selected':''; echo "<option value='{$r['id']}' $sel>".htmlspecialchars($r['name'])."</option>"; } } ?>
        </select>
      </div>
      <div class="md:col-span-2 text-slate-600 font-semibold">Payment</div>
      <div>
        <select name="payment_type" class="w-full border p-2 rounded">
          <option value="Cash" <?=($bk['payment_type']=='Cash'?'selected':'')?>>Cash</option>
          <option value="Credit" <?=($bk['payment_type']=='Credit'?'selected':'')?>>Credit</option>
        </select>
      </div>
      <div><input type="number" step="0.01" name="advance" value="<?=htmlspecialchars($bk['advance'])?>" class="w-full border p-2 rounded"></div>
      <div class="md:col-span-2">
        <label class="block text-sm font-semibold">Status</label>
        <select name="status" class="w-full border p-2 rounded">
          <?php foreach(['Pending','Dispatched','Delivered'] as $st){ $sel = ($bk['status']==$st)?'selected':''; echo "<option $sel>$st</option>"; } ?>
        </select>
      </div>
    </div>
    <div class="mt-4">
      <button name="update" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
      <a href="booking_list.php" class="ml-2 px-4 py-2 border rounded">Back</a>
    </div>
  </form>
</main>
<?php include "layout/footer.php"; ?>
