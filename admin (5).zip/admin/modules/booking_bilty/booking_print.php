
<?php
include "db.php";
$id = intval($_GET['id'] ?? 0);
$bk = $conn->query("SELECT b.*, v.plate_no, d.name as driver_name FROM bookings b
  LEFT JOIN vehicles v ON b.vehicle=v.id
  LEFT JOIN drivers d ON b.driver=d.id
  WHERE b.id=$id")->fetch_assoc();
if(!$bk){ die("Not found"); }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Bilty Print - <?=$bk['booking_no']?></title>
  <style>
    body{font-family:Arial; margin:20px;}
    .head{display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #222; padding-bottom:8px; margin-bottom:10px}
    .title{font-size:20px; font-weight:bold}
    table{width:100%; border-collapse:collapse}
    td,th{padding:6px; border:1px solid #ddd; font-size:13px}
    .no-border td,.no-border th{border:none}
    .muted{color:#666}
    .right{text-align:right}
    .center{text-align:center}
    .badge{display:inline-block; padding:2px 8px; border:1px solid #999; border-radius:12px; font-size:12px}
    @media print{ .noprint{display:none} }
  </style>
</head>
<body>
  <div class="noprint" style="text-align:right;margin-bottom:10px">
    <button onclick="window.print()">Print</button>
  </div>

  <div class="head">
    <div>
      <div class="title">Bilty / Consignment Note</div>
      <div class="muted">Fleet System</div>
    </div>
    <div class="right">
      <div><strong>No:</strong> <?=$bk['booking_no']?></div>
      <div><strong>Date:</strong> <?=$bk['date']?></div>
      <div><span class="badge"><?=$bk['status']?></span></div>
    </div>
  </div>

  <table class="no-border">
    <tr>
      <td style="width:50%">
        <strong>Consignor (Sender)</strong><br>
        <?=htmlspecialchars($bk['consignor'])?><br>
        <?=htmlspecialchars($bk['c_address'])?><br>
        <?=htmlspecialchars($bk['c_phone'])?>
      </td>
      <td style="width:50%">
        <strong>Consignee (Receiver)</strong><br>
        <?=htmlspecialchars($bk['consignee'])?><br>
        <?=htmlspecialchars($bk['cs_address'])?><br>
        <?=htmlspecialchars($bk['cs_phone'])?>
      </td>
    </tr>
  </table>

  <h4>Goods</h4>
  <table>
    <thead>
      <tr><th>Description</th><th class="right">Qty</th><th class="right">Weight(kg)</th><th class="right">Rate</th><th class="right">Total</th></tr>
    </thead>
    <tbody>
      <tr>
        <td><?=htmlspecialchars($bk['goods'])?></td>
        <td class="right"><?=number_format($bk['qty'],2)?></td>
        <td class="right"><?=number_format($bk['weight'],2)?></td>
        <td class="right"><?=number_format($bk['rate'],2)?></td>
        <td class="right"><?=number_format($bk['total'],2)?></td>
      </tr>
    </tbody>
  </table>

  <table class="no-border" style="margin-top:10px">
    <tr>
      <td>
        <strong>Vehicle:</strong> <?=htmlspecialchars($bk['plate_no'])?> &nbsp; 
        <strong>Driver:</strong> <?=htmlspecialchars($bk['driver_name'])?>
      </td>
      <td class="right" style="width:40%">
        <div><strong>Advance:</strong> <?=number_format($bk['advance'],2)?></div>
        <div><strong>Balance:</strong> <?=number_format($bk['balance'],2)?></div>
      </td>
    </tr>
  </table>

  <p class="muted" style="margin-top:20px">Note: This is a system generated bilty.</p>
</body>
</html>
