
<?php
$page_title = "Add Booking / Bilty";
include "layout/header.php";
include "layout/sidebar.php";
include "layout/topnav.php";
include "db.php";

// Auto Generate Booking No
$result = $conn->query("SELECT MAX(id) as max_id FROM bookings");
$row = $result ? $result->fetch_assoc() : ['max_id'=>0];
$nextId = intval($row['max_id']) + 1;
$bookingNo = "BILTY-" . str_pad($nextId, 4, "0", STR_PAD_LEFT);

// Save Form
if (isset($_POST['save'])) {
    $date       = $_POST['date'];
    $consignor  = $conn->real_escape_string($_POST['consignor']);
    $c_address  = $conn->real_escape_string($_POST['c_address']);
    $c_phone    = $conn->real_escape_string($_POST['c_phone']);
    $consignee  = $conn->real_escape_string($_POST['consignee']);
    $cs_address = $conn->real_escape_string($_POST['cs_address']);
    $cs_phone   = $conn->real_escape_string($_POST['cs_phone']);
    $goods      = $conn->real_escape_string($_POST['goods']);
    $qty        = floatval($_POST['qty']);
    $weight     = floatval($_POST['weight']);
    $rate       = floatval($_POST['rate']);
    $total      = $qty * $rate;
    $vehicle    = intval($_POST['vehicle']);
    $driver     = intval($_POST['driver']);
    $payment_type = $_POST['payment_type'];
    $advance      = floatval($_POST['advance']);
    $balance      = $total - $advance;
    $status = "Pending";

    $stmt = $conn->prepare("INSERT INTO bookings (booking_no, date, consignor, c_address, c_phone, consignee, cs_address, cs_phone, goods, qty, weight, rate, total, vehicle, driver, payment_type, advance, balance, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssssddddii sdd s", $bookingNo,$date,$consignor,$c_address,$c_phone,$consignee,$cs_address,$cs_phone,$goods,$qty,$weight,$rate,$total,$vehicle,$driver,$payment_type,$advance,$balance,$status);
    // Workaround: mysqli bind types — use string and numeric separately

    // Simpler insert to avoid bind complexity in starter
    $sql = "INSERT INTO bookings (booking_no, date, consignor, c_address, c_phone, consignee, cs_address, cs_phone, goods, qty, weight, rate, total, vehicle, driver, payment_type, advance, balance, status)
            VALUES ('$bookingNo','$date','$consignor','$c_address','$c_phone','$consignee','$cs_address','$cs_phone','$goods',$qty,$weight,$rate,$total,$vehicle,$driver,'$payment_type',$advance,$balance,'$status')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Booking Saved Successfully!'); window.location='booking_list.php';</script>";
        exit;
    } else {
        echo "<div class='p-4 text-red-600'>Error: ".$conn->error."</div>";
    }
}
?>

<main class="p-6 md:ml-64">
  <form method="post" class="bg-white border border-slate-200 rounded-2xl p-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-semibold">Booking No</label>
        <input type="text" name="booking_no" value="<?php echo $bookingNo; ?>" readonly class="w-full border p-2 rounded">
      </div>

      <div>
        <label class="block text-sm font-semibold">Date</label>
        <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" class="w-full border p-2 rounded" required>
      </div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Consignor (Sender)</div>
      <div><input type="text" name="consignor" placeholder="Name" class="w-full border p-2 rounded" required></div>
      <div><input type="text" name="c_address" placeholder="Address" class="w-full border p-2 rounded"></div>
      <div><input type="text" name="c_phone" placeholder="Phone" class="w-full border p-2 rounded"></div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Consignee (Receiver)</div>
      <div><input type="text" name="consignee" placeholder="Name" class="w-full border p-2 rounded" required></div>
      <div><input type="text" name="cs_address" placeholder="Address" class="w-full border p-2 rounded"></div>
      <div><input type="text" name="cs_phone" placeholder="Phone" class="w-full border p-2 rounded"></div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Goods Details</div>
      <div><input type="text" name="goods" placeholder="Goods Description" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="qty" placeholder="Quantity" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="weight" placeholder="Weight (kg)" class="w-full border p-2 rounded"></div>
      <div><input type="number" step="0.01" name="rate" placeholder="Rate per unit" class="w-full border p-2 rounded"></div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Trip Assignment</div>
      <div>
        <select name="vehicle" class="w-full border p-2 rounded">
          <option value="">Select Vehicle</option>
          <?php
            $v = $conn->query("SELECT id, plate_no FROM vehicles");
            if($v){ while($r = $v->fetch_assoc()) { echo "<option value='".$r['id']."'>".htmlspecialchars($r['plate_no'])."</option>"; } }
          ?>
        </select>
      </div>
      <div>
        <select name="driver" class="w-full border p-2 rounded">
          <option value="">Select Driver</option>
          <?php
            $d = $conn->query("SELECT id, name FROM drivers");
            if($d){ while($r = $d->fetch_assoc()) { echo "<option value='".$r['id']."'>".htmlspecialchars($r['name'])."</option>"; } }
          ?>
        </select>
      </div>

      <div class="md:col-span-2 text-slate-600 font-semibold">Payment</div>
      <div>
        <select name="payment_type" class="w-full border p-2 rounded">
          <option value="Cash">Cash</option>
          <option value="Credit">Credit</option>
        </select>
      </div>
      <div><input type="number" step="0.01" name="advance" placeholder="Advance Paid" class="w-full border p-2 rounded" value="0"></div>
    </div>

    <div class="mt-4">
      <button type="submit" name="save" class="bg-blue-600 text-white px-4 py-2 rounded">Save Booking</button>
      <a href="booking_list.php" class="ml-2 px-4 py-2 border rounded">Cancel</a>
    </div>
  </form>
</main>
<?php include "layout/footer.php"; ?>
