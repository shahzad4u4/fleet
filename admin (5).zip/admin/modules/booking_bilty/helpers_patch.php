<?php
// Add into lib/helpers.php if missing

if (!function_exists('uploads_path')) {
    function uploads_path($sub='') {
        $base = __DIR__ . '/../uploads';
        if (!is_dir($base)) { @mkdir($base, 0777, true); }
        if ($sub) {
            $dir = $base . '/' . trim($sub, '/');
            if (!is_dir($dir)) { @mkdir($dir, 0777, true); }
            return $dir;
        }
        return $base;
    }
}

if (!function_exists('handle_upload')) {
    /** generic secure upload */
    function handle_upload($field, $subdir, $allowed=['pdf','jpg','jpeg','png']) {
        if (empty($_FILES[$field]['name'])) return null;
        if (!is_array($_FILES[$field]['name'])) {
            $name = $_FILES[$field]['name'];
            $tmp  = $_FILES[$field]['tmp_name'];
            $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) return null;
            $safe = time().'_'.preg_replace('/[^a-zA-Z0-9_.-]/','_', $name);
            $dir  = uploads_path($subdir);
            $dest = $dir . '/' . $safe;
            if (move_uploaded_file($tmp, $dest)) {
                // return relative path for public URL
                return 'uploads/' . trim($subdir,'/') . '/' . $safe;
            }
        }
        return null;
    }
}
