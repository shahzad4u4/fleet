<?php
require_once __DIR__ . '/_bootstrap.php';

$id = $_GET['id'] ?? 0;
if (!$id) {
    header("Location: index.php?msg=Invalid+invoice+ID");
    exit;
}

// Fetch existing record
$stmt = $conn->prepare("SELECT * FROM invoices WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$invoice = $result->fetch_assoc();

if (!$invoice) {
    header("Location: index.php?msg=Invoice+not+found");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $invoice_no = $_POST['invoice_no'] ?? '';
    $customer   = $_POST['customer_name'] ?? '';
    $amount     = $_POST['amount'] ?? 0;
    $date       = $_POST['invoice_date'] ?? '';
    $status     = $_POST['status'] ?? '';

    if ($invoice_no && $customer && $date) {
        $stmt = $conn->prepare("UPDATE invoices SET invoice_no=?, customer_name=?, amount=?, invoice_date=?, status=? WHERE id=?");
        $stmt->bind_param("ssdssi", $invoice_no, $customer, $amount, $date, $status, $id);
        $stmt->execute();

        header("Location: index.php?msg=Invoice+updated+successfully");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Invoice</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-3xl mx-auto p-6">
    <div class="flex items-center justify-between mb-4">
      <h1 class="text-2xl font-semibold">Edit Invoice</h1>
      <a href="index.php" class="px-4 py-2 bg-gray-600 text-white rounded">Back</a>
    </div>

    <form method="post" class="bg-white shadow rounded-xl p-6 space-y-4">
      <div>
        <label class="block mb-1 font-medium">Invoice No</label>
        <input type="text" name="invoice_no" value="<?php echo htmlspecialchars($invoice['invoice_no']); ?>" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Customer Name</label>
        <input type="text" name="customer_name" value="<?php echo htmlspecialchars($invoice['customer_name']); ?>" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Amount</label>
        <input type="number" step="0.01" name="amount" value="<?php echo htmlspecialchars($invoice['amount']); ?>" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Invoice Date</label>
        <input type="date" name="invoice_date" value="<?php echo htmlspecialchars($invoice['invoice_date']); ?>" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1 font-medium">Status</label>
        <select name="status" class="w-full border px-3 py-2 rounded">
          <option value="Pending" <?php if($invoice['status']=='Pending') echo 'selected'; ?>>Pending</option>
          <option value="Paid" <?php if($invoice['status']=='Paid') echo 'selected'; ?>>Paid</option>
          <option value="Cancelled" <?php if($invoice['status']=='Cancelled') echo 'selected'; ?>>Cancelled</option>
        </select>
      </div>

      <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Update Invoice</button>
    </form>
  </div>
</body>
</html>
