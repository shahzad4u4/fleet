<?php
require_once __DIR__ . '/_bootstrap.php';
$id = $_GET['id'] ?? 0;
$conn->query("DELETE FROM invoices WHERE id=$id");
header("Location: index.php?msg=Invoice+deleted");
exit;
