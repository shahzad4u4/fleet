<?php
require_once __DIR__ . '/_bootstrap.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Sab bookings load karo
$bookings = [];
$res = $conn->query("SELECT id, customer_name FROM bookings ORDER BY id DESC");
while ($r = $res->fetch_assoc()) {
    $bookings[] = $r;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $invoice_no = $_POST['invoice_no'] ?? '';
    $booking_id = $_POST['booking_id'] ?? '';
    $amount     = $_POST['amount'] ?? 0;
    $status     = $_POST['status'] ?? 'Pending';

    if ($invoice_no && $booking_id && $amount) {
        $stmt = $conn->prepare("INSERT INTO invoices (invoice_no, booking_id, amount, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sids", $invoice_no, $booking_id, $amount, $status);
        $stmt->execute();
        header("Location: index.php?msg=Invoice+Added");
        exit;
    } else {
        echo "Missing required fields!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Invoice</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function updateCustomer() {
        let select = document.getElementById('booking_id');
        let customer = select.options[select.selectedIndex].dataset.customer;
        document.getElementById('customer_name').value = customer;
    }
  </script>
</head>
<body class="bg-gray-50">
  <div class="max-w-3xl mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Add Invoice</h1>

    <form method="post" class="bg-white shadow rounded-xl p-6 space-y-4">
      <div>
        <label class="block mb-1">Invoice No</label>
        <input type="text" name="invoice_no" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1">Booking</label>
        <select name="booking_id" id="booking_id" onchange="updateCustomer()" class="w-full border px-3 py-2 rounded" required>
          <option value="">-- Select Booking --</option>
          <?php foreach ($bookings as $b): ?>
            <option value="<?= $b['id'] ?>" data-customer="<?= htmlspecialchars($b['customer_name']) ?>">
              <?= "Booking #".$b['id']." - ".htmlspecialchars($b['customer_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label class="block mb-1">Customer Name</label>
        <input type="text" id="customer_name" class="w-full border px-3 py-2 rounded bg-gray-100" readonly>
      </div>

      <div>
        <label class="block mb-1">Amount</label>
        <input type="number" name="amount" step="0.01" class="w-full border px-3 py-2 rounded" required>
      </div>

      <div>
        <label class="block mb-1">Status</label>
        <select name="status" class="w-full border px-3 py-2 rounded">
          <option value="Pending">Pending</option>
          <option value="Paid">Paid</option>
        </select>
      </div>

      <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
    </form>
  </div>
</body>
</html>
