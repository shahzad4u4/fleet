<?php error_reporting(E_ALL); ini_set('display_errors', 1); ?>
<?php
if (file_exists(__DIR__.'/../../includes/auth.php')) { require __DIR__.'/../../includes/auth.php'; }
require __DIR__ . '/../../config/db.php';
$page_title = ucfirst('invoices') . ' - List';
<?php 
$__h1=__DIR__.'/../../partials/header.php';
$__h2=__DIR__.'/../../includes/header.php';
$__h3=__DIR__.'/../../header.php';
if(file_exists($__h1)) include $__h1; elseif(file_exists($__h2)) include $__h2; elseif(file_exists($__h3)) include $__h3; ?>
try { $result = $conn->query("SELECT * FROM invoices ORDER BY id DESC"); } catch (Throwable $e) { $result = false; echo "<div style='color:red'>DB Error: ".$e->getMessage()."</div>"; }
?>
<div class="flex justify-between items-center mb-4">
  <h2 class="text-xl font-semibold">Invoices List</h2>
  <a href="add.php" class="px-4 py-2 bg-blue-600 text-white rounded">Add New</a>
</div>
<div class="bg-white rounded-xl border shadow overflow-auto">
<table class="min-w-full text-sm">
  <thead class="bg-gray-50">
    <tr>
      <th class="px-3 py-2 text-left">ID</th>
      <th class="px-3 py-2 text-left">Booking_Id</th>
      <th class="px-3 py-2 text-left">Invoice_No</th>
      <th class="px-3 py-2 text-left">Amount</th>
      <th class="px-3 py-2 text-left">Status</th>
      <th class="px-3 py-2">Actions</th>
    </tr>
  </thead>
  <tbody>
<?php while($row = $result->fetch_assoc()): ?>
    <tr class="border-t">
      <td class="px-3 py-2"><?php echo $row['id']; ?></td>
      <td class="px-3 py-2"><?php echo htmlspecialchars($row['booking_id'] ?? ''); ?></td>
      <td class="px-3 py-2"><?php echo htmlspecialchars($row['invoice_no'] ?? ''); ?></td>
      <td class="px-3 py-2"><?php echo htmlspecialchars($row['amount'] ?? ''); ?></td>
      <td class="px-3 py-2"><?php echo htmlspecialchars($row['status'] ?? ''); ?></td>

      <td class="px-3 py-2 text-center">
        <a class="text-blue-600" href="edit.php?id=<?php echo $row['id'];?>">Edit</a> |
        <a class="text-red-600" onclick="return confirm('Delete?');" href="delete.php?id=<?php echo $row['id'];?>">Delete</a>
      </td>
    </tr>
<?php endwhile; ?>
  </tbody>
</table>
</div>
<?php <?php 
$__f1=__DIR__.'/../../partials/footer.php';
$__f2=__DIR__.'/../../includes/footer.php';
$__f3=__DIR__.'/../../footer.php';
if(file_exists($__f1)) include $__f1; elseif(file_exists($__f2)) include $__f2; elseif(file_exists($__f3)) include $__f3; ?> ?>