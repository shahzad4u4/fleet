<?php error_reporting(E_ALL); ini_set('display_errors', 1); ?>
<?php
if (file_exists(__DIR__.'/../../includes/auth.php')) { require __DIR__.'/../../includes/auth.php'; }
require __DIR__ . '/../../config/db.php';
$id = intval($_GET['id'] ?? 0);
$conn->query("DELETE FROM invoices WHERE id={$id}");
header('Location: index.php');