<?php error_reporting(E_ALL); ini_set('display_errors', 1); ?>
<?php
if (file_exists(__DIR__.'/../../includes/auth.php')) { require __DIR__.'/../../includes/auth.php'; }
require __DIR__ . '/../../config/db.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM invoices WHERE id={$id}");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) { die('Record not found'); }
$page_title = 'Edit Invoices';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $booking_id = $_POST['booking_id'] ?? $record['booking_id'];
    $invoice_no = $_POST['invoice_no'] ?? $record['invoice_no'];
    $amount = $_POST['amount'] ?? $record['amount'];
    $status = $_POST['status'] ?? $record['status'];

    $stmt = $conn->prepare("UPDATE invoices SET booking_id = ?, invoice_no = ?, amount = ?, status = ? WHERE id=?");
    $stmt->bind_param('ssssi', $booking_id, $invoice_no, $amount, $status, $id);
    $stmt->execute();
    header('Location: index.php'); exit;
}
<?php 
$__h1=__DIR__.'/../../partials/header.php';
$__h2=__DIR__.'/../../includes/header.php';
$__h3=__DIR__.'/../../header.php';
if(file_exists($__h1)) include $__h1; elseif(file_exists($__h2)) include $__h2; elseif(file_exists($__h3)) include $__h3; ?>
?>
<h2 class="text-xl font-semibold mb-4">Edit Invoices</h2>
<form method="post" class="bg-white p-4 rounded-xl border shadow max-w-2xl grid gap-3">
  <label class="block">
    <span class="text-sm">Booking_Id</span>
    <input name="booking_id" value="<?php echo htmlspecialchars($record['booking_id'] ?? ''); ?>" class="mt-1 w-full border rounded px-3 py-2">
  </label>
  <label class="block">
    <span class="text-sm">Invoice_No</span>
    <input name="invoice_no" value="<?php echo htmlspecialchars($record['invoice_no'] ?? ''); ?>" class="mt-1 w-full border rounded px-3 py-2">
  </label>
  <label class="block">
    <span class="text-sm">Amount</span>
    <input name="amount" value="<?php echo htmlspecialchars($record['amount'] ?? ''); ?>" class="mt-1 w-full border rounded px-3 py-2">
  </label>
  <label class="block">
    <span class="text-sm">Status</span>
    <input name="status" value="<?php echo htmlspecialchars($record['status'] ?? ''); ?>" class="mt-1 w-full border rounded px-3 py-2">
  </label>

  <button class="bg-blue-600 text-white px-4 py-2 rounded w-max">Update</button>
</form>
<?php <?php 
$__f1=__DIR__.'/../../partials/footer.php';
$__f2=__DIR__.'/../../includes/footer.php';
$__f3=__DIR__.'/../../footer.php';
if(file_exists($__f1)) include $__f1; elseif(file_exists($__f2)) include $__f2; elseif(file_exists($__f3)) include $__f3; ?> ?>