<?php
// modules/bookings/_bootstrap.php
// Safely include your existing DB connection.
// Priority: project-root/config/db.php -> project-root/includes/db.php -> local fallback.
$__root = realpath(__DIR__ . '/../../');

if (file_exists($__root . '/config/db.php')) {
    require_once $__root . '/config/db.php'; // expected to define $conn (mysqli)
} elseif (file_exists($__root . '/includes/db.php')) {
    require_once $__root . '/includes/db.php';
} else {
    // Fallback (update if needed)
    $conn = @mysqli_connect('localhost','root','','hslogistics_fleet');
    if(!$conn){
        die('DB connection failed. Please set config/db.php or includes/db.php');
    }
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Simple auth check (adjust role logic as per your system)
if (!isset($_SESSION['user_id'])) {
    // If you use admin/login.php in your project:
    header('Location: /admin/login.php');
    exit;
}
?>
