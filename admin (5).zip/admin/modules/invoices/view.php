<?php
require_once __DIR__ . '/_bootstrap.php';
$id = $_GET['id'] ?? 0;
$res = $conn->query("SELECT * FROM invoices WHERE id=$id");
$invoice = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>View Invoice</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-3xl mx-auto p-6 bg-white rounded-xl shadow">
    <h1 class="text-2xl font-semibold mb-4">Invoice #<?php echo $invoice['invoice_no']; ?></h1>
    <p><strong>Customer:</strong> <?php echo htmlspecialchars($invoice['customer_name']); ?></p>
    <p><strong>Amount:</strong> <?php echo number_format($invoice['amount'],2); ?></p>
    <p><strong>Date:</strong> <?php echo $invoice['invoice_date']; ?></p>
    <p><strong>Status:</strong> <?php echo htmlspecialchars($invoice['status']); ?></p>

    <div class="mt-4 flex gap-2">
      <a href="index.php" class="px-4 py-2 bg-gray-600 text-white rounded">Back</a>
      <button onclick="window.print()" class="px-4 py-2 bg-green-600 text-white rounded">Print</button>
    </div>
  </div>
</body>
</html>
