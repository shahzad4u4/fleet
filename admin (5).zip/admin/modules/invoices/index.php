<?php
require_once __DIR__ . '/_bootstrap.php';

// Error show karne ke liye (sirf test ke liye, baad me hata dena)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$msg = $_GET['msg'] ?? '';
$rows = [];

// Query invoices + bookings join
$sql = "
    SELECT i.id, i.invoice_no, i.amount, i.status, i.booking_id, b.customer_name
    FROM invoices i
    LEFT JOIN bookings b ON i.booking_id = b.id
    ORDER BY i.id DESC
";

$res = $conn->query($sql);
while ($r = $res->fetch_assoc()) {
    $rows[] = $r;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Invoices</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="max-w-6xl mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Invoices</h1>

    <?php if ($msg): ?>
      <div class="mb-4 p-3 bg-green-100 text-green-800 rounded"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <a href="add.php" class="mb-4 inline-block px-4 py-2 bg-blue-600 text-white rounded">+ New Invoice</a>

    <table class="w-full border-collapse border">
      <thead class="bg-gray-200">
        <tr>
          <th class="border px-3 py-2 text-left">#</th>
          <th class="border px-3 py-2 text-left">Invoice No</th>
          <th class="border px-3 py-2 text-left">Customer</th>
          <th class="border px-3 py-2 text-left">Amount</th>
          <th class="border px-3 py-2 text-left">Status</th>
          <th class="border px-3 py-2 text-left">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($rows): ?>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="border px-3 py-2"><?= htmlspecialchars($r['id']) ?></td>
              <td class="border px-3 py-2"><?= htmlspecialchars($r['invoice_no']) ?></td>
              <td class="border px-3 py-2"><?= htmlspecialchars($r['customer_name'] ?? '-') ?></td>
              <td class="border px-3 py-2"><?= htmlspecialchars($r['amount']) ?></td>
              <td class="border px-3 py-2"><?= htmlspecialchars($r['status']) ?></td>
              <td class="border px-3 py-2">
                <a href="view.php?id=<?= $r['id'] ?>" class="text-blue-600">View</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" class="text-center py-4">No invoices found</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
