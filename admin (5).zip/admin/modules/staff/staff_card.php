<?php
require('fpdf/fpdf.php');
include 'db_connection.php';
require 'phpqrcode/qrlib.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM staff WHERE id=$id");
$row = mysqli_fetch_assoc($result);

$pdf = new FPDF('P','mm',array(85,54));
$pdf->AddPage();
$pdf->SetFillColor(230,230,250);
$pdf->Rect(0,0,85,54,'F');

$logo_path = "uploads/logo.png";
if(file_exists($logo_path)){
    $pdf->Image($logo_path,5,5,25);
}

$pdf->SetFont('Arial','B',12);
$pdf->SetTextColor(0,0,80);
$pdf->Cell(0,10,'STAFF CARD',0,1,'C');

$pdf->Image('uploads/staff/'.$row['photo'],5,20,25,25);

$pdf->SetXY(35,20);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,5,'Staff ID: '.$row['staff_id'],0,1);
$pdf->Cell(0,5,'Name: '.$row['name'],0,1);
$pdf->Cell(0,5,'Role: '.$row['role'],0,1);
$pdf->Cell(0,5,'Dept: '.$row['department'],0,1);
$pdf->Cell(0,5,'Joining: '.$row['joining_date'],0,1);

$qr_temp = 'uploads/temp_qr.png';
QRcode::png($row['staff_id'], $qr_temp, 'L', 2, 2);
$pdf->Image($qr_temp,60,30,20,20);
unlink($qr_temp);

$pdf->Output();
?>
