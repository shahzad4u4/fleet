<?php
include 'db_connection.php';
include 'functions.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM staff WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $department = $_POST['department'];
    $joining_date = $_POST['joining_date'];
    $salary = $_POST['salary'];

    if($_FILES['photo']['name'] != '') {
        $photo = $_FILES['photo']['name'];
        $tmp_name = $_FILES['photo']['tmp_name'];
        $ext = pathinfo($photo, PATHINFO_EXTENSION);
        $photo_name = $row['staff_id'] . '.' . $ext;
        move_uploaded_file($tmp_name, "uploads/staff/".$photo_name);
    } else {
        $photo_name = $row['photo'];
    }

    $query = "UPDATE staff SET 
        name='$name',
        email='$email',
        phone='$phone',
        role='$role',
        department='$department',
        joining_date='$joining_date',
        salary='$salary',
        photo='$photo_name'
        WHERE id=$id";

    if(mysqli_query($conn, $query)) {
        header("Location: list_staff.php");
        exit;
    } else {
        echo "Error: ".mysqli_error($conn);
    }
}
?>

<form method="POST" action="" enctype="multipart/form-data">
    Name: <input type="text" name="name" value="<?php echo $row['name']; ?>" required><br>
    Email: <input type="email" name="email" value="<?php echo $row['email']; ?>" required><br>
    Phone: <input type="text" name="phone" value="<?php echo $row['phone']; ?>"><br>
    Role: <input type="text" name="role" value="<?php echo $row['role']; ?>"><br>
    Department: <input type="text" name="department" value="<?php echo $row['department']; ?>"><br>
    Joining Date: <input type="date" name="joining_date" value="<?php echo $row['joining_date']; ?>"><br>
    Salary: <input type="number" step="0.01" name="salary" value="<?php echo $row['salary']; ?>"><br>
    Photo: <input type="file" name="photo" accept="image/*"><br>
    <img src="uploads/staff/<?php echo $row['photo']; ?>" width="80"><br>
    <button type="submit" name="update">Update Staff</button>
</form>
