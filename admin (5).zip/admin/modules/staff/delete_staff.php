<?php
include 'db_connection.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT photo FROM staff WHERE id=$id");
$row = mysqli_fetch_assoc($result);
if($row['photo'] != '' && file_exists("uploads/staff/".$row['photo'])) {
    unlink("uploads/staff/".$row['photo']);
}

mysqli_query($conn, "DELETE FROM staff WHERE id=$id");
header("Location: list_staff.php");
exit;
?>
