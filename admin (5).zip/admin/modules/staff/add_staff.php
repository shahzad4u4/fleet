<?php
//require_once __DIR__ . '/_bootstrap.php';

include 'admin/includes/db.ph';
include 'functions.php';


if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $department = $_POST['department'];
    $joining_date = $_POST['joining_date'];
    $salary = $_POST['salary'];

    $staff_id = generateStaffID($conn);

    $photo = $_FILES['photo']['name'];
    $tmp_name = $_FILES['photo']['tmp_name'];
    $ext = pathinfo($photo, PATHINFO_EXTENSION);
    $photo_name = $staff_id . '.' . $ext;
    move_uploaded_file($tmp_name, "uploads/staff/".$photo_name);

    $query = "INSERT INTO staff (staff_id, name, email, phone, role, department, joining_date, salary, photo) 
              VALUES ('$staff_id','$name','$email','$phone','$role','$department','$joining_date','$salary','$photo_name')";
    if(mysqli_query($conn, $query)) {
        header("Location: list_staff.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<form method="POST" action="" enctype="multipart/form-data">
Name: <input type="text" name="name" required><br>
Email: <input type="email" name="email" required><br>
Phone: <input type="text" name="phone"><br>
Role: <input type="text" name="role"><br>
Department: <input type="text" name="department"><br>
Joining Date: <input type="date" name="joining_date"><br>
Salary: <input type="number" step="0.01" name="salary"><br>
Photo: <input type="file" name="photo" accept="image/*" required><br>
<button type="submit" name="submit">Add Staff</button>
</form>
