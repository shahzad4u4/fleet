<?php
function generateStaffID($conn) {
    $query = "SELECT staff_id FROM staff ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if($row) {
        $lastID = $row['staff_id'];
        $num = (int)substr($lastID, 3);
        $num++;
        return 'STF' . str_pad($num, 3, '0', STR_PAD_LEFT);
    } else {
        return 'STF001';
    }
}
?>
