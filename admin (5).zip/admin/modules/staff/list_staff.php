<?php
include 'db_connection.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$filter_department = isset($_GET['department']) ? $_GET['department'] : '';
$filter_role = isset($_GET['role']) ? $_GET['role'] : '';

$query = "SELECT * FROM staff WHERE 1";
if($search != '') $query .= " AND (name LIKE '%$search%' OR staff_id LIKE '%$search%')";
if($filter_department != '') $query .= " AND department='$filter_department'";
if($filter_role != '') $query .= " AND role='$filter_role'";
$query .= " ORDER BY id DESC";

$result = mysqli_query($conn, $query);
?>

<form method="GET" action="">
    Search: <input type="text" name="search" value="<?php echo $search; ?>">
    Department: <input type="text" name="department" value="<?php echo $filter_department; ?>">
    Role: <input type="text" name="role" value="<?php echo $filter_role; ?>">
    <button type="submit">Filter</button>
    <a href="list_staff.php">Reset</a>
</form>

<table border="1">
<tr>
<th>ID</th>
<th>Staff ID</th>
<th>Name</th>
<th>Photo</th>
<th>Role</th>
<th>Department</th>
<th>Actions</th>
</tr>
<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['staff_id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><img src="uploads/staff/<?php echo $row['photo']; ?>" width="50"></td>
    <td><?php echo $row['role']; ?></td>
    <td><?php echo $row['department']; ?></td>
    <td>
        <a href="edit_staff.php?id=<?php echo $row['id']; ?>">Edit</a> | 
        <a href="delete_staff.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete?')">Delete</a> | 
        <a href="staff_card.php?id=<?php echo $row['id']; ?>" target="_blank">Card</a>
    </td>
</tr>
<?php } ?>
</table>
