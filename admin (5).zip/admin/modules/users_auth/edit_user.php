<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM users WHERE id=$id");
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $email, $role, $id);
    if ($stmt->execute()) {
        echo "User updated! <a href='user_list.php'>Back</a>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit User</title></head>
<body>
<h2>Edit User</h2>
<form method="post">
    <label>Name:</label><input type="text" name="name" value="<?php echo $user['name']; ?>" required><br>
    <label>Email:</label><input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>
    <label>Role:</label>
    <select name="role">
        <option value="admin" <?php if($user['role']=='admin') echo 'selected'; ?>>Admin</option>
        <option value="staff" <?php if($user['role']=='staff') echo 'selected'; ?>>Staff</option>
        <option value="driver" <?php if($user['role']=='driver') echo 'selected'; ?>>Driver</option>
        <option value="accountant" <?php if($user['role']=='accountant') echo 'selected'; ?>>Accountant</option>
    </select><br>
    <button type="submit">Update</button>
</form>
</body>
</html>
