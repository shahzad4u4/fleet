
<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<?php $err = $_GET['err'] ?? ''; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <style>
    body{font-family:Arial;background:#f6f8fb;margin:0;display:flex;align-items:center;justify-content:center;height:100vh}
    .card{width:360px;background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:20px;box-shadow:0 10px 30px rgba(0,0,0,.05)}
    h2{margin:0 0 12px 0}
    label{display:block;font-weight:bold;margin-top:10px}
    input{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .btn{margin-top:12px;width:100%;padding:10px;border-radius:8px;border:1px solid #111827;background:#111827;color:#fff;cursor:pointer}
    .err{color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:8px;margin-top:8px}
    .muted{font-size:12px;color:#6b7280;text-align:center;margin-top:8px}
  </style>
</head>
<body>
  <div class="card">
    <h2>Sign in</h2>
    <?php if($err){ echo "<div class='err'>".htmlspecialchars($err)."</div>"; } ?>
    <form method="post" action="login_check.php">
      <label>Email</label>
      <input type="email" name="email" required>
      <label>Password</label>
      <input type="password" name="password" required>
      <button class="btn" type="submit">Login</button>
    </form>
    <div class="muted">Default admin: admin@example.com / Admin@123 (change after login)</div>
  </div>
</body>
</html>
