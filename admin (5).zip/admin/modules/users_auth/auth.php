
<?php
// Session + helpers for auth/roles
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function is_logged_in() {
  return isset($_SESSION['user']);
}

function current_user() {
  return $_SESSION['user'] ?? null;
}

function require_login() {
  if (!is_logged_in()) {
    header("Location: login.php?next=" . urlencode($_SERVER['REQUEST_URI'] ?? ''));
    exit;
  }
}

function require_role($roles = []) {
  require_login();
  $user = current_user();
  if (!in_array($user['role'], (array)$roles)) {
    http_response_code(403);
    echo "<h2 style='font-family:Arial'>Access Denied</h2><p>You do not have permission to view this page.</p>";
    exit;
  }
}
