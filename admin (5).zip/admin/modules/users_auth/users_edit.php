<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include __DIR__ . '/../../app/auth_guard.php';
if (($_SESSION['user']['role'] ?? '') !== 'admin') { echo "<div style='padding:16px;color:#b91c1c;'>Access denied (admin only).</div>"; exit; }
$layoutBase = __DIR__ . '/../../app/layout';
include $layoutBase . '/header.php';
include $layoutBase . '/sidebar.php';
include $layoutBase . '/topnav.php';
require_once __DIR__ . '/../../config/db.php';
?>
<main class="p-6 md:ml-64">
<h1 class="text-xl font-bold mb-4">Edit User</h1>
<?php
$id = intval($_GET['id'] ?? 0);
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST'){
  $username = trim($_POST['username'] ?? '');
  $role = $_POST['role'] ?? 'staff';
  $password = $_POST['password'] ?? '';
  if ($username===''){
    $msg = "<div class='mb-3 text-red-600'>Username required.</div>";
  } else {
    if ($password !== ''){
      $hash = password_hash($password, PASSWORD_BCRYPT);
      $stmt = $conn->prepare("UPDATE users SET username=?, role=?, password=? WHERE id=?");
      $stmt->bind_param("sssi", $username, $role, $hash, $id);
    } else {
      $stmt = $conn->prepare("UPDATE users SET username=?, role=? WHERE id=?");
      $stmt->bind_param("ssi", $username, $role, $id);
    }
    if ($stmt->execute()){
      $msg = "<div class='mb-3 text-green-700'>User updated.</div>";
      echo "<script>setTimeout(()=>location.href='users_list.php',700);</script>";
    } else {
      $msg = "<div class='mb-3 text-red-600'>Update failed.</div>";
    }
  }
}
$res = $conn->query("SELECT * FROM users WHERE id=$id");
$r = $res ? $res->fetch_assoc() : null;
echo $msg;
?>
<?php if($r): ?>
<form method="post" class="bg-white rounded-xl border shadow-sm p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
  <label class="text-sm">Username<input name="username" value="<?= htmlspecialchars($r['username']) ?>" class="mt-1 w-full border rounded px-3 py-2" required></label>
  <label class="text-sm">Role
    <select name="role" class="mt-1 w-full border rounded px-3 py-2">
      <option value="staff" <?= $r['role']=='staff'?'selected':''; ?>>Staff</option>
      <option value="driver" <?= $r['role']=='driver'?'selected':''; ?>>Driver</option>
      <option value="admin" <?= $r['role']=='admin'?'selected':''; ?>>Admin</option>
    </select>
  </label>
  <label class="text-sm md:col-span-2">New Password (optional)
    <input name="password" type="password" class="mt-1 w-full border rounded px-3 py-2" placeholder="Leave blank to keep same">
  </label>
  <div class="md:col-span-2 flex gap-2 pt-2">
    <button class="px-4 py-2 border rounded-lg">Update</button>
    <a href="users_list.php" class="px-4 py-2 border rounded-lg">Back</a>
  </div>
</form>
<?php else: ?>
<div class="text-red-600">User not found.</div>
<?php endif; ?>

</main>
<?php include $layoutBase . '/footer.php'; ?>
