
<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require 'db.php';

$email = trim($_POST['email'] ?? '');
$pass  = $_POST['password'] ?? '';

$stmt = $conn->prepare("SELECT id, name, email, role, status, password_hash FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();

if(!$user || $user['status']!=='active' || !password_verify($pass, $user['password_hash'])){
  header("Location: login.php?err=" . urlencode("Invalid credentials or account disabled"));
  exit;
}

$_SESSION['user'] = [
  'id' => $user['id'],
  'name' => $user['name'],
  'email' => $user['email'],
  'role' => $user['role']
];

$next = $_GET['next'] ?? $_POST['next'] ?? 'dashboard.php';
header("Location: " . $next);
exit;
