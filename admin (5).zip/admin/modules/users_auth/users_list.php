
<?php
require_once 'auth.php';
require_role(['admin']);
require 'db.php';
$users = $conn->query("SELECT id, name, email, role, status, created_at FROM users ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Users</title>
  <style>
    body{font-family:Arial;background:#f6f8fb;margin:20px}
    table{width:100%;border-collapse:collapse;background:#fff}
    th,td{border:1px solid #e5e7eb;padding:8px;text-align:left}
    th{background:#111827;color:#fff}
    .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
    .btn{padding:8px 12px;border-radius:8px;border:1px solid #0ea5e9;background:#0ea5e9;color:#fff;text-decoration:none}
    .btn.red{background:#ef4444;border-color:#ef4444}
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="top">
  <h2>User Management</h2>
  <a class="btn" href="user_add.php">+ Add User</a>
</div>
<table>
  <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Created</th><th>Actions</th></tr>
  <?php while($u = $users->fetch_assoc()){ ?>
    <tr>
      <td><?php echo $u['id']; ?></td>
      <td><?php echo htmlspecialchars($u['name']); ?></td>
      <td><?php echo htmlspecialchars($u['email']); ?></td>
      <td><?php echo htmlspecialchars($u['role']); ?></td>
      <td><?php echo htmlspecialchars($u['status']); ?></td>
      <td><?php echo $u['created_at']; ?></td>
      <td>
        <a class="btn" href="user_edit.php?id=<?php echo $u['id']; ?>">Edit</a>
        <a class="btn red" href="user_delete.php?id=<?php echo $u['id']; ?>" onclick="return confirm('Delete this user?')">Delete</a>
      </td>
    </tr>
  <?php } ?>
</table>
</body>
</html>
