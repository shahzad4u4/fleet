<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include __DIR__ . '/../../app/auth_guard.php';
if (($_SESSION['user']['role'] ?? '') !== 'admin') { die('Access denied'); }
require_once __DIR__ . '/../../config/db.php';
$id = intval($_GET['id'] ?? 0);
if ($id > 0){
  // prevent deleting yourself for safety
  if (($_SESSION['user']['id'] ?? 0) == $id){
    header("Location: users_list.php");
    exit;
  }
  $conn->query("DELETE FROM users WHERE id=$id");
}
header("Location: users_list.php");
exit;
