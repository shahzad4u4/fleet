
<?php
require_once 'auth.php';
require_role(['admin']);
require 'db.php';

$id = intval($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$role = $_POST['role'] ?? 'staff';
$status = $_POST['status'] ?? 'active';
$pass = $_POST['password'] ?? '';

if(!$id || !$name || !$email){
  die("Missing fields");
}

if($pass){
  $hash = password_hash($pass, PASSWORD_BCRYPT);
  $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=?, status=?, password_hash=? WHERE id=?");
  $stmt->bind_param("sssssi", $name, $email, $role, $status, $hash, $id);
} else {
  $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=?, status=? WHERE id=?");
  $stmt->bind_param("ssssi", $name, $email, $role, $status, $id);
}

if($stmt->execute()){
  header("Location: users_list.php?ok=1");
} else {
  echo "Error: " . $conn->error;
}
