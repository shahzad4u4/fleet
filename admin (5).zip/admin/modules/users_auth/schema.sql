
-- Users + Roles schema

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  role ENUM('admin','staff','customer') NOT NULL DEFAULT 'staff',
  password_hash VARCHAR(255) NOT NULL,
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed an initial admin (change the email/password after import)
INSERT INTO users (name, email, role, password_hash) VALUES
('Super Admin', 'admin@example.com', 'admin', '$2y$10$W2j1k3uTz3bq3ZkKeC0Bpe1v8g6i7XK8u8e8OaU9vA9JvCq2rS9My'); 
-- password is: Admin@123  (please change)
