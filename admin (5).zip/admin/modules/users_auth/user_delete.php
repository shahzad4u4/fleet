
<?php
require_once 'auth.php';
require_role(['admin']);
require 'db.php';
$id = intval($_GET['id'] ?? 0);
if($id){
  $conn->query("DELETE FROM users WHERE id=$id");
}
header("Location: users_list.php");
exit;
