
<?php
require_once 'auth.php';
require_login();
$user = current_user();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <style>
    body{font-family:Arial;background:#f6f8fb;margin:20px}
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:14px}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px}
    .muted{color:#6b7280}
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<h2>Welcome, <?php echo htmlspecialchars($user['name']); ?> 👋</h2>
<p class="muted">Role-based quick links appear below.</p>
<div class="grid">
  <div class="card">
    <h3>Bookings</h3>
    <p>Create & manage bookings</p>
    <a href="booking_list.php">Open</a>
  </div>
  <div class="card">
    <h3>Bilty</h3>
    <p>Generate & print LR</p>
    <a href="bilty_list.php">Open</a>
  </div>
  <div class="card">
    <h3>Reports</h3>
    <p>Graphs & exports</p>
    <a href="reports_dashboard.php">Open</a>
  </div>
</div>

<?php if($user['role']==='admin'){ ?>
  <div class="card" style="margin-top:14px">
    <h3>Admin Tools</h3>
    <ul>
      <li><a href="users_list.php">User Management</a></li>
      <li><a href="settings.php">System Settings</a></li>
    </ul>
  </div>
<?php } ?>
</body>
</html>
