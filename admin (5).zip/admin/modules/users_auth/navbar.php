
<?php
require_once 'auth.php';
$user = current_user();
?>
<div style="background:#111827;color:#fff;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;border-radius:10px">
  <div>
    <strong>Fleet System</strong>
    <?php if($user){ echo " — <span style='opacity:.8'>".htmlspecialchars($user['role'])."</span>"; } ?>
  </div>
  <div>
    <?php if($user){ ?>
      <span style="margin-right:10px"><?php echo htmlspecialchars($user['name']); ?></span>
      <a href="dashboard.php" style="color:#93c5fd;margin-right:10px">Dashboard</a>
      <?php if(in_array($user['role'], ['admin'])){ ?>
        <a href="users_list.php" style="color:#93c5fd;margin-right:10px">Users</a>
      <?php } ?>
      <a href="logout.php" style="color:#fca5a5">Logout</a>
    <?php } else { ?>
      <a href="login.php" style="color:#93c5fd">Login</a>
    <?php } ?>
  </div>
</div>
