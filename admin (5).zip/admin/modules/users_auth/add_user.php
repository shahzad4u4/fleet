<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $role);
    if ($stmt->execute()) {
        echo "User added successfully! <a href='user_list.php'>View Users</a>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Add User</title></head>
<body>
<h2>Add User</h2>
<form method="post">
    <label>Name:</label><input type="text" name="name" required><br>
    <label>Email:</label><input type="email" name="email" required><br>
    <label>Password:</label><input type="password" name="password" required><br>
    <label>Role:</label>
    <select name="role">
        <option value="admin">Admin</option>
        <option value="staff">Staff</option>
        <option value="driver">Driver</option>
        <option value="accountant">Accountant</option>
    </select><br>
    <button type="submit">Add User</button>
</form>
</body>
</html>
