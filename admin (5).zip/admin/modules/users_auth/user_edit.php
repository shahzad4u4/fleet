
<?php
require_once 'auth.php';
require_role(['admin']);
require 'db.php';
$id = intval($_GET['id'] ?? 0);
$u = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();
if(!$u){ die("User not found"); }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit User</title>
  <style>
    body{font-family:Arial;background:#f6f8fb;margin:20px}
    .card{max-width:700px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px}
    label{display:block;margin-top:8px;font-weight:bold}
    input,select{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .btn{margin-top:12px;padding:10px 14px;border-radius:8px;border:1px solid #0ea5e9;background:#0ea5e9;color:#fff;cursor:pointer}
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<h2>Edit User</h2>
<div class="card">
  <form method="post" action="user_update.php">
    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($u['name']); ?>" required>
    <label>Email</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($u['email']); ?>" required>
    <label>Role</label>
    <select name="role" required>
      <option value="admin" <?php if($u['role']=='admin') echo 'selected'; ?>>Admin</option>
      <option value="staff" <?php if($u['role']=='staff') echo 'selected'; ?>>Staff</option>
      <option value="customer" <?php if($u['role']=='customer') echo 'selected'; ?>>Customer</option>
    </select>
    <label>Status</label>
    <select name="status">
      <option value="active" <?php if($u['status']=='active') echo 'selected'; ?>>Active</option>
      <option value="disabled" <?php if($u['status']=='disabled') echo 'selected'; ?>>Disabled</option>
    </select>
    <label>New Password (optional)</label>
    <input type="password" name="password">
    <button class="btn" type="submit">Update</button>
  </form>
</div>
</body>
</html>
