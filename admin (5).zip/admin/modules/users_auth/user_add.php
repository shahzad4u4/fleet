
<?php
require_once 'auth.php';
require_role(['admin']);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add User</title>
  <style>
    body{font-family:Arial;background:#f6f8fb;margin:20px}
    .card{max-width:700px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px}
    label{display:block;margin-top:8px;font-weight:bold}
    input,select{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin-top:6px}
    .btn{margin-top:12px;padding:10px 14px;border-radius:8px;border:1px solid #10b981;background:#10b981;color:#fff;cursor:pointer}
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<h2>Add User</h2>
<div class="card">
  <form method="post" action="user_save.php">
    <label>Name</label>
    <input type="text" name="name" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Role</label>
    <select name="role" required>
      <option value="admin">Admin</option>
      <option value="staff" selected>Staff</option>
      <option value="customer">Customer</option>
    </select>
    <label>Password</label>
    <input type="password" name="password" required>
    <label>Status</label>
    <select name="status">
      <option value="active" selected>Active</option>
      <option value="disabled">Disabled</option>
    </select>
    <button class="btn" type="submit">Save</button>
  </form>
</div>
</body>
</html>
