
<?php
require_once 'auth.php';
require_role(['admin']);
require 'db.php';

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$role = $_POST['role'] ?? 'staff';
$status = $_POST['status'] ?? 'active';
$pass = $_POST['password'] ?? '';

if(!$name || !$email || !$pass){
  die("Missing fields");
}

$hash = password_hash($pass, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (name,email,role,password_hash,status) VALUES (?,?,?,?,?)");
$stmt->bind_param("sssss", $name, $email, $role, $hash, $status);
if($stmt->execute()){
  header("Location: users_list.php?ok=1");
} else {
  echo "Error: " . $conn->error;
}
