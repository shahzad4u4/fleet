
# Auth + Roles Module

## Tables
- `users` (name, email, role, password_hash, status)

## Files
- `login.php`, `login_check.php`, `logout.php`
- `auth.php` (session + helpers), `navbar.php`
- `dashboard.php` (role-based UI)
- `users_list.php`, `user_add.php`, `user_save.php`, `user_edit.php`, `user_update.php`, `user_delete.php`

## Setup
1) Import `schema.sql` (will create `users` + seed admin).
2) Copy files to your project root (where `db.php` exists).
3) Open `login.php` → sign in with `admin@example.com / Admin@123` → **immediately change password**.
4) Use `User Management` to add Staff/Customer users.

## Usage
- Guard any page with:
  ```php
  require_once 'auth.php';
  require_login(); // or require_role(['admin','staff'])
  ```
