<?php
require_once __DIR__ . "/db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$vehicleRes = $conn->query("SELECT * FROM vehicles WHERE id=$id");
if (!$vehicleRes || !$vehicleRes->num_rows) { die("Vehicle not found."); }
$vehicle = $vehicleRes->fetch_assoc();
$uploadDir = __DIR__ . "/uploads/"; $uploadUrlBase = "uploads/"; if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }
if (isset($_POST['update'])) {
    $reg_no=$conn->real_escape_string($_POST['reg_no']); $make=$conn->real_escape_string($_POST['make']); $model=$conn->real_escape_string($_POST['model']);
    $year=(int)$_POST['year']; $color=$conn->real_escape_string($_POST['color']??""); $engine_no=$conn->real_escape_string($_POST['engine_no']??"");
    $chassis_no=$conn->real_escape_string($_POST['chassis_no']??""); $insurance_date=$conn->real_escape_string($_POST['insurance_date']??null);
    $permit_date=$conn->real_escape_string($_POST['permit_date']??null);
    function saveUpload($field,$prefix,$uploadDir,$uploadUrlBase){
        if(!empty($_FILES[$field]['name'])){ $safe=preg_replace('/[^A-Za-z0-9\.\-_]/','_',basename($_FILES[$field]['name']));
            $fs=$uploadDir.time().'_'+$prefix.'_'.$safe; if(move_uploaded_file($_FILES[$field]['tmp_name'],$fs)){ return "uploads/".basename($fs);}}
        return null;
    }
    if($url=saveUpload('insurance_file','insurance',$uploadDir,$uploadUrlBase)){ if(!empty($vehicle['insurance_file'])){ $old=__DIR__.'/'.$vehicle['insurance_file']; if(file_exists($old)) @unlink($old);} $vehicle['insurance_file']=$url; }
    if($url=saveUpload('permit_file','permit',$uploadDir,$uploadUrlBase)){ if(!empty($vehicle['permit_file'])){ $old=__DIR__.'/'.$vehicle['permit_file']; if(file_exists($old)) @unlink($old);} $vehicle['permit_file']=$url; }
    if($url=saveUpload('rc_file','rc',$uploadDir,$uploadUrlBase)){ if(!empty($vehicle['rc_file'])){ $old=__DIR__.'/'.$vehicle['rc_file']; if(file_exists($old)) @unlink($old);} $vehicle['rc_file']=$url; }
    $sql="UPDATE vehicles SET reg_no='$reg_no', make='$make', model='$model', year=$year, color='$color', engine_no='$engine_no', chassis_no='$chassis_no', ".
        "insurance_date=".($insurance_date?"'$insurance_date'":"NULL").", permit_date=".($permit_date?"'$permit_date'":"NULL").", ".
        "insurance_file=".(!empty($vehicle['insurance_file'])?"'".$conn->real_escape_string($vehicle['insurance_file'])."'":"NULL").", ".
        "permit_file=".(!empty($vehicle['permit_file'])?"'".$conn->real_escape_string($vehicle['permit_file'])."'":"NULL").", ".
        "rc_file=".(!empty($vehicle['rc_file'])?"'".$conn->real_escape_string($vehicle['rc_file'])."'":"NULL")." WHERE id=$id";
    if($conn->query($sql)===TRUE){ header("Location: vehicle_list.php"); exit(); } else { $err="Error: ".$conn->error; }
}
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Edit Vehicle</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:720px;margin:0 auto}.header{display:flex;justify-content:space-between;align-items:center}
.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
form{background:#fafafa;padding:16px;border:1px solid #e5e5e5;border-radius:8px}label{font-weight:600;display:block;margin-top:10px}
input{width:100%;padding:10px;margin-top:6px;border:1px solid #ccc;border-radius:6px}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.actions{margin-top:16px}button{padding:10px 14px;background:#f59e0b;border:none;color:#fff;border-radius:6px;cursor:pointer}.err{color:#b91c1c;font-weight:600}.doc a{margin-right:10px}
</style></head><body><div class="wrap">
<div class="header"><h2>Edit Vehicle</h2><a class="btn" href="vehicle_list.php">Back to List</a></div><?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>
<form method="post" enctype="multipart/form-data">
<div class="row">
<div><label>Registration No</label><input type="text" name="reg_no" value="<?= htmlspecialchars($vehicle['reg_no']) ?>" required></div>
<div><label>Make</label><input type="text" name="make" value="<?= htmlspecialchars($vehicle['make']) ?>" required></div>
<div><label>Model</label><input type="text" name="model" value="<?= htmlspecialchars($vehicle['model']) ?>" required></div>
<div><label>Year</label><input type="number" name="year" value="<?= (int)$vehicle['year'] ?>" required></div>
<div><label>Color</label><input type="text" name="color" value="<?= htmlspecialchars($vehicle['color']) ?>"></div>
<div><label>Engine No</label><input type="text" name="engine_no" value="<?= htmlspecialchars($vehicle['engine_no']) ?>"></div>
<div><label>Chassis No</label><input type="text" name="chassis_no" value="<?= htmlspecialchars($vehicle['chassis_no']) ?>"></div>
<div><label>Insurance Date</label><input type="date" name="insurance_date" value="<?= htmlspecialchars($vehicle['insurance_date']) ?>"></div>
<div><label>Permit Date</label><input type="date" name="permit_date" value="<?= htmlspecialchars($vehicle['permit_date']) ?>"></div>
</div>
<label>Insurance Document</label><?php if(!empty($vehicle['insurance_file'])): ?><div class="doc"><a href="<?= $vehicle['insurance_file'] ?>" target="_blank">View Old</a></div><?php endif; ?><input type="file" name="insurance_file" accept=".pdf,.png,.jpg,.jpeg,.webp">
<label>Permit Document</label><?php if(!empty($vehicle['permit_file'])): ?><div class="doc"><a href="<?= $vehicle['permit_file'] ?>" target="_blank">View Old</a></div><?php endif; ?><input type="file" name="permit_file" accept=".pdf,.png,.jpg,.jpeg,.webp">
<label>RC Document</label><?php if(!empty($vehicle['rc_file'])): ?><div class="doc"><a href="<?= $vehicle['rc_file'] ?>" target="_blank">View Old</a></div><?php endif; ?><input type="file" name="rc_file" accept=".pdf,.png,.jpg,.jpeg,.webp">
<div class="actions"><button type="submit" name="update">Update Vehicle</button></div>
</form></div></body></html>