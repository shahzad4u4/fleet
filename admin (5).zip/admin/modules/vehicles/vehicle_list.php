<?php
require_once __DIR__ . "/../../config/db.php";
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $res = $conn->query("SELECT insurance_file, permit_file, rc_file FROM vehicles WHERE id=$id");
    if ($res && $res->num_rows) {
        $row = $res->fetch_assoc();
        foreach (['insurance_file','permit_file','rc_file'] as $f) {
            if (!empty($row[$f])) {
                $fs = __DIR__ . "/" . $row[$f];
                if (file_exists($fs)) { @unlink($fs); }
            }
        }
    }
    $conn->query("DELETE FROM vehicles WHERE id=$id");
    header("Location: vehicle_list.php"); exit();
}
$result = $conn->query("SELECT * FROM vehicles ORDER BY id DESC");
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Vehicle List</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:1200px;margin:0 auto}.header{display:flex;justify-content:space-between;align-items:center}
.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
table{width:100%;border-collapse:collapse;margin-top:16px}th,td{border:1px solid #e5e5e5;padding:10px;text-align:center}th{background:#f8fafc}
.edit{background:#f59e0b;color:#fff}.delete{background:#ef4444;color:#fff}.actions a{padding:6px 10px;border-radius:6px;text-decoration:none;margin:0 4px;display:inline-block}
.doc a{display:block;margin:2px 0}.searchbar{margin-top:12px}input[type="text"]{padding:8px;border:1px solid #ccc;border-radius:6px;width:260px}
</style>
<script>
function confirmDel(id){ if(confirm('Delete this vehicle?')){ window.location='vehicle_list.php?delete='+id; } }
function filterTable(){ const q=document.getElementById('q').value.toLowerCase(); const rows=document.querySelectorAll('tbody tr'); rows.forEach(r=>{ const txt=r.innerText.toLowerCase(); r.style.display = txt.includes(q)?'':''; }); }
</script></head><body><div class="wrap">
<div class="header"><h2>Vehicle List</h2><a class="btn" href="add_vehicle.php">+ Add New Vehicle</a></div>
<div class="searchbar"><input id="q" type="text" placeholder="Search (Reg, Make, Model, Color...)" onkeyup="filterTable()"></div>
<table><thead><tr>
<th>ID</th><th>Reg No</th><th>Make</th><th>Model</th><th>Year</th><th>Color</th><th>Engine No</th><th>Chassis No</th><th>Insurance</th><th>Permit</th><th>RC</th><th>Actions</th>
</tr></thead><tbody>
<?php while($row=$result->fetch_assoc()): ?><tr>
<td><?= $row['id'] ?></td>
<td><?= htmlspecialchars($row['reg_no']) ?></td>
<td><?= htmlspecialchars($row['make']) ?></td>
<td><?= htmlspecialchars($row['model']) ?></td>
<td><?= (int)$row['year'] ?></td>
<td><?= htmlspecialchars($row['color']) ?></td>
<td><?= htmlspecialchars($row['engine_no']) ?></td>
<td><?= htmlspecialchars($row['chassis_no']) ?></td>
<td class="doc"><?php if(!empty($row['insurance_file'])): ?><a href="<?= $row['insurance_file'] ?>" target="_blank">View</a><?php endif; ?></td>
<td class="doc"><?php if(!empty($row['permit_file'])): ?><a href="<?= $row['permit_file'] ?>" target="_blank">View</a><?php endif; ?></td>
<td class="doc"><?php if(!empty($row['rc_file'])): ?><a href="<?= $row['rc_file'] ?>" target="_blank">View</a><?php endif; ?></td>
<td class="actions"><a class="edit" href="vehicle_edit.php?id=<?= $row['id'] ?>">Edit</a><a class="delete" href="javascript:void(0)" onclick="confirmDel(<?= $row['id'] ?>)">Delete</a></td>
</tr><?php endwhile; ?>
</tbody></table></div></body></html>