<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $reg=$conn->real_escape_string($_POST['reg_no']); $mm=$conn->real_escape_string($_POST['make_model']); $yr=(int)($_POST['year']??0);
  $cap=$conn->real_escape_string($_POST['capacity']); $st=$conn->real_escape_string($_POST['status']??'active');
  $conn->query("INSERT INTO vehicles(reg_no,make_model,year,capacity,status) VALUES('$reg','$mm',$yr,'$cap','$st')");
  header('Location:index.php'); exit;
}
require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Add Vehicle</h2>
<form method="post"><div class="row">
<div><label>Registration No</label><input name="reg_no" required></div>
<div><label>Make / Model</label><input name="make_model"></div>
<div><label>Year</label><input type="number" name="year"></div>
<div><label>Capacity</label><input name="capacity"></div>
<div><label>Status</label><select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
</div><br><button class="btn">Save</button> <a class="btn" href="index.php">Cancel</a></form></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
