<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/db.php';
$id=(int)($_GET['id']??0); $veh=$conn->query("SELECT * FROM vehicles WHERE id=$id")->fetch_assoc(); if(!$veh){ header('Location:index.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $reg=$conn->real_escape_string($_POST['reg_no']); $mm=$conn->real_escape_string($_POST['make_model']); $yr=(int)($_POST['year']??0);
  $cap=$conn->real_escape_string($_POST['capacity']); $st=$conn->real_escape_string($_POST['status']??'active');
  $conn->query("UPDATE vehicles SET reg_no='$reg', make_model='$mm', year=$yr, capacity='$cap', status='$st' WHERE id=$id");
  header('Location:index.php'); exit;
}
require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Edit Vehicle #<?=$veh['id']?></h2>
<form method="post"><div class="row">
<div><label>Registration No</label><input name="reg_no" value="<?=$veh['reg_no']?>" required></div>
<div><label>Make / Model</label><input name="make_model" value="<?=$veh['make_model']?>"></div>
<div><label>Year</label><input type="number" name="year" value="<?=$veh['year']?>"></div>
<div><label>Capacity</label><input name="capacity" value="<?=$veh['capacity']?>"></div>
<div><label>Status</label><select name="status">
<option <?=$veh['status']=='active'?'selected':''?> value="active">Active</option>
<option <?=$veh['status']=='inactive'?'selected':''?> value="inactive">Inactive</option></select></div>
</div><br><button class="btn">Update</button> <a class="btn" href="index.php">Cancel</a></form></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
