<?php
include("../../admin/includes/header.php"); 
include("../../config/db.php");
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Vehicles</h1>
    </section>

    <section class="content">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Vehicles List</h3>
                <a href="add.php" class="btn btn-success btn-sm">+ Add Vehicle</a>
            </div>

            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Reg No</th>
                            <th>Make</th>
                            <th>Model</th>
                            <th>Year</th>
                            <th>Color</th>
                            <th>Engine No</th>
                            <th>Chassis No</th>
                            <th>Insurance</th>
                            <th>Permit</th>
                            <th>RC</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM vehicles";
                        $result = mysqli_query($conn, $query);
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['reg_no']}</td>
                                    <td>{$row['make']}</td>
                                    <td>{$row['model']}</td>
                                    <td>{$row['year']}</td>
                                    <td>{$row['color']}</td>
                                    <td>{$row['engine_no']}</td>
                                    <td>{$row['chassis_no']}</td>
                                    <td>{$row['insurance']}</td>
                                    <td>{$row['permit']}</td>
                                    <td>{$row['rc']}</td>
                                    <td>
                                        <a href='edit.php?id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='delete.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Are you sure?')\">Delete</a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='12' class='text-center'>No Vehicles Found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<?php include("../../admin/includes/footer.php"); ?>