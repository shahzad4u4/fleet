CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(50) NOT NULL,
  make VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  year INT NOT NULL,
  color VARCHAR(50),
  engine_no VARCHAR(100),
  chassis_no VARCHAR(100),
  insurance_date DATE,
  permit_date DATE,
  insurance_file VARCHAR(255),
  permit_file VARCHAR(255),
  rc_file VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);