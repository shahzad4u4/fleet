<?php
// Debugging ON (blank page na aaye)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database file include
$dbPath = __DIR__ . "/../../config/db.php";
if (!file_exists($dbPath)) {
    die("❌ Database config file NOT found at: " . $dbPath);
}
require_once $dbPath;

// Uploads folder
$uploadDir = __DIR__ . "/uploads/";
$uploadUrlBase = "uploads/";

if (!is_dir($uploadDir)) { 
    mkdir($uploadDir, 0777, true); 
}

$msg = ""; 
$err = "";

$insuranceFile = ""; 
$permitFile = ""; 
$rcFile = "";

// Save Upload Helper
function saveUpload($field, $prefix, $uploadDir, $uploadUrlBase){
    if (!empty($_FILES[$field]['name'])) {
        $safe = preg_replace('/[^A-Za-z0-9\.\-_]/', '_', basename($_FILES[$field]['name']));
        $fs = $uploadDir . time() . "_" . $prefix . "_" . $safe;
        if (move_uploaded_file($_FILES[$field]['tmp_name'], $fs)) {
            return $uploadUrlBase . basename($fs);
        }
    }
    return "";
}

// Form Handling
if (isset($_POST['save'])) {
    $reg_no     = $conn->real_escape_string($_POST['reg_no']);
    $make       = $conn->real_escape_string($_POST['make']);
    $model      = $conn->real_escape_string($_POST['model']);
    $year       = (int)$_POST['year'];
    $color      = $conn->real_escape_string($_POST['color'] ?? "");
    $engine_no  = $conn->real_escape_string($_POST['engine_no'] ?? "");
    $chassis_no = $conn->real_escape_string($_POST['chassis_no'] ?? "");
    $insurance_date = !empty($_POST['insurance_date']) ? $conn->real_escape_string($_POST['insurance_date']) : null;
    $permit_date    = !empty($_POST['permit_date']) ? $conn->real_escape_string($_POST['permit_date']) : null;

    // Upload files
    $insuranceFile = saveUpload("insurance_file", "insurance", $uploadDir, $uploadUrlBase);
    $permitFile    = saveUpload("permit_file", "permit", $uploadDir, $uploadUrlBase);
    $rcFile        = saveUpload("rc_file", "rc", $uploadDir, $uploadUrlBase);

    // Insert SQL
    $sql = "INSERT INTO vehicles 
            (reg_no, make, model, year, color, engine_no, chassis_no, insurance_date, permit_date, insurance_file, permit_file, rc_file)
            VALUES (
                '$reg_no','$make','$model',$year,'$color','$engine_no','$chassis_no'," .
                ($insurance_date ? "'$insurance_date'" : "NULL") . "," .
                ($permit_date ? "'$permit_date'" : "NULL") . "," .
                ($insuranceFile ? "'$insuranceFile'" : "NULL") . "," .
                ($permitFile ? "'$permitFile'" : "NULL") . "," .
                ($rcFile ? "'$rcFile'" : "NULL") . ")";

    if ($conn->query($sql) === TRUE) { 
        $msg = "✅ Vehicle Added Successfully!"; 
    } else { 
        $err = "❌ Error: " . $conn->error; 
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add Vehicle</title>
    <style>
        body{font-family:Arial, sans-serif;margin:24px}
        .wrap{max-width:720px;margin:0 auto}
        .header{display:flex;justify-content:space-between;align-items:center}
        .btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
        form{background:#fafafa;padding:16px;border:1px solid #e5e5e5;border-radius:8px}
        label{font-weight:600;display:block;margin-top:10px}
        input{width:100%;padding:10px;margin-top:6px;border:1px solid #ccc;border-radius:6px}
        .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .actions{margin-top:16px}
        button{padding:10px 14px;background:#2563eb;border:none;color:#fff;border-radius:6px;cursor:pointer}
        .msg{color:green;font-weight:600}
        .err{color:#b91c1c;font-weight:600}
    </style>
</head>
<body>
<div class="wrap">
    <div class="header">
        <h2>Add New Vehicle</h2>
        <a class="btn" href="vehicle_list.php">Vehicle List</a>
    </div>

    <?php if(!empty($msg)) echo "<p class='msg'>$msg</p>"; ?>
    <?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>

    <form method="post" enctype="multipart/form-data">
        <div class="row">
            <div><label>Registration No</label><input type="text" name="reg_no" required></div>
            <div><label>Make</label><input type="text" name="make" required></div>
            <div><label>Model</label><input type="text" name="model" required></div>
            <div><label>Year</label><input type="number" name="year" min="1950" max="2100" required></div>
            <div><label>Color</label><input type="text" name="color"></div>
            <div><label>Engine No</label><input type="text" name="engine_no"></div>
            <div><label>Chassis No</label><input type="text" name="chassis_no"></div>
            <div><label>Insurance Date</label><input type="date" name="insurance_date"></div>
            <div><label>Permit Date</label><input type="date" name="permit_date"></div>
        </div>

        <label>Insurance Document</label><input type="file" name="insurance_file" accept=".pdf,.png,.jpg,.jpeg,.webp">
        <label>Permit Document</label><input type="file" name="permit_file" accept=".pdf,.png,.jpg,.jpeg,.webp">
        <label>RC Document</label><input type="file" name="rc_file" accept=".pdf,.png,.jpg,.jpeg,.webp">

        <div class="actions"><button type="submit" name="save">Save Vehicle</button></div>
    </form>
</div>
</body>
</html>