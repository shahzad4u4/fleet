# Fleet Vehicle Module (PHP + MySQL)
Includes:
- Add Vehicle (with uploads)
- List/Search
- Edit + replace documents
- Delete (removes files)
- schema.sql and db.php

## Setup
1) Copy to `htdocs/fleet/` (XAMPP).
2) Create DB `fleet` (or edit `db.php`).
3) Import `schema.sql`.
4) Open `http://localhost/fleet/vehicle_list.php` or `add_vehicle.php`.
