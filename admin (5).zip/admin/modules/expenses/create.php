<?php require __DIR__.'/../../admin/includes/auth.php'; require __DIR__.'/../../admin/includes/db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $d=$conn->real_escape_string($_POST['expense_date']); $c=$conn->real_escape_string($_POST['category']);
  $a=(float)($_POST['amount']??0); $n=$conn->real_escape_string($_POST['notes']??'');
  $conn->query("INSERT INTO expenses(expense_date,category,amount,notes) VALUES('$d','$c',$a,'$n')");
  header('Location:index.php'); exit;
}
require __DIR__.'/../../admin/includes/header.php'; ?>
<div class="card"><h2>Add Expense</h2>
<form method="post"><div class="row">
<div><label>Date</label><input type="date" name="expense_date" required></div>
<div><label>Category</label><input name="category" required></div>
<div><label>Amount</label><input type="number" step="0.01" name="amount" required></div>
<div><label>Notes</label><input name="notes"></div>
</div><br><button class="btn">Save</button> <a class="btn" href="index.php">Cancel</a></form></div>
<?php require __DIR__.'/../../admin/includes/footer.php'; ?>
