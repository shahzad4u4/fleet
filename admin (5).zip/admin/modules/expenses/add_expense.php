<?php
require_once __DIR__ . "/db.php";

$uploadDirFs = __DIR__ . "/expense_uploads/";
$uploadDirUrl = "expense_uploads/";
if (!is_dir($uploadDirFs)) { mkdir($uploadDirFs, 0777, true); }

if (isset($_POST['submit'])) {
    $vehicle_id    = (int)$_POST['vehicle_id'];
    $expense_type  = $conn->real_escape_string($_POST['expense_type']);
    $vendor        = $conn->real_escape_string($_POST['vendor'] ?? "");
    $expense_date  = $conn->real_escape_string($_POST['expense_date']);
    $amount        = (float)$_POST['amount'];
    $payment_method= $conn->real_escape_string($_POST['payment_method']);
    $reference_no  = $conn->real_escape_string($_POST['reference_no'] ?? "");
    $notes         = $conn->real_escape_string($_POST['notes'] ?? "");
    $attachmentUrl = "";

    if (!empty($_FILES['attachment']['name'])) {
        $safe = preg_replace('/[^A-Za-z0-9\.\-_]/','_', basename($_FILES['attachment']['name']));
        $fs   = $uploadDirFs . time() . "_expense_" . $safe;
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $fs)) {
            $attachmentUrl = $uploadDirUrl . basename($fs);
        }
    }

    $sql = "INSERT INTO expenses (vehicle_id, expense_type, vendor, expense_date, amount, payment_method, reference_no, notes, attachment)
            VALUES ($vehicle_id, '$expense_type', '$vendor', '$expense_date', $amount, '$payment_method', '$reference_no', '$notes', " .
            ($attachmentUrl ? "'$attachmentUrl'" : "NULL") . ")";

    if ($conn->query($sql)) { $msg = "Expense Added Successfully!"; } else { $err = "Error: " . $conn->error; }
}
$vehicles = $conn->query("SELECT id, reg_no FROM vehicles ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"><title>Add Expense</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:760px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
form{background:#fafafa;padding:16px;border:1px solid #e5e5e5;border-radius:8px}label{font-weight:600;display:block;margin-top:10px}
input,select,textarea{width:100%;padding:10px;margin-top:6px;border:1px solid #ccc;border-radius:6px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.actions{margin-top:16px}
button{padding:10px 14px;background:#2563eb;border:none;color:#fff;border-radius:6px;cursor:pointer}.msg{color:green;font-weight:600}.err{color:#b91c1c;font-weight:600}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h2>Add Expense</h2>
    <a class="btn" href="expense_list.php">Expense List</a>
  </div>
  <?php if(!empty($msg)) echo "<p class='msg'>$msg</p>"; ?>
  <?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>
  <form method="post" enctype="multipart/form-data">
    <label>Vehicle</label>
    <select name="vehicle_id" required>
      <?php while($v = $vehicles->fetch_assoc()): ?>
        <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['reg_no']) ?></option>
      <?php endwhile; ?>
    </select>

    <div class="row">
      <div>
        <label>Expense Type</label>
        <select name="expense_type" required>
            <option>Fuel</option>
            <option>Maintenance</option>
            <option>Toll</option>
            <option>Fine</option>
            <option>Insurance</option>
            <option>Parts</option>
            <option>Other</option>
        </select>
      </div>
      <div>
        <label>Vendor</label>
        <input type="text" name="vendor">
      </div>
      <div>
        <label>Expense Date</label>
        <input type="date" name="expense_date" required>
      </div>
      <div>
        <label>Amount</label>
        <input type="number" step="0.01" name="amount" required>
      </div>
      <div>
        <label>Payment Method</label>
        <select name="payment_method">
            <option>Cash</option>
            <option>Bank</option>
            <option>Card</option>
            <option>Wallet</option>
            <option>Other</option>
        </select>
      </div>
      <div>
        <label>Reference No</label>
        <input type="text" name="reference_no">
      </div>
    </div>

    <label>Notes</label>
    <textarea name="notes" rows="3"></textarea>

    <label>Receipt / Attachment (PDF or Image)</label>
    <input type="file" name="attachment" accept=".pdf,.png,.jpg,.jpeg,.webp">

    <div class="actions">
      <button type="submit" name="submit">Save Expense</button>
    </div>
  </form>
</div>
</body>
</html>
