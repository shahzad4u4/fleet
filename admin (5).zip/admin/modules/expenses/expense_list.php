<?php
require_once __DIR__ . "/db.php";

// Filters
$q = isset($_GET['q']) ? trim($_GET['q']) : "";
$from = isset($_GET['from']) ? $_GET['from'] : "";
$to   = isset($_GET['to']) ? $_GET['to'] : "";
$etype= isset($_GET['etype']) ? $_GET['etype'] : "";

$where = [];
if ($q !== "") {
    $qEsc = $conn->real_escape_string($q);
    $where[] = "(vehicles.reg_no LIKE '%$qEsc%' OR expenses.vendor LIKE '%$qEsc%' OR expenses.reference_no LIKE '%$qEsc%')";
}
if ($from !== "") { $where[] = "expenses.expense_date >= '".$conn->real_escape_string($from)."'"; }
if ($to !== "")   { $where[] = "expenses.expense_date <= '".$conn->real_escape_string($to)."'"; }
if ($etype !== ""){ $where[] = "expenses.expense_type = '".$conn->real_escape_string($etype)."'"; }

$whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT expenses.*, vehicles.reg_no 
        FROM expenses 
        JOIN vehicles ON vehicles.id = expenses.vehicle_id
        $whereSql
        ORDER BY expenses.expense_date DESC, expenses.id DESC";
$res = $conn->query($sql);

// Totals
$sum = 0;
$rows = [];
while($row = $res->fetch_assoc()){ $rows[] = $row; $sum += (float)$row['amount']; }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"><title>Expense List</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:1200px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
table{width:100%;border-collapse:collapse;margin-top:16px}th,td{border:1px solid #e5e5e5;padding:10px;text-align:center}th{background:#f8fafc}
.actions a{padding:6px 10px;border-radius:6px;text-decoration:none;margin:0 4px;display:inline-block}
.filters{margin-top:12px}input[type="text"],input[type="date"],select{padding:8px;border:1px solid #ccc;border-radius:6px}
tfoot td{font-weight:700;background:#f8fafc}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h2>Expense List</h2>
    <a class="btn" href="add_expense.php">+ Add Expense</a>
  </div>

  <form method="get" class="filters">
    <input type="text" name="q" placeholder="Search (Vehicle, Vendor, Ref No)" value="<?= htmlspecialchars($q) ?>">
    <label>From</label><input type="date" name="from" value="<?= htmlspecialchars($from) ?>">
    <label>To</label><input type="date" name="to" value="<?= htmlspecialchars($to) ?>">
    <label>Type</label>
    <select name="etype">
        <option value="">All</option>
        <?php foreach (['Fuel','Maintenance','Toll','Fine','Insurance','Parts','Other'] as $t): ?>
          <option value="<?= $t ?>" <?= $etype==$t?'selected':''; ?>><?= $t ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn" type="submit">Filter</button>
  </form>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Vehicle</th>
        <th>Type</th>
        <th>Vendor</th>
        <th>Amount</th>
        <th>Payment</th>
        <th>Ref No</th>
        <th>Attachment</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $row): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['expense_date']) ?></td>
        <td><?= htmlspecialchars($row['reg_no']) ?></td>
        <td><?= htmlspecialchars($row['expense_type']) ?></td>
        <td><?= htmlspecialchars($row['vendor']) ?></td>
        <td><?= number_format($row['amount'], 2) ?></td>
        <td><?= htmlspecialchars($row['payment_method']) ?></td>
        <td><?= htmlspecialchars($row['reference_no']) ?></td>
        <td>
          <?php if(!empty($row['attachment'])): ?>
            <a href="<?= $row['attachment'] ?>" target="_blank">View</a>
          <?php endif; ?>
        </td>
        <td class="actions">
          <a href="edit_expense.php?id=<?= $row['id'] ?>">Edit</a>
          <a href="delete_expense.php?id=<?= $row['id'] ?>">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="5" style="text-align:right">Total</td>
        <td><?= number_format($sum, 2) ?></td>
        <td colspan="4"></td>
      </tr>
    </tfoot>
  </table>
</div>
</body>
</html>
