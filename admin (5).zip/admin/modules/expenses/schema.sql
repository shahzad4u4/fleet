-- Expenses table
CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    expense_type VARCHAR(100) NOT NULL,   -- Fuel, Maintenance, Toll, Fine, Insurance, Parts, Other
    vendor VARCHAR(120),
    expense_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('Cash','Bank','Card','Wallet','Other') DEFAULT 'Cash',
    reference_no VARCHAR(100),
    notes TEXT,
    attachment VARCHAR(255),              -- receipt/invoice photo/pdf
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
);
