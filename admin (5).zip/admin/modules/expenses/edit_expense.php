<?php
require_once __DIR__ . "/db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = $conn->query("SELECT * FROM expenses WHERE id=$id");
if (!$res || !$res->num_rows) { die("Expense not found."); }
$exp = $res->fetch_assoc();

$uploadDirFs = __DIR__ . "/expense_uploads/";
$uploadDirUrl = "expense_uploads/";
if (!is_dir($uploadDirFs)) { mkdir($uploadDirFs, 0777, true); }

if (isset($_POST['update'])) {
    $vehicle_id    = (int)$_POST['vehicle_id'];
    $expense_type  = $conn->real_escape_string($_POST['expense_type']);
    $vendor        = $conn->real_escape_string($_POST['vendor'] ?? "");
    $expense_date  = $conn->real_escape_string($_POST['expense_date']);
    $amount        = (float)$_POST['amount'];
    $payment_method= $conn->real_escape_string($_POST['payment_method']);
    $reference_no  = $conn->real_escape_string($_POST['reference_no'] ?? "");
    $notes         = $conn->real_escape_string($_POST['notes'] ?? "");

    // replace attachment if new uploaded
    if (!empty($_FILES['attachment']['name'])) {
        $safe = preg_replace('/[^A-Za-z0-9\.\-_]/','_', basename($_FILES['attachment']['name']));
        $fs   = $uploadDirFs . time() . "_expense_" . $safe;
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $fs)) {
            // delete old
            if (!empty($exp['attachment'])) {
                $old = __DIR__ . "/" . $exp['attachment'];
                if (file_exists($old)) { @unlink($old); }
            }
            $exp['attachment'] = $uploadDirUrl . basename($fs);
        }
    }

    $sql = "UPDATE expenses SET
                vehicle_id=$vehicle_id,
                expense_type='$expense_type',
                vendor='$vendor',
                expense_date='$expense_date',
                amount=$amount,
                payment_method='$payment_method',
                reference_no='$reference_no',
                notes='$notes',
                attachment=" . (!empty($exp['attachment']) ? "'".$conn->real_escape_string($exp['attachment'])."'" : "NULL") . "
            WHERE id=$id";

    if ($conn->query($sql)) {
        header("Location: expense_list.php");
        exit();
    } else {
        $err = "Error: " . $conn->error;
    }
}
$vehicles = $conn->query("SELECT id, reg_no FROM vehicles ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"><title>Edit Expense</title>
<style>
body{font-family:Arial, sans-serif;margin:24px}.wrap{max-width:760px;margin:0 auto}
.header{display:flex;justify-content:space-between;align-items:center}.btn{padding:8px 12px;background:#0e8f4c;color:#fff;text-decoration:none;border-radius:6px}
form{background:#fafafa;padding:16px;border:1px solid #e5e5e5;border-radius:8px}label{font-weight:600;display:block;margin-top:10px}
input,select,textarea{width:100%;padding:10px;margin-top:6px;border:1px solid #ccc;border-radius:6px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.actions{margin-top:16px}
button{padding:10px 14px;background:#f59e0b;border:none;color:#fff;border-radius:6px;cursor:pointer}.err{color:#b91c1c;font-weight:600}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h2>Edit Expense</h2>
    <a class="btn" href="expense_list.php">Back to List</a>
  </div>
  <?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>
  <form method="post" enctype="multipart/form-data">
    <label>Vehicle</label>
    <select name="vehicle_id" required>
      <?php while($v = $vehicles->fetch_assoc()): ?>
        <option value="<?= $v['id'] ?>" <?= $exp['vehicle_id']==$v['id'] ? 'selected' : '' ?>><?= htmlspecialchars($v['reg_no']) ?></option>
      <?php endwhile; ?>
    </select>

    <div class="row">
      <div>
        <label>Expense Type</label>
        <select name="expense_type" required>
          <?php foreach (['Fuel','Maintenance','Toll','Fine','Insurance','Parts','Other'] as $t): ?>
            <option value="<?= $t ?>" <?= $exp['expense_type']==$t ? 'selected':''; ?>><?= $t ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Vendor</label>
        <input type="text" name="vendor" value="<?= htmlspecialchars($exp['vendor']) ?>">
      </div>
      <div>
        <label>Expense Date</label>
        <input type="date" name="expense_date" value="<?= htmlspecialchars($exp['expense_date']) ?>" required>
      </div>
      <div>
        <label>Amount</label>
        <input type="number" step="0.01" name="amount" value="<?= htmlspecialchars($exp['amount']) ?>" required>
      </div>
      <div>
        <label>Payment Method</label>
        <select name="payment_method">
            <?php foreach (['Cash','Bank','Card','Wallet','Other'] as $p): ?>
              <option value="<?= $p ?>" <?= $exp['payment_method']==$p ? 'selected':''; ?>><?= $p ?></option>
            <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Reference No</label>
        <input type="text" name="reference_no" value="<?= htmlspecialchars($exp['reference_no']) ?>">
      </div>
    </div>

    <label>Notes</label>
    <textarea name="notes" rows="3"><?= htmlspecialchars($exp['notes']) ?></textarea>

    <?php if(!empty($exp['attachment'])): ?>
      <div><a href="<?= $exp['attachment'] ?>" target="_blank">View Existing Attachment</a></div>
    <?php endif; ?>
    <label>Replace Attachment</label>
    <input type="file" name="attachment" accept=".pdf,.png,.jpg,.jpeg,.webp">

    <div class="actions">
      <button type="submit" name="update">Update Expense</button>
    </div>
  </form>
</div>
</body>
</html>
