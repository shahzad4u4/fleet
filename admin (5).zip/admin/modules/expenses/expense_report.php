<?php
include 'db.php';

// Expense usage report
$expenseResult = $conn->query("
    SELECT MONTH(date) as month, YEAR(date) as year,
           SUM(amount) as total_expense
    FROM expenses
    GROUP BY YEAR(date), MONTH(date)
    ORDER BY YEAR(date), MONTH(date)
");

$expenses = [];
$labels = [];
$totals = [];
while ($row = $expenseResult->fetch_assoc()) {
    $monthYear = $row['month'] . '-' . $row['year'];
    $expenses[] = $row;
    $labels[] = $monthYear;
    $totals[] = $row['total_expense'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Expense Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; background: white; }
        table th, table td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        table th { background: #28a745; color: white; }
        .chart-container { width: 70%; margin: auto; }
    </style>
</head>
<body>
    <h2>Expense Report</h2>

    <table>
        <tr>
            <th>Month-Year</th>
            <th>Total Expense (PKR)</th>
        </tr>
        <?php foreach ($expenses as $row) { ?>
        <tr>
            <td><?php echo $row['month'] . '-' . $row['year']; ?></td>
            <td><?php echo $row['total_expense']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <div class="chart-container">
        <canvas id="expenseChart"></canvas>
    </div>

    <script>
        const ctx = document.getElementById('expenseChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Total Expense',
                    data: <?php echo json_encode($totals); ?>,
                    backgroundColor: '#28a745',
                    borderColor: '#28a745',
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: true } },
                scales: { y: { beginAtZero: true } }
            }
        });
    </script>
</body>
</html>
