
<?php
require_once __DIR__ . '/../../includes/session_check.php';
require_once __DIR__ . '/../../includes/db.php';
include __DIR__ . '/../../admin/partials/header.php';
$rows=[]; $rs=$conn->query("SELECT * FROM `expenses` ORDER BY id DESC LIMIT 100"); if($rs){ while($r=$rs->fetch_assoc()){ $rows[]=$r; } }
?>
<section class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
  <div class="flex items-center justify-between">
    <h2 class="font-semibold text-slate-800">Expenses</h2>
    <a href="#" class="px-3 py-1.5 rounded-md bg-brand text-white text-sm">Create (sample)</a>
  </div>
  <div class="mt-3 overflow-auto">
    <table class="min-w-full divide-y divide-slate-200">
      <thead class="bg-slate-50"><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>ID</th><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>category</th><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>amount</th><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>date</th><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>note</th><th class='px-3 py-2 text-left text-xs font-medium text-slate-500 uppercase'>Actions</th></thead>
      <tbody class="divide-y divide-slate-200">
        <?php foreach($rows as $row): ?>
          <tr class="hover:bg-slate-50">
            <td class="px-3 py-2 text-sm text-slate-700"><?php echo $row['id']; ?></td>
            <td class='px-3 py-2 text-sm text-slate-700'><?php echo htmlspecialchars($row['category'] ?? ''); ?></td><td class='px-3 py-2 text-sm text-slate-700'><?php echo htmlspecialchars($row['amount'] ?? ''); ?></td><td class='px-3 py-2 text-sm text-slate-700'><?php echo htmlspecialchars($row['date'] ?? ''); ?></td><td class='px-3 py-2 text-sm text-slate-700'><?php echo htmlspecialchars($row['note'] ?? ''); ?></td>
            <td class="px-3 py-2 text-sm"><a class="text-brand" href="#">Edit</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if(empty($rows)): ?>
          <tr><td colspan="6" class="px-3 py-6 text-center text-slate-500">No records</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php include __DIR__ . '/../../admin/partials/footer.php'; ?>
