<?php
require __DIR__ . '/../../includes/auth.php';
require __DIR__ . '/../../includes/db.php';
$page_title = 'Slider';
include __DIR__ . '/../../includes/header.php';

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['image'])) {
    $dir = __DIR__ . '/../../uploads/';
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
    $name = time().'_'.preg_replace('/[^a-zA-Z0-9._-]/','', $_FILES['image']['name']);
    $path = $dir . $name;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
        $rel = '/uploads/' . $name;
        $stmt = $conn->prepare("INSERT INTO slider (image_path, caption, active) VALUES (?, ?, 1)");
        $cap = $_POST['caption'] ?? '';
        $stmt->bind_param('ss', $rel, $cap);
        $stmt->execute();
        echo '<div class="p-3 bg-green-100 border text-green-700 rounded mb-3">Slider updated.</div>';
    } else {
        echo '<div class="p-3 bg-red-100 border text-red-700 rounded mb-3">Upload failed.</div>';
    }
}
$res = $conn->query("SELECT * FROM slider ORDER BY id DESC");
?>
<h2 class="text-xl font-semibold mb-4">Slider Images</h2>
<form method="post" enctype="multipart/form-data" class="bg-white p-4 rounded-xl border shadow max-w-xl grid gap-3 mb-6">
  <label class="block">
    <span class="text-sm">Caption</span>
    <input name="caption" class="mt-1 w-full border rounded px-3 py-2">
  </label>
  <label class="block">
    <span class="text-sm">Image</span>
    <input type="file" name="image" accept="image/*" class="mt-1 w-full border rounded px-3 py-2" required>
  </label>
  <button class="bg-blue-600 text-white px-4 py-2 rounded w-max">Upload</button>
</form>
<div class="grid md:grid-cols-3 gap-3">
<?php while($r=$res->fetch_assoc()): ?>
  <div class="bg-white rounded-xl border shadow p-2">
    <img src="<?php echo htmlspecialchars($r['image_path']); ?>" class="w-full h-40 object-cover rounded" />
    <div class="text-sm mt-1"><?php echo htmlspecialchars($r['caption']); ?></div>
  </div>
<?php endwhile; ?>
</div>
<?php include __DIR__ . '/../../includes/footer.php'; ?>