# Fleet Master – Merged Build

This is an auto-merged project created from your uploaded master zip.
- Files have been organized into `/modules/*`, `/config`, `/public/assets`, and `/sql`.
- Duplicate filename conflicts are preserved with `__dupN` suffix.
- Start from `index.php` to browse module files. You'll still need to connect routes/menus as per your framework.

## Recommended Next Steps
1. Review `/config/db.php` (or your config) and set credentials.
2. Import SQL files from `/sql` into your database in a safe order.
3. Test critical flows:
   - Booking/Bilty → Dispatch → Trip → Invoice → Payment
4. Standardize header/sidebar/layout includes across modules.
5. Add proper auth guard for `/modules/*` if needed.
