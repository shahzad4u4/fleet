
import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About HS Logistics')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                SizedBox(height: 12),
                Image(image: AssetImage('assets/logo.png'), height: 96),
                SizedBox(height: 16),
                Text('HS Logistics', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('Fast, Reliable & Secure', style: TextStyle(fontSize: 16)),
                SizedBox(height: 16),
                Text('Shahzad\nContact: 0318-2194607\nEmail: info@hslogistics.pk', textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
