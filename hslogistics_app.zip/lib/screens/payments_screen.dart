
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/database_helper.dart';
import '../models/payment.dart';

class PaymentsScreen extends StatefulWidget {
  final String userEmail;
  final String role;
  const PaymentsScreen({super.key, required this.userEmail, required this.role});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final df = NumberFormat("#,##0.##");
  List<Payment> list = [];

  Future<void> _load() async {
    final db = await DB().database;
    final rows = await db.query('payments', orderBy: 'date DESC');
    setState(() => list = rows.map((e) => Payment.fromMap(e)).toList());
  }

  Future<void> _addOrEdit({Payment? existing}) async {
    final party = TextEditingController(text: existing?.party);
    final amount = TextEditingController(text: existing?.amount.toString());
    final ref = TextEditingController(text: existing?.reference);
    String type = existing?.type ?? 'incoming';
    String date = existing?.date ?? DateTime.now().toIso8601String();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(existing == null ? 'Add Payment' : 'Edit Payment'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: party, decoration: const InputDecoration(labelText: 'Party')), 
              const SizedBox(height: 8),
              DropdownButtonFormField(
                value: type,
                items: const [
                  DropdownMenuItem(value: 'incoming', child: Text('Incoming (Received)')),
                  DropdownMenuItem(value: 'outgoing', child: Text('Outgoing (Paid)')),
                ],
                onChanged: (v) => type = v as String,
                decoration: const InputDecoration(labelText: 'Type'),
              ),
              const SizedBox(height: 8),
              TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (PKR)')),
              const SizedBox(height: 8),
              TextField(controller: ref, decoration: const InputDecoration(labelText: 'Reference / Note')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final db = await DB().database;
              final data = Payment(
                id: existing?.id,
                party: party.text,
                type: type,
                amount: double.tryParse(amount.text) ?? 0,
                date: date,
                reference: ref.text,
                createdBy: widget.userEmail,
              );
              if (existing == null) {
                await db.insert('payments', data.toMap());
              } else {
                await db.update('payments', data.toMap(), where: 'id = ?', whereArgs: [existing.id]);
              }
              if (!mounted) return;
              Navigator.pop(context);
              _load();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(int id) async {
    if (widget.role != 'admin') return;
    final db = await DB().database;
    await db.delete('payments', where: 'id = ?', whereArgs: [id]);
    _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payments')),
      floatingActionButton: FloatingActionButton(onPressed: () => _addOrEdit(), child: const Icon(Icons.add)),
      body: ListView.separated(
        itemBuilder: (_, i) {
          final p = list[i];
          return ListTile(
            leading: Icon(p.type == 'incoming' ? Icons.south_west : Icons.north_east, color: p.type == 'incoming' ? Colors.green : Colors.red),
            title: Text('${p.party} — PKR ${df.format(p.amount)}'),
            subtitle: Text('${p.type} • ${p.reference}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => _addOrEdit(existing: p), icon: const Icon(Icons.edit)),
                if (widget.role == 'admin') IconButton(onPressed: () => _delete(p.id!), icon: const Icon(Icons.delete)),
              ],
            ),
          );
        },
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemCount: list.length,
      ),
    );
  }
}
