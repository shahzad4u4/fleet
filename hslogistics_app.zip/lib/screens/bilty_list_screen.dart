
import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../models/bilty.dart';

class BiltyListScreen extends StatefulWidget {
  final String userEmail;
  final String role;
  const BiltyListScreen({super.key, required this.userEmail, required this.role});

  @override
  State<BiltyListScreen> createState() => _BiltyListScreenState();
}

class _BiltyListScreenState extends State<BiltyListScreen> {
  List<Bilty> list = [];

  Future<void> _load() async {
    final db = await DB().database;
    final rows = await db.query('bilties', orderBy: 'date DESC');
    setState(() => list = rows.map((e) => Bilty.fromMap(e)).toList());
  }

  Future<void> _addOrEdit({Bilty? existing}) async {
    final vendor = TextEditingController(text: existing?.vendor);
    final vehicle = TextEditingController(text: existing?.vehicle);
    final goods = TextEditingController(text: existing?.goods);
    final fromCity = TextEditingController(text: existing?.fromCity);
    final toCity = TextEditingController(text: existing?.toCity);
    final km = TextEditingController(text: existing?.km.toString());
    final amount = TextEditingController(text: existing?.amount.toString());
    final notes = TextEditingController(text: existing?.notes ?? '');

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(existing == null ? 'Add Bilty / Vendor' : 'Edit Bilty'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: vendor, decoration: const InputDecoration(labelText: 'Vendor')),
              TextField(controller: vehicle, decoration: const InputDecoration(labelText: 'Vehicle')),
              TextField(controller: goods, decoration: const InputDecoration(labelText: 'Goods')),
              Row(children: [
                Expanded(child: TextField(controller: fromCity, decoration: const InputDecoration(labelText: 'From'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: toCity, decoration: const InputDecoration(labelText: 'To')),
                ),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: km, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'KM'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (PKR)'))),
              ]),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Notes')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final db = await DB().database;
              final data = Bilty(
                id: existing?.id,
                vendor: vendor.text,
                vehicle: vehicle.text,
                goods: goods.text,
                fromCity: fromCity.text,
                toCity: toCity.text,
                km: double.tryParse(km.text) ?? 0,
                amount: double.tryParse(amount.text) ?? 0,
                date: DateTime.now().toIso8601String(),
                notes: notes.text,
                createdBy: widget.userEmail,
              );
              if (existing == null) {
                await db.insert('bilties', data.toMap());
              } else {
                await db.update('bilties', data.toMap(), where: 'id = ?', whereArgs: [existing.id]);
              }
              if (!mounted) return;
              Navigator.pop(context);
              _load();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(int id) async {
    if (widget.role != 'admin') return;
    final db = await DB().database;
    await db.delete('bilties', where: 'id = ?', whereArgs: [id]);
    _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bilty / Vendor Records')),
      floatingActionButton: FloatingActionButton(onPressed: () => _addOrEdit(), child: const Icon(Icons.add)),
      body: ListView.separated(
        itemBuilder: (_, i) {
          final b = list[i];
          return ListTile(
            leading: const Icon(Icons.receipt_long),
            title: Text('${b.vendor} — ${b.vehicle}'),
            subtitle: Text('${b.fromCity} ➜ ${b.toCity} • KM ${b.km} • PKR ${b.amount}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => _addOrEdit(existing: b), icon: const Icon(Icons.edit)),
                if (widget.role == 'admin') IconButton(onPressed: () => _delete(b.id!), icon: const Icon(Icons.delete)),
              ],
            ),
          );
        },
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemCount: list.length,
      ),
    );
  }
}
