
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static final DB _instance = DB._internal();
  factory DB() => _instance;
  DB._internal();
  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'hslogistics.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            name TEXT,
            role TEXT
          );
        ''');
        await db.execute('''
          CREATE TABLE bilties(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vendor TEXT,
            vehicle TEXT,
            goods TEXT,
            from_city TEXT,
            to_city TEXT,
            km REAL,
            amount REAL,
            date TEXT,
            notes TEXT,
            created_by TEXT
          );
        ''');
        await db.execute('''
          CREATE TABLE payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            party TEXT,
            type TEXT,
            amount REAL,
            date TEXT,
            reference TEXT,
            created_by TEXT
          );
        ''');
        await db.insert('users', {
          'email': 'admin@hslogistics.pk',
          'name': 'Admin',
          'role': 'admin'
        });
      },
    );
  }
}
