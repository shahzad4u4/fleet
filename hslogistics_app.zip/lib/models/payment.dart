
class Payment {
  int? id;
  String party;
  String type; // incoming or outgoing
  double amount;
  String date;
  String reference;
  String createdBy;

  Payment({
    this.id,
    required this.party,
    required this.type,
    required this.amount,
    required this.date,
    required this.reference,
    required this.createdBy,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'party': party,
        'type': type,
        'amount': amount,
        'date': date,
        'reference': reference,
        'created_by': createdBy,
      };

  factory Payment.fromMap(Map<String, dynamic> m) => Payment(
        id: m['id'],
        party: m['party'],
        type: m['type'],
        amount: (m['amount'] ?? 0).toDouble(),
        date: m['date'],
        reference: m['reference'] ?? '',
        createdBy: m['created_by'] ?? '',
      );
}
