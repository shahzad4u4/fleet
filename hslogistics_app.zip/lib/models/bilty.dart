
class Bilty {
  int? id;
  String vendor;
  String vehicle;
  String goods;
  String fromCity;
  String toCity;
  double km;
  double amount;
  String date;
  String notes;
  String createdBy;

  Bilty({
    this.id,
    required this.vendor,
    required this.vehicle,
    required this.goods,
    required this.fromCity,
    required this.toCity,
    required this.km,
    required this.amount,
    required this.date,
    required this.notes,
    required this.createdBy,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'vendor': vendor,
        'vehicle': vehicle,
        'goods': goods,
        'from_city': fromCity,
        'to_city': toCity,
        'km': km,
        'amount': amount,
        'date': date,
        'notes': notes,
        'created_by': createdBy,
      };

  factory Bilty.fromMap(Map<String, dynamic> m) => Bilty(
        id: m['id'],
        vendor: m['vendor'],
        vehicle: m['vehicle'],
        goods: m['goods'],
        fromCity: m['from_city'],
        toCity: m['to_city'],
        km: (m['km'] ?? 0).toDouble(),
        amount: (m['amount'] ?? 0).toDouble(),
        date: m['date'],
        notes: m['notes'] ?? '',
        createdBy: m['created_by'] ?? '',
      );
}
