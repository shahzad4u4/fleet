# HS Logistics – Flutter App (Payments + Bilty)

**Screens:** Login, Dashboard, Bilty List/Add, Payments, About.

## Build (Android APK)
1) Install Flutter (3.x).
2) In terminal:
```
flutter create .
flutter pub get
flutter run   # test
flutter build apk --release
```
(If asked to overwrite, choose **y** to add android/ios folders.)

## Replace Branding
- Put your real logo at `assets/logo.png`.
- Update About info in `lib/screens/about_screen.dart`.

## Roles
- Login as `admin@hslogistics.pk` → Admin (full control).
- Any other email → Staff.
